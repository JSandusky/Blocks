#include "DocType_CommonActions.h"

#include <Urho3D/Resource/ResourceCache.h>

#include "Block.h"
#include "Doc_DocumentManager.h"
#include "Doc_Document3D.h"

#include "Clipboard.h"
#include "DocType_Scene.h"
#include "Urho_Undo.h"
#include "Urho_Util.h"

using namespace Urho3D;

#define URHO_NODE_LIST std::vector<std::shared_ptr<UrhoNodeSelectable>>


AppAction* StandardActions::ClearSelection = nullptr;
AppAction* StandardActions::CutScene = nullptr;
AppAction* StandardActions::CopyScene = nullptr;
AppAction* StandardActions::PasteScene = nullptr;
AppAction* StandardActions::ResetToDefault = nullptr;
AppAction* StandardActions::ResetPosition = nullptr;
AppAction* StandardActions::ResetRotation = nullptr;
AppAction* StandardActions::ResetScale = nullptr;
AppAction* StandardActions::ResetTransform = nullptr;

AppAction* StandardActions::ToggleSceneUpdate = nullptr;
AppAction* StandardActions::ViewCloser = nullptr;
AppAction* StandardActions::MatchToCamera = nullptr;

AppAction* StandardActions::CloneScene = nullptr;
AppAction* StandardActions::DeleteScene = nullptr;
AppAction* StandardActions::NewLocalChild = nullptr;
AppAction* StandardActions::NewReplicatedChild = nullptr;
AppAction* StandardActions::SaveAsPrefab = nullptr;
AppAction* StandardActions::ReloadPrefab = nullptr;
AppAction* StandardActions::BreakPrefab = nullptr;

AppAction* StandardActions::SetSceneToLocal = nullptr;
AppAction* StandardActions::SetSceneToReplicated = nullptr;
AppAction* StandardActions::SetToTemporary = nullptr;
AppAction* StandardActions::SetToPersistent = nullptr;

AppAction* StandardActions::GizmoSelect = nullptr;
AppAction* StandardActions::GizmoMove = nullptr;
AppAction* StandardActions::GizmoRotate = nullptr;
AppAction* StandardActions::GizmoScale = nullptr;
AppAction* StandardActions::GizmoBox = nullptr;
AppAction* StandardActions::GizmoToggleLocal = nullptr;

AppAction* StandardActions::UndoAction = nullptr;
AppAction* StandardActions::RedoAction = nullptr;

void StandardActions::InitializeSceneStandardActions()
{
    auto input = BlockExe::GetInst()->GetSubsystem<Input>();

    SharedPtr<InputBinding> binding = SharedPtr<InputBinding>(new DocumentAction<DocumentBase>("Selection", ICON_FA_CIRCLE_NOTCH " Clear Selection", "Deselects all currently selected items", [](DocumentBase* doc) { doc->GetSelection().DeselectAll(); }));
    input->AddInputBinding(binding);
    ClearSelection = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_CUT " Cut", "Cuts the selected nodes/components to the clipboard", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable> > nodes) {
        if (nodes.size() > 0)
        {
            SelectionList oldSel = doc->GetSelection();

            std::vector<std::shared_ptr<UndoRedo> > actions;
            VectorBuffer buffer;
            buffer.WriteUInt(nodes.size());
            buffer.WriteVector3(Centroid(nodes));
            for (auto sel : nodes)
            {
                sel->node_->Save(buffer);
                actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(sel->node_->GetParent()), sel->node_, false));
            }
            Clipboard::SetClipboardData(1, buffer);
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_CUT " Cut " + String(nodes.size()) + " nodes"), actions))->AttachSelectables(oldSel, SelectionList());
        }
    });
    binding->FromString("CTRL + X");
    input->AddInputBinding(binding);
    CutScene = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_COPY " Copy", "Copy selected nodes to the clipboard", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        if (nodes.size() > 0)
        {
            std::vector<std::shared_ptr<UndoRedo> > actions;
            VectorBuffer buffer;
            buffer.WriteUInt(nodes.size());
            buffer.WriteVector3(Centroid(nodes));
            for (auto sel : nodes)
                sel->node_->Save(buffer);
            Clipboard::SetClipboardData(1, buffer);
        }
        else
        {
            auto comps = CastVector<UrhoComponentSelectable>(doc->GetSelection());
        }
    });
    binding->FromString("CTRL + C");
    input->AddInputBinding(binding);
    CopyScene = (AppAction*)binding.Get();

    binding = new DocumentAction<Document3D>("Node Actions", ICON_FA_PASTE " Paste Nodes", "Paste nodes from clipboard into the scene/selected node", [](Document3D* doc) {
        auto target = doc->GetSelection().MostRecent<UrhoNodeSelectable>();
        if (!target)
            target = std::make_shared<UrhoNodeSelectable>(doc->GetScene());

        if (target)
        {
            if (Clipboard::GetClipboardDataType() == 1)
            {
                SelectionList oldSelection = doc->GetSelection();
                SelectionList newSelection;

                Clipboard::GetClipboardData().Seek(0);
                unsigned ct = Clipboard::GetClipboardData().ReadUInt();
                Vector3 centroid = Clipboard::GetClipboardData().ReadVector3();
                std::vector<std::shared_ptr<UndoRedo>> actions;
                for (unsigned i = 0; i < ct; ++i)
                {
                    SharedPtr<Node> nd(target->node_->CreateChild());
                    nd->Load(Clipboard::GetClipboardData());
                    nd->SetWorldPosition(nd->GetWorldPosition() - centroid);
                    actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(target->node_, nd, true));
                    newSelection.push_back(std::make_shared<UrhoNodeSelectable>(nd));
                }
                doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_PASTE " Paste " + String(ct) + " nodes"), actions))->AttachSelectables(oldSelection, newSelection);
            }
        }
    });
    binding->FromString("CTRL + V");
    input->AddInputBinding(binding);
    PasteScene = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SYNC_ALT " Reset To Default", "Resets selected nodes and components to the defaults", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        for (auto sel : nodes)
            sel->node_->ResetToDefault();
    });
    input->AddInputBinding(binding);
    ResetToDefault = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SYNC_ALT " Reset Position", "Resets selected node positions to 0,0,0", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        for (auto sel : nodes)
            sel->node_->SetPosition(Vector3::ZERO);
    });
    input->AddInputBinding(binding);
    ResetPosition = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SYNC_ALT " Reset Rotation", "Resets selected node rotations to 0 degrees", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        for (auto sel : nodes)
            sel->node_->SetRotation(Quaternion::IDENTITY);
    });
    input->AddInputBinding(binding);
    ResetRotation = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SYNC_ALT " Reset Scale", "Resets selected node scales to 1,1,1", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        for (auto sel : nodes)
            sel->node_->SetScale(Vector3::ONE);
    });
    input->AddInputBinding(binding);
    ResetScale = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SYNC_ALT " Reset Transform", "Resets selected nodes transform to the identity matrix", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        for (auto sel : nodes)
            sel->node_->SetTransform(Matrix3x4::IDENTITY);
    });
    input->AddInputBinding(binding);
    ResetTransform = (AppAction*)binding.Get();

    binding = new DocumentAction<Document3D>("Scene Actions", ICON_FA_PLAY " Toggle Scene Update", "Enables/disables runtime updates of the scene", [](Document3D* doc) {
        doc->GetScene()->SetUpdateEnabled(!doc->GetScene()->IsUpdateEnabled());
    });
    input->AddInputBinding(binding);
    ToggleSceneUpdate = (AppAction*)binding.Get();

    ViewCloser;
    MatchToCamera;

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_CLONE " Clone", "Clones the selected nodes", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> selected) {
        std::vector<Node*> newNodes;
        std::vector<SharedPtr<Node> > parents;
        for (auto sel : selected)
        {
            if (auto parent = sel->node_->GetParent())
            {
                auto clone = sel->node_->Clone(sel->node_->GetID() >= FIRST_LOCAL_ID ? LOCAL : REPLICATED);
                newNodes.push_back(clone);
                parents.push_back(SharedPtr<Node>(parent));
            }
        }

        if (newNodes.size() > 0)
        {
            SelectionList oldSelection = doc->GetSelection();
            doc->GetSelection().DeselectAll();
            for (auto sel : newNodes)
                doc->GetSelection().AddSelection(std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(sel)));

            doc->GetUndoStack().PushNew(std::make_shared<FunctionalUndoRedo>(ICON_FA_CLONE " ^3Clone Nodes", [=]() {
                for (size_t i = 0; i < newNodes.size(); ++i)
                    parents[i]->AddChild(newNodes[i]);
            },
                [=]() {
                for (auto sel : newNodes)
                    sel->GetParent()->RemoveChild(sel);
            }))->AttachSelectables(oldSelection, doc->GetSelection());
        }
    });
    input->AddInputBinding(binding);
    CloneScene = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_TRASH " Delete", "Deletes the selected nodes", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        SelectionList oldSelection = doc->GetSelection();
        auto castVec = CastVector<UrhoNodeSelectable, Selectable>(doc->GetSelection());
        std::vector<std::shared_ptr<UndoRedo>> actions;
        for (auto v : castVec)
        {
            SharedPtr<Node> parentNode(v->node_->GetParent());
            SharedPtr<Node> self(v->node_);
            actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(parentNode, self, false));
            doc->GetSelection().Deselect(v);
        }

        if (actions.size() > 1)
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_TRASH " ^1Delete " + String(actions.size()) + " nodes, " + ToCSV<SharedPtr<Node> >(ToNodeVector(castVec), [](SharedPtr<Node> n) { return n->GetName() + " : " + String(n->GetID()); })), actions))->AttachSelectables(oldSelection, doc->GetSelection());
        else if (actions.size() == 1)
            doc->GetUndoStack().PushNew(actions[0])->AttachSelectables(oldSelection, doc->GetSelection());

        doc->GetSelection().clear();
    });
    input->AddInputBinding(binding);
    DeleteScene = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", "New Local Child", "Creates a local child on the most recently selected noded", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        auto tgt = doc->GetSelection().MostRecent<UrhoNodeSelectable>();//lastNode ? lastNode : camera->GetScene();
        if (doc)
        {
            SharedPtr<Node> child(tgt->node_->CreateChild(String::EMPTY, Urho3D::LOCAL));
            //if (rayHit)
            //    child->SetWorldPosition(*rayHit);
            SelectionList oldSelection = doc->GetSelection();
            doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(child));
            doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(tgt->node_), child, true))->AttachSelectables(oldSelection, doc->GetSelection());
        }
    });
    input->AddInputBinding(binding);
    NewLocalChild = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", "New Replicated Child", "Creates a replicated child on the most recently selected noded", [](DocumentBase* doc, std::vector<std::shared_ptr<UrhoNodeSelectable>> nodes) {
        auto tgt = doc->GetSelection().MostRecent<UrhoNodeSelectable>();//lastNode ? lastNode : camera->GetScene();
        if (doc)
        {
            SharedPtr<Node> child(tgt->node_->CreateChild(String::EMPTY, Urho3D::REPLICATED));
            //if (rayHit)
            //    child->SetWorldPosition(*rayHit);
            SelectionList oldSelection = doc->GetSelection();
            doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(child));
            doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(tgt->node_), child, true))->AttachSelectables(oldSelection, doc->GetSelection());
        }
    });
    input->AddInputBinding(binding);
    NewReplicatedChild = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SAVE " Save As Prefab", "Saves the current node as a prefab", [](DocumentBase* doc, URHO_NODE_LIST nodes) {
        auto filePath = GetSaveFile("Save Prefab", "*.xml", "Prefab XML Scene (*.xml)|*.xml");
        auto node = doc->GetSelection().MostRecent<UrhoNodeSelectable>()->node_;
        if (!filePath.empty())
        {
            auto ctx = BlockExe::GetInst()->GetContext();
            auto cache = ctx->GetSubsystem<ResourceCache>();

            SharedPtr<XMLFile> file(new XMLFile(ctx));
            auto sceneRoot = file->CreateRoot("node");
            node->SaveXML(sceneRoot);
            file->SaveFile(filePath.c_str());
            node->GetScene()->RegisterVar("PREFAB_PATH");
            node->SetVar("PREFAB_PATH", cache->SanitateResourceName(filePath.c_str()));
        }
    });
    input->AddInputBinding(binding);
    SaveAsPrefab = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SYNC_ALT " Reload Prefab", "Reloads selected node prefabs", [](DocumentBase* doc, URHO_NODE_LIST selected) {
        for (auto sel : selected)
            ReloadNodePrefab(sel->node_);
    });
    input->AddInputBinding(binding);
    ReloadPrefab = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_LINK " Break Prefabs", "Disconnects selected node prefabs from their sources", [](DocumentBase* doc, URHO_NODE_LIST selected) {
        std::vector<std::shared_ptr<UndoRedo> > actions;
        for (auto sel : selected)
        {
            auto oldValue = sel->node_->GetVar("PREFAB_PATH");
            actions.push_back(std::make_shared<FunctionalUndoRedo>("Break prefab connection", [=]() {
                sel->node_->SetVar("PREFAB_PATH", Variant());
            }, [=]() {
                sel->node_->SetVar("PREFAB_PATH", oldValue);
            }));
        }

        if (actions.size() > 0)
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_LINK " ^3Break prefab connection", actions))->RecordStandardSelectables(doc);
    });
    input->AddInputBinding(binding);
    BreakPrefab = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_MAP_MARKER " Set To Local", "Sets selected nodes to local replication", [](DocumentBase* doc, URHO_NODE_LIST selected) {
        // TODO: how the fuck to deal with selection here?
        UndoRedoList actions;
        SelectionList oldSelection = doc->GetSelection();
        auto lastNode = doc->GetSelection().MostRecent<UrhoNodeSelectable>()->node_;
        for (auto sel : selected)
        {
            if (dynamic_cast<Scene*>(sel->node_.Get()))
                continue;
            if (sel->node_->GetID() < FIRST_LOCAL_ID)
            {
                unsigned index = sel->node_->GetParent()->GetChildren().IndexOf(sel->node_);
                SharedPtr<Node> parent(sel->node_->GetParent());
                SharedPtr<Node> newNode(sel->node_->Clone(LOCAL));
                unsigned oldID = newNode->GetID();
                newNode->Remove();
                actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(parent, sel->node_, false));
                actions.push_back(std::make_shared<FunctionalUndoRedo>("", [=]() {
                    newNode->SetID(oldID);
                    parent->AddChild(newNode, index);
                },
                    [=]() {
                    newNode->Remove();
                }));
            }
        }
        if (actions.size() > 2)
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_MAP_MARKER " ^3Convert nodes to local", actions));
        else if (actions.size())
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_MAP_MARKER " ^3Convert " + lastNode->GetName() + " : " + String(lastNode->GetID()) + " to local"), actions));
    });
    input->AddInputBinding(binding);
    SetSceneToLocal = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_SITEMAP " Set To Replicated", "Sets selected nodes to networked replication", [](DocumentBase* doc, URHO_NODE_LIST selected) {
        auto lastNode = doc->GetSelection().MostRecent<UrhoNodeSelectable>()->node_;
        UndoRedoList actions;
        for (auto sel : selected)
        {
            if (dynamic_cast<Scene*>(sel->node_.Get()))
                continue;
            if (sel->node_->GetID() >= FIRST_LOCAL_ID)
            {
                unsigned index = sel->node_->GetParent()->GetChildren().IndexOf(sel->node_);
                SharedPtr<Node> parent(sel->node_->GetParent());
                SharedPtr<Node> newNode(sel->node_->Clone(REPLICATED));
                SharedPtr<Node> FakeNewNode(sel->node_->GetParent()->CreateChild("", REPLICATED));
                unsigned oldID = FakeNewNode->GetID();;
                newNode->Remove();
                FakeNewNode->Remove();
                actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(parent, sel->node_, false));
                actions.push_back(std::make_shared<FunctionalUndoRedo>("", [=]() {
                    newNode->SetID(oldID);
                    parent->AddChild(newNode, index);
                },
                    [=]() {
                    newNode->Remove();
                }));
            }
        }
        if (actions.size() > 2)
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_SITEMAP " ^3Convert nodes to replicated", actions));
        else if (actions.size())
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_SITEMAP " ^3Convert " + lastNode->GetName() + " : " + String(lastNode->GetID()) + " to replicated"), actions));
    });
    input->AddInputBinding(binding);
    SetSceneToReplicated = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_HOURGLASS " Set To Temporary", "Converts selected nodes to temporary", [](DocumentBase* doc, URHO_NODE_LIST selected) {
        UndoRedoList actions;
        for (auto sel : selected)
        {
            if (dynamic_cast<Scene*>(sel->node_.Get()))
                continue;

            bool oldState = sel->node_->IsTemporary();
            String lbl = ICON_FA_HOURGLASS " ^3Set ";
            lbl.AppendWithFormat("%s : [%u] to temporary", sel->node_->GetName().CString(), sel->node_->GetID());
            actions.push_back(std::make_shared<FunctionalUndoRedo>(lbl.CString(), [=]() { sel->node_->SetTemporary(true); }, [=]() { sel->node_->SetTemporary(oldState); }));
        }
        if (actions.size() == 1)
            doc->GetUndoStack().PushNew(actions[0])->RecordStandardSelectables(doc);
        else if (actions.size() > 1)
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_HOURGLASS " Convert nodes to temporary", actions))->RecordStandardSelectables(doc);
    });
    input->AddInputBinding(binding);
    SetToTemporary = (AppAction*)binding.Get();

    binding = new SelectableAction<UrhoNodeSelectable>("Node Actions", ICON_FA_GLOBE " Set To Permanent", "Sets selected nodes to serialized status", [](DocumentBase* doc, URHO_NODE_LIST selected) {
        UndoRedoList actions;
        for (auto sel : selected)
        {
            if (dynamic_cast<Scene*>(sel->node_.Get()))
                continue;

            bool oldState = sel->node_->IsTemporary();
            String lbl = ICON_FA_GLOBE " ^3Set ";
            lbl.AppendWithFormat("%s : [%u] to permanent", sel->node_->GetName().CString(), sel->node_->GetID());
            actions.push_back(std::make_shared<FunctionalUndoRedo>(lbl.CString(), [=]() { sel->node_->SetTemporary(false); }, [=]() { sel->node_->SetTemporary(oldState); }));
        }
        if (actions.size() == 1)
            doc->GetUndoStack().PushNew(actions[0])->RecordStandardSelectables(doc);
        else if (actions.size() > 1)
            doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_HOURGLASS " Convert nodes to permanent", actions))->RecordStandardSelectables(doc);
    });
    input->AddInputBinding(binding);
    SetToPersistent = (AppAction*)binding.Get();

    binding = new AppAction("Manipulator", ICON_FA_MOUSE_POINTER " Select", "Activate selection only mode", []() { BaseGizmo::mode_ = BaseGizmo::NONE; });
    binding->FromString("CTRL + 1");
    input->AddInputBinding(binding);
    GizmoSelect = (AppAction*)binding.Get();

    binding = new AppAction("Manipulator", ICON_FA_ARROWS_ALT " Translate", "Activate translation mode", []() { BaseGizmo::mode_ = BaseGizmo::TRANSLATE; });
    binding->FromString("CTRL + 2");
    input->AddInputBinding(binding);
    GizmoSelect = (AppAction*)binding.Get();

    binding = new AppAction("Manipulator", ICON_FA_SYNC_ALT " Rotate", "Activate rotate mode", []() { BaseGizmo::mode_ = BaseGizmo::ROTATE; });
    binding->FromString("CTRL + 3");
    input->AddInputBinding(binding);
    GizmoSelect = (AppAction*)binding.Get();

    binding = new AppAction("Manipulator", ICON_FA_EXPAND_ARROWS_ALT " Scale", "Activate scale mode", []() { BaseGizmo::mode_ = BaseGizmo::SCALE; });
    binding->FromString("CTRL + 4");
    input->AddInputBinding(binding);
    GizmoSelect = (AppAction*)binding.Get();

    binding = new AppAction("Manipulator", ICON_FA_CUBE " Box", "Activate box resize", []() { BaseGizmo::mode_ = BaseGizmo::BOX; });
    binding->FromString("CTRL + 5");
    input->AddInputBinding(binding);
    GizmoSelect = (AppAction*)binding.Get();

    binding = new AppAction("Manipulator", ICON_FA_GLOBE " Toggle Local/Global", "Toggle between local and global space", []() { BaseGizmo::isLocal_ = !BaseGizmo::isLocal_; });
    binding->FromString("CTRL + L");
    input->AddInputBinding(binding);
    GizmoSelect = (AppAction*)binding.Get();

    binding = new AppAction("Application Core", ICON_FA_UNDO " Undo", "Reverse a step in the undo/redo history", []() {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
            doc->GetUndoStack().Undo();
    }, []() -> bool {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
            return doc->GetUndoStack().undo_.size() > 0;
        return false;
    });
    binding->FromString("CTRL + Z");
    input->AddInputBinding(binding);
    UndoAction = (AppAction*)binding.Get();

    binding = new AppAction("Application Core", ICON_FA_REDO " Redo", "Move forward a step in the undo/redo history", []() {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
            doc->GetUndoStack().Redo();
    }, []() -> bool {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
        {
            unsigned undoSize = doc->GetUndoStack().redo_.size();
            return undoSize > 0;
        }
        return false;
    });
    binding->FromString("CTRL + SHIFT + Z");
    input->AddInputBinding(binding);
    RedoAction = (AppAction*)binding.Get();
}
