#pragma once

#include "Doc_Document3D.h"

#include <Urho3D/ThirdParty/ImGui/imgui.h>

namespace Urho3D
{
    class Context;
    class UIElement;
}

class UIDocumentType : public DocumentType
{
public:
    UIDocumentType();

    virtual std::shared_ptr<DocumentBase> NewDocument() override;
    virtual std::shared_ptr<DocumentBase> OpenPath(const Urho3D::String& path) override;

    virtual bool OpensXML(const Urho3D::String& xmlRootName) { return xmlRootName == "element"; }
};

class UIDocument : public Document3D, public ITreeDocument
{
public:
    UIDocument(Urho3D::Context* ctx);
    UIDocument(Urho3D::Context*, const Urho3D::String& path);
    UIDocument(Urho3D::Context*, const UIDocument& src) = delete;
    virtual ~UIDocument();

    virtual unsigned GetTabColor() const override { return ImColor(120, 120, 30, 255); }

    virtual bool Save() override;
    virtual void SaveAs() override;
    virtual bool Close() override;

    virtual void DrawMasterButtons() override;
    virtual void PreDraw() override;
    virtual void DrawDocumentTree(ImGuiTextFilter*) override;

    virtual void Activated() override;
    virtual void Deactivated() override;

private:
    void CommonConstruct();
    void ShowTree(Urho3D::UIElement*);
    Urho3D::UIElement* DoCreateElement(Urho3D::UIElement*);

    Urho3D::SharedPtr<Urho3D::UIElement> secretRoot_;
    Urho3D::SharedPtr<Urho3D::UIElement> root_;
};