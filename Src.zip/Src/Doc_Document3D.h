#pragma once

#include "Doc_DocumentManager.h"

namespace ImGuizmo
{
    struct Context;
}

class Document3D : public DocumentBase
{
public:
    Document3D(Urho3D::Context* context, Urho3D::SharedPtr<Urho3D::Scene> scene);
    virtual ~Document3D();

    struct View
    {
        View(Document3D* doc, Urho3D::SharedPtr<Urho3D::Node> camNode);
        ~View();

        void CheckSize(int w, int h);

        Urho3D::SharedPtr<Urho3D::Texture2D> surface_;
        Urho3D::SharedPtr<Urho3D::Node> cameraNode_;
        Urho3D::SharedPtr<Urho3D::Viewport> viewport_;
        Document3D* doc_;
        ImGuizmo::Context* gizmoContext_;

        int viewID_ = 0;

        static int nextViewID_;
    };

    Urho3D::SharedPtr<Urho3D::Scene>& GetScene() { return scene_; }

    virtual void PreDraw() override;

    std::unique_ptr<BaseGizmo>& GetGizmo() { return gizmo_; }
    virtual bool CheckMultiGizmo() { return false; }

    virtual void UpdateNodeIcons();

    virtual bool Close() override;

protected:
    void DrawViewManagementWidgets();

    Urho3D::SharedPtr<Urho3D::Scene> scene_;
    Urho3D::SharedPtr<Urho3D::Node> debugIconNode_;
    Urho3D::SharedPtr<Urho3D::BillboardSet> debugIconBB_;
    std::unique_ptr<BaseGizmo> gizmo_;
    bool wantNodeIcons_ = true;
};