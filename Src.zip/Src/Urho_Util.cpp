#include "Urho_Util.h"

#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/Graphics/Octree.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Resource/XMLElement.h>
#include <Urho3D/Resource/XMLFile.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>

#include "Block.h"
#include "Clipboard.h"
#include "Doc_DocumentManager.h"
#include "DataObject.h"
#include "GUI_Main.h"
#include "Doc_Selectable.h"
#include "DocType_Scene.h"
#include "Urho_Undo.h"
#include "UX.h"

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

int GridSize = 30;

extern std::unique_ptr<DataObject> viewportSettings_;

SharedPtr<Node> GetNodeByID(SharedPtr<Node> cur, unsigned id)
{
    for (auto child : cur->GetChildren())
    {
        if (child->GetID() == id)
            return child;
    }
    
    for (auto child : cur->GetChildren())
    {
        if (auto ret = GetNodeByID(child, id))
            return ret;
    }

    return nullptr;
}

SharedPtr<Component> GetComponentByID(SharedPtr<Node> cur, unsigned id)
{
    for (auto child : cur->GetComponents())
    {
        if (child->GetID() == id)
            return child;
    }

    for (auto child : cur->GetChildren())
    {
        if (auto ret = GetComponentByID(child, id))
            return ret;
    }

    return nullptr;
}

void DrawGrid_3D(Urho3D::DebugRenderer* debugRen, const Urho3D::Vector3& origin)
{
    GridSize = viewportSettings_->GetField("Grid Size").GetFloat();

    if (!viewportSettings_->GetField("Show Grid").GetBool())
        return;

    if (viewportSettings_->GetField("2D Grid Mode").GetBool())
    {
        DrawGrid_2D(debugRen, origin);
        return;
    }

    int x = origin.x_;
    int y = origin.y_;
    int z = origin.z_;

    for (int xx = -GridSize; xx < GridSize+1; ++xx)
        debugRen->AddLine(Vector3(x + xx, 0, z + -GridSize), Vector3(x + xx, 0, z + GridSize), Color(1, 1, 1, 0.3f));
    for (int yy = -GridSize; yy < GridSize+1; ++yy)
        debugRen->AddLine(Vector3(x + -GridSize, 0, z + yy), Vector3(x + GridSize, 0, z + yy), Color(1, 1, 1, 0.3f));
}

void DrawGrid_2D(Urho3D::DebugRenderer* debugRen, const Urho3D::Vector3& origin)
{
    int x = origin.x_;
    int y = origin.y_;
    int z = origin.z_;

    for (int xx = -GridSize; xx < GridSize+1; ++xx)
        debugRen->AddLine(Vector3(x + xx, y + -GridSize, 0), Vector3(x + xx, y + GridSize, 0), Color(1, 1, 1, 0.3f));
    for (int yy = -GridSize; yy < GridSize+1; ++yy)
        debugRen->AddLine(Vector3(x + -GridSize, y + yy, 0), Vector3(x + GridSize, y + yy, 0), Color(1, 1, 1, 0.3f));
}

void Focus(const Urho3D::BoundingBox& bounds, const Urho3D::Vector3& offsetDir, Urho3D::Vector3* outPos, Urho3D::Vector3* outDir)
{
    // Compute centroid and bounds (to approximate radius)
    Vector3 centroid = bounds.Center();
    Vector3 min = bounds.min_;
    Vector3 max = bounds.max_;

    float radius = (max - min).Length() / 2;
    double camDistance = (radius * 1.5) / atanf((45 * M_DEGTORAD) / 2.0);
    float dist = (float)(camDistance) * 0.5f;

    // Set our position, then look at the centroid
    *outPos = centroid + offsetDir * dist; //TODO: check axis length to change to a more ideal view?
    //??if (fabsf(Vector3.Dot(offsetDir, Vector3::UP)) > 0.9f)
    //??    upDir_ = Vector3.UnitZ;
    *outDir = centroid;
}

Urho3D::Vector3 GetSelectionCentroid()
{
    Vector3 ret(0, 0, 0);
    if (auto doc = DocumentManager::Get()->GetActiveDocument())
    {
        float ct = 0;
        for (auto sel : doc->GetSelection())
        {
            if (auto nd = std::dynamic_pointer_cast<UrhoNodeSelectable>(sel))
            {
                ret += nd->node_->GetWorldPosition();
                ct += 1.0f;
            }
            else if (auto comp = std::dynamic_pointer_cast<UrhoComponentSelectable>(sel))
            {
                ret += comp->component_->GetNode()->GetWorldPosition();
                ct += 1.0f;
            }
        }
        if (ct > 0)
            ret /= ct;
    }
    return ret;
}

Urho3D::String GetResourceNameFromFullName(const Urho3D::String& resourceName)
{
    auto cache = BlockExe::GetInst()->GetSubsystem<ResourceCache>();
    auto resourceDirs = cache->GetResourceDirs();

    for (size_t i = 0; i < resourceDirs.Size(); ++i)
    {
        if (!resourceName.ToLower().StartsWith(resourceDirs[i].ToLower()))
            continue;
        return resourceName.Substring(resourceDirs[i].Length());
    }

    return ""; // Not found
}

bool EditorSettingsDialog()
{
    extern std::unique_ptr<DataObject> editorSettings_;
    DataObject::DrawEditor(editorSettings_.get());
    return true;
}

bool ViewportSettingsDialog()
{
    extern std::unique_ptr<DataObject> viewportSettings_;
    DataObject::DrawEditor(viewportSettings_.get());
    return true;
}

bool LightingSettingsDialog()
{
    extern std::unique_ptr<DataObject> lightmapSettings_;
    DataObject::DrawEditor(lightmapSettings_.get());
    return true;
}

bool ManipulatorSettingsDialog()
{
    extern std::unique_ptr<DataObject> gizmoSettings_;
    DataObject::DrawEditor(gizmoSettings_.get());
    return true;
}


static bool showingComponentPopup = false;
static bool compPopupJustShowed = false;
void ShowCreateComponentPopup(Node* onNode, ImVec2* mousePos, UndoStack* undoStack)
{
    
}

void FillNodeContextMenu(Urho3D::Node* node, Urho3D::Node* camera, Urho3D::Vector3* rayHit)
{
    auto lastNode = node;
    auto doc = DocumentManager::Get()->GetActiveDoc<Document3D>();
    std::vector<std::shared_ptr<UrhoNodeSelectable> > selected = CastVector<UrhoNodeSelectable>(doc->GetSelection());

    extern ImVec4 GetEditorIconUV(const String&);

    auto texSize = GetEditorIconUV("Node");
    ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(20, 20), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w));
    ImGui::SameLine();
    if (ImGui::MenuItem("New Local Child Node"))
    {
        auto tgt = lastNode ? lastNode : camera->GetScene();
        if (doc)
        {
            SharedPtr<Node> child(tgt->CreateChild(String::EMPTY, Urho3D::LOCAL));
            if (rayHit)
                child->SetWorldPosition(*rayHit);
            SelectionList oldSelection = doc->GetSelection();
            doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(child));
            doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(tgt), child, true))->AttachSelectables(oldSelection, doc->GetSelection());
        }
    }

    texSize = GetEditorIconUV("Node");
    ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(20, 20), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w));
    ImGui::SameLine();
    if (ImGui::MenuItem("New Replicated Child Node"))
    {
        auto tgt = lastNode ? lastNode : camera->GetScene();
        if (doc)
        {
            SharedPtr<Node> child(tgt->CreateChild(String::EMPTY, Urho3D::REPLICATED));
            if (rayHit)
                child->SetWorldPosition(*rayHit);
            SelectionList oldSelection = doc->GetSelection();
            doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(child));
            doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(tgt), child, true))->AttachSelectables(oldSelection, doc->GetSelection());
        }
    }
    ImGuiUX::AutoSeparator();

    if (selected.size() > 0)
    {
        if (ImGuiUX::AutoMenu(ICON_FA_CUT " Cut"))
        {
            if (selected.size() > 0)
            {
                SelectionList oldSelection = doc->GetSelection();

                std::vector<std::shared_ptr<UndoRedo> > actions;
                VectorBuffer buffer;
                buffer.WriteUInt(selected.size());
                buffer.WriteVector3(Centroid(selected));
                for (auto sel : selected)
                {
                    sel->node_->Save(buffer);
                    actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(sel->node_->GetParent()), sel->node_, false));
                    doc->GetSelection().Deselect(sel);
                }
                Clipboard::SetClipboardData(1, buffer);
                doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_CUT " Cut " + String(selected.size()) + " nodes"), actions))->AttachSelectables(oldSelection, doc->GetSelection());
            }
        }
        if (ImGuiUX::AutoMenu(ICON_FA_COPY " Copy"))
        {
            if (selected.size() > 0)
            {
                std::vector<std::shared_ptr<UndoRedo> > actions;
                VectorBuffer buffer;
                buffer.WriteUInt(selected.size());
                buffer.WriteVector3(Centroid(selected));
                for (auto sel : selected)
                    sel->node_->Save(buffer);
                Clipboard::SetClipboardData(1, buffer);
            }
        }
    }

    if (Clipboard::GetClipboardDataType() == 1)
    {
        if (ImGuiUX::AutoMenu(ICON_FA_PASTE " Paste"))
        {
            auto target = doc->GetSelection().MostRecent<UrhoNodeSelectable>();
            if (!target || rayHit)
                target = std::make_shared<UrhoNodeSelectable>(doc->GetScene());

            if (target)
            {
                SelectionList oldSelection = doc->GetSelection();
                Clipboard::GetClipboardData().Seek(0);
                unsigned ct = Clipboard::GetClipboardData().ReadUInt();
                Vector3 centroid = Clipboard::GetClipboardData().ReadVector3();
                std::vector<std::shared_ptr<UndoRedo>> actions;
                doc->GetSelection().DeselectAll();
                for (unsigned i = 0; i < ct; ++i)
                {
                    SharedPtr<Node> nd(target->node_->CreateChild());
                    nd->Load(Clipboard::GetClipboardData());
                    nd->SetWorldPosition(nd->GetWorldPosition() - centroid + (rayHit ? *rayHit : Vector3(0, 0, 0)));
                    actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(target->node_, nd, true));

                    if (i == 0)
                        doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(nd));
                    else
                        doc->GetSelection().AddSelection(std::make_shared<UrhoNodeSelectable>(nd));
                }
                doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_PASTE " Paste " + String(ct) + " nodes"), actions))->AttachSelectables(oldSelection, doc->GetSelection());
            }
        }
        ImGuiUX::AutoSeparator();
    }

    if (selected.size() > 0)
    {
        if (ImGuiUX::AutoMenu(ICON_FA_SAVE " Save as Prefab"))
        {
            auto filePath = GetSaveFile("Save Prefab", "*.xml", "Prefab XML Scene (*.xml)|*.xml");
            if (!filePath.empty())
            {
                auto ctx = BlockExe::GetInst()->GetContext();
                auto cache = ctx->GetSubsystem<ResourceCache>();

                SharedPtr<XMLFile> file(new XMLFile(ctx));
                auto sceneRoot = file->CreateRoot("node");
                node->SaveXML(sceneRoot);
                file->SaveFile(filePath.c_str());
                lastNode->GetScene()->RegisterVar("PREFAB_PATH");
                lastNode->SetVar("PREFAB_PATH", cache->SanitateResourceName(filePath.c_str()));
            }
        }
        if (lastNode->GetVars().Contains("PREFAB_PATH"))
        {
            if (ImGuiUX::AutoMenu(ICON_FA_SYNC_ALT " Reload Prefab"))
            {
                for (auto sel : selected)
                    ReloadNodePrefab(sel->node_);
            }

            if (ImGuiUX::AutoMenu(ICON_FA_LINK " Break Prefab Link"))
            {
                std::vector<std::shared_ptr<UndoRedo> > actions;
                for (auto sel : selected)
                {
                    auto oldValue = sel->node_->GetVar("PREFAB_PATH");
                    actions.push_back(std::make_shared<FunctionalUndoRedo>("Break prefab connection", [=]() {
                        sel->node_->SetVar("PREFAB_PATH", Variant());
                    }, [=]() {
                        sel->node_->SetVar("PREFAB_PATH", oldValue);
                    }));
                }

                if (actions.size() > 0)
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_LINK " ^3Break prefab connection", actions))->RecordStandardSelectables(doc.get());
            }
        }
    }

    if (selected.size() > 0)
    {
        if (ImGuiUX::AutoMenu(ICON_FA_CLONE " Clone"))
        {
            std::vector<Node*> newNodes;
            std::vector<SharedPtr<Node> > parents;
            for (auto sel : selected)
            {
                if (auto parent = sel->node_->GetParent())
                {
                    auto clone = sel->node_->Clone(sel->node_->GetID() >= FIRST_LOCAL_ID ? LOCAL : REPLICATED);
                    newNodes.push_back(clone);
                    parents.push_back(SharedPtr<Node>(parent));
                }
            }

            if (newNodes.size() > 0)
            {
                SelectionList oldSelection = doc->GetSelection();
                doc->GetSelection().DeselectAll();
                for (auto sel : newNodes)
                    doc->GetSelection().AddSelection(std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(sel)));

                doc->GetUndoStack().PushNew(std::make_shared<FunctionalUndoRedo>(ICON_FA_CLONE " ^3Clone Nodes", [=]() {
                    for (size_t i = 0; i < newNodes.size(); ++i)
                        parents[i]->AddChild(newNodes[i]);
                },
                [=]() {
                    for (auto sel : newNodes)
                        sel->GetParent()->RemoveChild(sel);
                }))->AttachSelectables(oldSelection, doc->GetSelection());
            }
        }

        if (camera == nullptr && ImGui::BeginMenu(ICON_FA_PLUG " Replication"))
        {
            if (ImGui::MenuItem(ICON_FA_MAP_MARKER " Set To Local"))
            {
                // TODO: how the fuck to deal with selection here?
                UndoRedoList actions;
                SelectionList oldSelection = doc->GetSelection();
                for (auto sel : selected)
                {
                    if (dynamic_cast<Scene*>(sel->node_.Get()))
                        continue;
                    if (sel->node_->GetID() < FIRST_LOCAL_ID)
                    {                        
                        unsigned index = sel->node_->GetParent()->GetChildren().IndexOf(sel->node_);
                        SharedPtr<Node> parent(sel->node_->GetParent());
                        SharedPtr<Node> newNode(sel->node_->Clone(LOCAL));
                        unsigned oldID = newNode->GetID();
                        newNode->Remove();
                        actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(parent, sel->node_, false));
                        actions.push_back(std::make_shared<FunctionalUndoRedo>("", [=]() {
                            newNode->SetID(oldID);
                            parent->AddChild(newNode, index);
                        },
                        [=]() {
                            newNode->Remove();
                        }));
                    }
                }
                if (actions.size() > 2)
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_MAP_MARKER " ^3Convert nodes to local", actions));
                else if (actions.size())
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_MAP_MARKER " ^3Convert " + lastNode->GetName() + " : " + String(lastNode->GetID()) + " to local"), actions));
            }
            else if (ImGui::MenuItem(ICON_FA_SITEMAP " Set To Replicated"))
            {
                UndoRedoList actions;
                for (auto sel : selected)
                {
                    if (dynamic_cast<Scene*>(sel->node_.Get()))
                        continue;
                    if (sel->node_->GetID() >= FIRST_LOCAL_ID)
                    {
                        unsigned index = sel->node_->GetParent()->GetChildren().IndexOf(sel->node_);
                        SharedPtr<Node> parent(sel->node_->GetParent());
                        SharedPtr<Node> newNode(sel->node_->Clone(REPLICATED));
                        SharedPtr<Node> FakeNewNode(sel->node_->GetParent()->CreateChild("", REPLICATED));
                        unsigned oldID = FakeNewNode->GetID();;
                        newNode->Remove();
                        FakeNewNode->Remove();
                        actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(parent, sel->node_, false));
                        actions.push_back(std::make_shared<FunctionalUndoRedo>("", [=]() {
                            newNode->SetID(oldID);
                            parent->AddChild(newNode, index);
                        },
                        [=]() {
                            newNode->Remove();
                        }));
                    }
                }
                if (actions.size() > 2)
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_SITEMAP " ^3Convert nodes to replicated", actions));
                else if (actions.size())
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_SITEMAP " ^3Convert " + lastNode->GetName() + " : " + String(lastNode->GetID()) + " to replicated"), actions));
            }

            ImGui::Separator();

            if (ImGui::MenuItem(ICON_FA_HOURGLASS " Set To Temporary"))
            {
                UndoRedoList actions;
                for (auto sel : selected)
                {
                    if (dynamic_cast<Scene*>(sel->node_.Get()))
                        continue;

                    bool oldState = sel->node_->IsTemporary();
                    String lbl = ICON_FA_HOURGLASS " ^3Set ";
                    lbl.AppendWithFormat("%s : [%u] to temporary", sel->node_->GetName().CString(), sel->node_->GetID());
                    actions.push_back(std::make_shared<FunctionalUndoRedo>(lbl.CString(), [=]() { sel->node_->SetTemporary(true); }, [=]() { sel->node_->SetTemporary(oldState); }));
                }
                if (actions.size() == 1)
                    doc->GetUndoStack().PushNew(actions[0])->RecordStandardSelectables(doc.get());
                else if (actions.size() > 1)
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_HOURGLASS " Convert nodes to temporary", actions))->RecordStandardSelectables(doc.get());
            }
            if (ImGui::MenuItem(ICON_FA_GLOBE " Set to Permanent"))
            {
                UndoRedoList actions;
                for (auto sel : selected)
                {
                    if (dynamic_cast<Scene*>(sel->node_.Get()))
                        continue;

                    bool oldState = sel->node_->IsTemporary();
                    String lbl = ICON_FA_GLOBE " ^3Set ";
                    lbl.AppendWithFormat("%s : [%u] to permanent", sel->node_->GetName().CString(), sel->node_->GetID());
                    actions.push_back(std::make_shared<FunctionalUndoRedo>(lbl.CString(), [=]() { sel->node_->SetTemporary(false); }, [=]() { sel->node_->SetTemporary(oldState); }));
                }
                if (actions.size() == 1)
                    doc->GetUndoStack().PushNew(actions[0])->RecordStandardSelectables(doc.get());
                else if (actions.size() > 1)
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_HOURGLASS " Convert nodes to permanent", actions))->RecordStandardSelectables(doc.get());
            }

            ImGui::EndMenu();
        }
    }

    static StringHash NodeCtx("NODE_CONTEXT");
    static StringHash TreeCtx("SCENETREE_CONTEXT");

    if (doc)
    {
        if (camera == nullptr)
            doc->SendEvent(TreeCtx);
        else
            doc->SendEvent(NodeCtx);
    }

    if (camera)
    {
        if (ImGuiUX::AutoMenu(ICON_FA_EYE " Match With Camera"))
        {
            if (auto doc = DocumentManager::Get()->GetActiveDocument())
            {
                auto nodes = CastVector<UrhoNodeSelectable>(doc->GetSelection());
                UndoRedoList actions;
                auto camPos = camera->GetWorldPosition();
                auto camRot = camera->GetWorldRotation();
                for (auto sel : nodes)
                {
                    auto node = sel->node_;
                    auto oldPos = sel->node_->GetWorldPosition();
                    auto oldRot = sel->node_->GetWorldRotation();

                    actions.push_back(std::make_shared<FunctionalUndoRedo>((ICON_FA_EYE " ^3Set " + sel->node_->GetName() + " : " + String(sel->node_->GetID()) + " to match camera transform"), [node, camera, camPos, camRot]() { node->SetWorldPosition(camPos); node->SetWorldRotation(camRot); }, [node, camera, oldPos, oldRot]() { node->SetWorldPosition(oldPos); node->SetWorldRotation(oldRot); }));
                }
                if (actions.size() == 1)
                    doc->GetUndoStack().PushNew(actions[0])->RecordStandardSelectables(doc.get());
                else if (actions.size() > 1)
                    doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_EYE " ^3Set nodes to match camera transform", actions))->RecordStandardSelectables(doc.get());
            }
        }
    }

    ImGuiUX::AutoSeparator();

    if (lastNode)
    {
        GUI_PropertiesView::DoCreateComponentMenu(Urho3D::SharedPtr<Node>(lastNode));
        ImGuiUX::AutoSeparator();
    }

    if (lastNode && lastNode->GetParent() && ImGuiUX::AutoMenu(ICON_FA_TRASH " Delete"))
    {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
        {
            SelectionList oldSelection = doc->GetSelection();
            auto castVec = CastVector<UrhoNodeSelectable, Selectable>(doc->GetSelection());
            std::vector<std::shared_ptr<UndoRedo>> actions;
            for (auto v : castVec)
            {
                SharedPtr<Node> parentNode(v->node_->GetParent());
                SharedPtr<Node> self(v->node_);
                actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(parentNode, self, false));
                doc->GetSelection().Deselect(v);
            }

            if (actions.size() > 1)
                doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>((ICON_FA_TRASH " ^1Delete " + String(actions.size()) + " nodes, " + ToCSV<SharedPtr<Node> >(ToNodeVector(castVec), [](SharedPtr<Node> n) { return n->GetName() + " : " + String(n->GetID()); })), actions))->AttachSelectables(oldSelection, doc->GetSelection());
            else if (actions.size() == 1)
                doc->GetUndoStack().PushNew(actions[0])->AttachSelectables(oldSelection, doc->GetSelection());

            doc->GetSelection().clear();
        }
    }

    ImGuiUX::EndAutoMenu();
}

bool LoadEditorScene(Urho3D::Scene* target, const Urho3D::String& scenePath)
{
    auto cache = target->GetSubsystem<ResourceCache>();

    if (auto loaded = cache->GetResource<XMLFile>("Data/EditorScenes/" + scenePath))
    {
        if (target->LoadXML(loaded->GetRoot("scene")))
            return true;
    }

    return false;
}

Urho3D::SharedPtr<Urho3D::Node> CreateNodeFromFile(Urho3D::Scene* target, const Urho3D::String& resPath)
{
    auto cache = target->GetSubsystem<ResourceCache>();
    if (auto file = cache->GetResource<XMLFile>(resPath))
    {
        if (auto newNode = target->CreateChild())
        {
            if (newNode->LoadXML(file->GetRoot()))
                return SharedPtr<Node>(newNode);
            else
                newNode->Remove();
        }
    }
    return nullptr;
}


void ReloadNodePrefab(Urho3D::SharedPtr<Urho3D::Node> node)
{
    if (!node)
        return;

    auto var = node->GetVar("PREFAB_PATH");
    if (var.GetType() != VAR_NONE)
    {
        auto cache = node->GetSubsystem<ResourceCache>();
        if (auto prefabRes = cache->GetResource<XMLFile>(var.GetString()))
        {
            auto oldPos = node->GetPosition();
            auto oldRot = node->GetRotation();
            auto oldScl = node->GetScale();
            auto oldName = node->GetName();
            auto oldEnabled = node->IsEnabled();

            node->RemoveAllChildren();
            node->RemoveAllComponents();
            if (node->LoadXML(prefabRes->GetRoot("node")))
            {
                node->SetPosition(oldPos);
                node->SetRotation(oldRot);
                node->SetScale(oldScl);
                node->SetName(oldName);
                node->SetEnabled(oldEnabled);
            }
            node->SetVar("PREFAB_PATH", var);
        }
    }
}

void Visit(Urho3D::SharedPtr<Urho3D::Node> node, std::function<void(Urho3D::SharedPtr<Urho3D::Node>)> func)
{
    func(node);
    for (auto child : node->GetChildren())
        Visit(child, func);
}

std::vector<Urho3D::SharedPtr<Node> > ToNodeVector(const std::vector<std::shared_ptr<UrhoNodeSelectable>>& sel)
{
    std::vector<Urho3D::SharedPtr<Node>> ret;
    for (auto s : sel)
        ret.push_back(s->node_);
    return ret;
}

Urho3D::Vector3 Centroid(const std::vector<std::shared_ptr<UrhoNodeSelectable>>& sel)
{
    Urho3D::Vector3 pt;
    for (auto s : sel)
        pt += s->node_->GetWorldPosition();
    if (sel.size() > 0)
        pt /= sel.size();
    return pt;
}

