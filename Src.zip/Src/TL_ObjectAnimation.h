#pragma once

#include <Urho3D/Scene/ObjectAnimation.h>
#include <Urho3D/ThirdParty/ImGui/ImSequencer.h>

struct ObjectAnimSequencer : public ImSequencer::SequenceInterface
{
    ObjectAnimSequencer(Urho3D::SharedPtr<Urho3D::ObjectAnimation> animation);
    ~ObjectAnimSequencer();
    Urho3D::SharedPtr<Urho3D::ObjectAnimation> animation_;

    virtual int GetFrameCount() const override;
    virtual int GetTrackCount() const override;
    virtual ImSequencer::TRACK_NATURE GetTrackNature(unsigned trackIndex) const override;

    virtual int GetTrackTypeCount() const override;
    virtual const char *GetTrackTypeName(int typeIndex) const override;
    virtual const char *GetTrackLabel(int index) const override;
    
    virtual unsigned GetKeyFrameCount(int trackIndex) override;
    virtual void Get(int trackIndex, int keyIndex, int** start, int** end, int *type, unsigned int *color) override;

    virtual void Add(int type);
    virtual void Del(int index);
    virtual void Duplicate(int index);
    virtual bool SwapKeyframes(int trackIndex, int keyIndex, int withIndex) override;

};