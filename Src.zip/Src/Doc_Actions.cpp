#include "Doc_Actions.h"

#include "Doc_DocumentManager.h"

#include <Urho3D/DebugNew.h>

UndoRedo::~UndoRedo()
{
    Consequences.clear();
    RedoSelectables.clear();
    UndoSelectables.clear();
}

void UndoRedo::Redo(DocumentBase* doc)
{
    Execute(false, doc);
    for (auto consequence : Consequences)
        consequence->Execute(false, doc);
    firstRedo_ = false;

    if (doc && selectablesSet)
        doc->GetSelection().Set(RedoSelectables);
}

void UndoRedo::Undo(DocumentBase* doc)
{
    Execute(true, doc);
    for (auto consequence : Consequences)
        consequence->Execute(true, doc);

    if (doc && selectablesSet)
        doc->GetSelection().Set(UndoSelectables);
}

void UndoRedo::RecordStandardSelectables(DocumentBase* doc)
{
    if (doc)
    {
        RedoSelectables = UndoSelectables = doc->GetSelection();
        selectablesSet = true;
    }
}

FunctionalUndoRedo::FunctionalUndoRedo(const Urho3D::String& text, std::function<void()> perform, std::function<void()> reverse) :
    text_(text),
    perform_(perform),
    reverse_(reverse)
{

}

void FunctionalUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    if (isUndo)
        reverse_();
    else
        perform_();
}

std::shared_ptr<UndoRedo> UndoStack::GetLatest()
{
    if (undo_.empty())
        return std::shared_ptr<UndoRedo>();
    return undo_.back();
}

std::shared_ptr<UndoRedo> UndoStack::PushNew(std::shared_ptr<UndoRedo> act)
{
    doc_->MarkDirty();
    if (act->IsDead())
    {
        act->Redo(doc_);
        return nullptr;
    }

    redo_.clear();
    if (!undo_.empty() && undo_.back()->CanMergeWith(act.get()))
    {
        undo_.back()->Merge(act.get());
        act->Redo(doc_);
        return undo_.back();
    }
    act->Redo(doc_);
    undo_.push_back(act);
    while (undo_.size() > 256)
        undo_.erase(undo_.begin());

    return act;
}

void UndoStack::Clear()
{
    undo_.clear();
    redo_.clear();
}

void UndoStack::Undo()
{
    if (undo_.size() > 0)
    {
        doc_->MarkDirty();
        undo_.back()->Undo(doc_);
        redo_.push_back(undo_.back());
        undo_.pop_back();
    }
}

void UndoStack::Redo()
{
    if (redo_.size() > 0)
    {
        doc_->MarkDirty();
        redo_.back()->Redo(doc_);
        undo_.push_back(redo_.back());
        redo_.pop_back();
    }
}

void UndoStack::UndoUntil(std::shared_ptr<UndoRedo> act)
{
    while (undo_.empty() && undo_.back() != act)
        Undo();
    if (!undo_.empty())
        Undo();
}

void UndoStack::RedoUntil(std::shared_ptr<UndoRedo> act)
{
    while (redo_.empty() && redo_.back() != act)
        Redo();
    if (!redo_.empty())
        Redo();
}

MultiUndoRedo::MultiUndoRedo(const Urho3D::String& text, const std::vector<std::shared_ptr<UndoRedo> >& actions)
{
    actions_ = actions;
    text_ = text;
}

void MultiUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    for (auto u : actions_)
    {
        if (isUndo)
            u->Undo(forDoc);
        else
            u->Redo(forDoc);
    }
}

bool MultiUndoRedo::CanMergeWith(UndoRedo* rhs) const
{
    if (auto other = dynamic_cast<MultiUndoRedo*>(rhs))
    {
        bool okay = true;
        if (actions_.size() != other->actions_.size())
            return false;
        for (size_t i = 0; i < actions_.size(); ++i)
            okay &= actions_[i]->CanMergeWith(other->actions_[i].get());
        return okay;
    }
    return false;
}

void MultiUndoRedo::Merge(UndoRedo* rhs)
{
    if (auto other = dynamic_cast<MultiUndoRedo*>(rhs))
    {
        for (size_t i = 0; i < actions_.size(); ++i)
            actions_[i]->Merge(other->actions_[i].get());
        text_ = other->text_;
    }
}

void IQuickActionSource::FilterActions(ActionList& list)
{
    ActionList newList;
    newList.reserve(list.size());
    for (size_t i = 0; i < list.size(); ++i)
    {
        if (list[i]->IsAvailable() && !list[i]->hidden_)
            newList.push_back(list[i]);
    }
    list = newList;
}