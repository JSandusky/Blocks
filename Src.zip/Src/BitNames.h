#pragma once

#include <string>
#include <unordered_map>

struct BitNames
{
    std::string setName_;
    std::string bits_[32];
};

class BitNamesTable
{
public:
    BitNamesTable();
    ~BitNamesTable();

    void Save();

    BitNames* GetBitNames(const std::string& name);
    void DrawEditor();

private:
    std::unordered_map<std::string, BitNames*> names_;
};