#include "GUI_Data.h"

#include <Urho3D/Container/RefCounted.h>
#include <Urho3D/Container/Ptr.h>
#include <Urho3D/Container/VectorBase.h>
#include <Urho3D/UI/ImGuiElement.h>

#include "Block.h"

#include <Urho3D/DebugNew.h>

EditorShortCut::EditorShortCut()
{

}

EditorShortCut::EditorShortCut(const Urho3D::String& path)
{
    SetFromString(path);
}

void EditorShortCut::SetFromString(const Urho3D::String& path)
{
    if (path.Contains("CTRL"))
        control_ = true;
    if (path.Contains("ALT"))
        alt_ = true;
    if (path.Contains("SHIFT"))
        shift_ = true;

    unsigned index = path.FindLast('+');
    String parseString = path;
    if (index == Urho3D::String::NPOS)
        parseString = path.Substring(index + 1);

    parseString = parseString.Trimmed();
    auto input = BlockExe::GetInst()->GetContext()->GetSubsystem<Input>();
    keyCode_ = input->GetKeyFromName(parseString);
}

void EditorShortCut::Reset()
{
    keyCode_ = -1;
    control_ = alt_ = shift_ = false;
}

bool EditorShortCut::Check() const
{
    auto input = BlockExe::GetInst()->GetContext()->GetSubsystem<Input>();
    if (keyCode_ != -1)
    {
        bool okay = input->GetKeyPress(keyCode_);
        if (shift_)
            okay &= (input->GetKeyDown(KEY_LSHIFT) || input->GetKeyDown(KEY_RSHIFT) || input->GetKeyDown(KEY_SHIFT));
        if (control_)
            okay &= (input->GetKeyDown(KEY_LCTRL) || input->GetKeyDown(KEY_RCTRL) || input->GetKeyDown(KEY_CTRL));
        if (alt_)
            okay &= input->GetKeyDown(KEY_MENU);
        return okay;
    }
    return false;
}

Urho3D::String EditorShortCut::GetText() const
{
    auto input = BlockExe::GetInst()->GetContext()->GetSubsystem<Input>();
    String baseString = input->GetKeyName(keyCode_);
    if (alt_)
        baseString = "ALT + " + baseString;
    if (shift_)
        baseString = "SHIFT + " + baseString;
    if (control_)
        baseString = "CTRL + " + baseString;
    return baseString;
}

bool EditorShortCut::operator==(const EditorShortCut& rhs) const
{
    return alt_ == rhs.alt_ && control_ == rhs.control_ && shift_ == rhs.shift_ && keyCode_ == rhs.keyCode_;
}