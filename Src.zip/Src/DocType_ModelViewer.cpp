#include "DocType_ModelViewer.h"

#include <Urho3D/Graphics/AnimatedModel.h>
#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/Graphics/Geometry.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Graphics/Material.h>
#include <Urho3D/Graphics/Model.h>
#include <Urho3D/Scene/Node.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Audio/SoundListener.h>
#include <Urho3D/Math/Sphere.h>
#include <Urho3D/Graphics/StaticModel.h>

#include <Urho3D/ThirdParty/ImGui/imgui_ext.h>

#include "Block.h"
#include "DataObject.h"
#include "GUI_Pane3D.h"
#include "Urho_AttrEdit.h"
#include "Urho_Util.h"
#include "UX.h"

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

extern void SetupTestScene(Urho3D::SharedPtr<Urho3D::Scene> scene, Urho3D::SharedPtr<Urho3D::Node> camNode);

ModelViewerDocumentType::ModelViewerDocumentType() : DocumentType("Model", "Model (*.mdl)|*.mdl")
{

}

std::shared_ptr<DocumentBase> ModelViewerDocumentType::OpenPath(const Urho3D::String& path)
{
    return std::make_shared<ModelViewerDocument>(BlockExe::GetInst()->GetContext(), path);
}

class GUI_ModelViewerView : public GUI_View3D
{
public:
    ModelViewerDocument* doc_;

    GUI_ModelViewerView(Document3D::View* v) :
        GUI_View3D(v)
    {
        doc_ = dynamic_cast<ModelViewerDocument*>(v->doc_);
    }

    ~GUI_ModelViewerView()
    {
        doc_ = 0x0;
    }

    GUI_PaneView* Clone()
    {
        auto camClone = view_->cameraNode_->Clone();
        camClone->SetTemporary(true);
        auto v = new Document3D::View(view_->doc_, SharedPtr<Node>(camClone));
        return new GUI_ModelViewerView(v);
    }

    virtual void Draw(const Urho3D::IntRect& r) override {
        ImGui::PushID(doc_);

        auto winPos = ImGui::GetWindowPos();
        auto winSize = ImGui::GetWindowSize();
        const bool isActive = IsActive();

        GUI_View3D::Draw(r);

        auto boldFont = ImGui::GetIO().Fonts->Fonts[3];
        ImGui::PushFont(boldFont);

        ImGui::SetCursorPos(ImVec2(20, 20));
        
        ImGui::BeginGroup();
        ImGui::Checkbox("Show Skeleton", &doc_->drawSkeleton_);
        ImGui::Checkbox("Show Spheres", &doc_->drawBoneSphere_);
        ImGui::Checkbox("Show Boxes", &doc_->drawBoneBox_);
        ImGui::Checkbox("Solid Volumes", &doc_->depthTestVolume_);
        ImGui::EndGroup();

        ImGui::PopFont();

        ImGui::PopID();
    }
};

ModelViewerDocument::ModelViewerDocument(Context* ctx, const Urho3D::String& path) :
    Document3D(ctx, SharedPtr<Scene>(new Scene(ctx)))
{
    wantNodeIcons_ = false;
    filePath_ = path.CString();
    name_ = GetFileName(path).CString();

    auto cache = GetSubsystem<ResourceCache>();
    modelData_ = new Model(GetContext());
    modelData_->LoadFile(path);

    SharedPtr<Node> cameraNode(scene_->CreateChild("##camera"));
    cameraNode->SetTemporary(true);
    cameraNode->CreateComponent<Camera>();
    cameraNode->CreateComponent<SoundListener>();

    if (!LoadEditorScene(scene_, "ModelViewer.xml"))
        SetupTestScene(scene_, cameraNode);

    cameraNode->SetPosition(Vector3(0, 2, -8));
    cameraNode->LookAt(Vector3(0, 0, 0));

    modelNode_ = scene_->CreateChild("Model Node");
    modelNode_->SetTemporary(true);
    modelComp_ = modelNode_->CreateComponent<AnimatedModel>();
    modelComp_->SetModel(modelData_);
    material_ = new Material(GetContext());
    modelComp_->SetMaterial(material_);

    guiViews_->topViews_.push_back(new GUI_ModelViewerView(new View(this, cameraNode)));
}

ModelViewerDocument::~ModelViewerDocument()
{

}

bool ModelViewerDocument::Save()
{
    if (filePath_.empty())
    {
        auto fileName = GetSaveFile_PairName("Save Model", "*.mdl", "Model (*.mdl)|*.mdl");

        if (!fileName.first.empty())
        {
            filePath_ = fileName.first;
            name_ = fileName.second;
        }
        else
            return false;
    }

    modelData_->SaveFile(filePath_.c_str());
    ClearDirty();
    return true;
}

void ModelViewerDocument::SaveAs()
{
    auto oldFilePath = filePath_;
    filePath_.clear();
    if (Save())
    {

    }
    else
        filePath_ = oldFilePath; // if save fails then revert path
}

bool ModelViewerDocument::Close()
{
    Document3D::Close();
    scene_.Reset();
    return false;
}

void ModelViewerDocument::PreDraw()
{
    if (!scene_)
        return;
    UpdateNodeIcons();
    auto debugRen = GetScene()->GetOrCreateComponent<DebugRenderer>();
    DrawGrid_3D(debugRen, Vector3(0, 0, 0));
    debugRen->AddLine(Vector3(0, 0.01f, 0), Vector3(5, 0.01f, 0), Color::RED);
    debugRen->AddLine(Vector3(0, 0.01f, 0), Vector3(0, 0.01f, 5), Color::BLUE);
    if (modelData_ && modelComp_)
    {
        if (drawSkeleton_)
            debugRen->AddSkeleton(modelComp_->GetSkeleton(), Color::YELLOW, false);
        
        auto& skel = modelComp_->GetSkeleton();
        for (size_t i = 0; i < skel.GetNumBones(); ++i)
        {
            auto bone = skel.GetBone(i);
            if (!bone->node_)
                continue;

            static Color notSelectedBone = Color(Color::BLUE, 0.75f);
            static Color selectedSolid = Color(Color::MAGENTA, 0.75f);
            if (bone->collisionMask_ & 0x1 && bone->radius_ > 0 && 
                ((drawBoneSphere_ && selectedBoneIndex_ == -1) || (drawBoneSphere_ && selectedBoneIndex_ == i)))
            {
                debugRen->AddSphere(Urho3D::Sphere(bone->node_->GetWorldPosition(), bone->radius_), selectedBoneIndex_ == i ? Color::MAGENTA : notSelectedBone, false);
            }
            if (bone->collisionMask_ & 0x2 && bone->boundingBox_.Defined() && 
                ((drawBoneBox_ && selectedBoneIndex_ == -1) || (drawBoneBox_ && selectedBoneIndex_ == i)))
            {
                if (depthTestVolume_)
                    debugRen->AddBoundingBox(bone->boundingBox_, bone->node_->GetWorldTransform(), selectedBoneIndex_ == i ? selectedSolid : notSelectedBone, true, true);
                else
                    debugRen->AddBoundingBox(bone->boundingBox_, bone->node_->GetWorldTransform(), selectedBoneIndex_ == i ? Color::MAGENTA : notSelectedBone, false);
            }
        }
    }
}

void ModelViewerDocument::DrawProperties(ImGuiTextFilter* filter)
{
    if (modelData_)
    {
        ResourceRef previewRes(StringHash("Material"), material_->GetName().Replaced("//", "/"));

        EditAttribute(scene_.Get(), modelComp_.Get(), "Material", &GetUndoStack());
        ImGui::PopID();

        if (ImGui::CollapsingHeader("Metrics"))
        {
            IndentScope indent;

            ImGui::Text("Geometrys: %u", modelData_->GetNumGeometries());
            ImGui::Text("Morphs: %u", modelData_->GetNumMorphs());

            unsigned triCt = 0;
            unsigned vertCt = 0;
            for (auto g : modelData_->GetGeometries())
            {
                if (g.Size() > 0)
                {
                    triCt += g[0]->GetIndexCount() / 3;
                    vertCt += g[0]->GetVertexCount();
                }
            }

            ImGui::Text("Triangles: %u", triCt);
            ImGui::Text("Vertices: %u", vertCt);
        }

        if (ImGui::CollapsingHeader("Geometries"))
        {
            ImGui::PushID("GEOMETRIES");
            for (size_t i = 0; i < modelData_->GetNumGeometries(); ++i)
            {
                if (ImGui::TreeNode((void*)(i + 1), "Geom %u", i))
                {
                    auto& lods = modelData_->GetGeometries()[i];
                    for (size_t lod = 0; lod < lods.Size(); ++lod)
                    {
                        auto& g = lods[lod];
                        if (ImGui::TreeNode((void*)(lod + 1), "LOD %u", lod))
                        {
                            ImGui::Text("Triangles: %u", g->GetIndexCount() / 3);
                            ImGui::Text("Vertices: %u", g->GetVertexCount());
                            float lodDist = g->GetLodDistance();
                            if (ImGui::DragFloat("Distance", &lodDist))
                            {
                                g->SetLodDistance(lodDist);
                                MarkDirty();
                            }
                            ImGui::TreePop();
                        }
                    }
                    ImGui::TreePop();
                }
            }
            ImGui::PopID();
        }

        auto& skeleton = modelData_->GetSkeleton();
        if (ImGui::CollapsingHeader("Skeleton"))
        {
            IndentScope indent;

            if (skeleton.GetNumBones() == 0)
            {
                ImGui::Text("< no skeleton >");
            }
            else
            {
                ImGui::Text("    %u Bones", skeleton.GetNumBones());

                auto PrintBone = [=](Urho3D::Skeleton& skel, Urho3D::Bone* bone, unsigned idx) {
                    ImGui::PushID(bone);
                    bool isSelected = idx == selectedBoneIndex_;
                    bool wasSelected = isSelected;
                    ImGui::Selectable(bone->name_.CString(), &isSelected, ImGuiSelectableFlags_AllowDoubleClick);
                    if (wasSelected != isSelected)
                    {
                        if (isSelected)
                            selectedBoneIndex_ = idx;
                        else
                            selectedBoneIndex_ = -1;
                    }
                    ImGui::PopID();
                };

                float w = ImGui::GetContentRegionAvailWidth() / 2;
                ImGui::PushItemWidth(w);

                ImGui::BeginChild("Bones", ImVec2(w, 0), true);
                for (size_t i = 0; i < skeleton.GetNumBones(); ++i)
                {
                    auto bone = skeleton.GetBone(i);
                    PrintBone(skeleton, bone, i);
                }
                ImGui::EndChild();

                if (selectedBoneIndex_ != -1)
                {
                    ImGui::SameLine();
                    ImGui::BeginChild("Selected Bone", ImVec2(w, 0), true);
                    auto bone = skeleton.GetBone(selectedBoneIndex_);

                    ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());
                    ImGui::Text("Name");
                    if (ImGuiElement::EditString("##bone_name", bone->name_))
                    {
                        modelComp_->GetSkeleton().GetBone(selectedBoneIndex_)->name_ = bone->name_;
                        modelComp_->GetSkeleton().GetBone(selectedBoneIndex_)->nameHash_ = bone->nameHash_ = StringHash(bone->name_);
                        MarkDirty();
                    }
                                        
                    unsigned boneColMask = bone->collisionMask_;
                    bool enableSphere = boneColMask & 0x1;
                    bool enableBox = boneColMask & 0x2;
                    if (ImGui::Checkbox("Enable Sphere Collision", &enableSphere))
                    {
                        if (enableSphere)
                            boneColMask |= 0x1;
                        else
                            boneColMask &= ~(0x1);
                        modelComp_->GetSkeleton().GetBone(selectedBoneIndex_)->collisionMask_ = bone->collisionMask_ = boneColMask;
                        MarkDirty();
                    }
                    if (ImGui::Checkbox("Enable Box Collision", &enableBox))
                    {
                        if (enableBox)
                            boneColMask |= 0x2;
                        else
                            boneColMask &= ~(0x2);
                        modelComp_->GetSkeleton().GetBone(selectedBoneIndex_)->collisionMask_ = bone->collisionMask_ = boneColMask;
                        MarkDirty();
                    }

                    ImGui::Text("Collision Radius");
                    if (ImGui::DragFloat("##radius", &bone->radius_, 0.01f, 0.0f, 9999.0f))
                    {
                        modelComp_->GetSkeleton().GetBone(selectedBoneIndex_)->radius_ = bone->radius_;
                        MarkDirty();
                    }
                    
                    ImGui::Text("Min Collision Bounds");
                    if (ImGui::DragFloatN_Colored("##boxmin", &(bone->boundingBox_.min_).x_, 3, 0.01f))
                    {
                        modelComp_->GetSkeleton().GetBone(selectedBoneIndex_)->boundingBox_.min_ = bone->boundingBox_.min_;
                        MarkDirty();
                    }
                    ImGui::Text("Max Collision Bounds");
                    if (ImGui::DragFloatN_Colored("##boxmax", &(bone->boundingBox_.max_).x_, 3, 0.01f))
                    {
                        modelComp_->GetSkeleton().GetBone(selectedBoneIndex_)->boundingBox_.max_ = bone->boundingBox_.max_;
                        MarkDirty();
                    }

                    ImGui::PopItemWidth();
                    ImGui::EndChild();
                }

                ImGui::PopItemWidth();
            }
        }
    }
}

void ModelViewerDocument::DrawMasterButtons()
{
    ImGuiUX::MenuButton(ICON_FA_SLIDERS_H, "#material_tasks", "Tasks");
    //ImGui::SameLine();
    DrawViewManagementWidgets();

    if (ImGui::BeginPopup("#material_tasks"))
    {
        if (ImGui::MenuItem(ICON_FA_CAMERA " Render Imposters"))
        {
            ModalWindows::Get()->PushModal(ModalWindow(ICON_FA_CAMERA " Render Imposters", []() -> bool {

                extern std::unique_ptr<DataObject> imposterBakeSettings_;

                DataObject::DrawEditor(imposterBakeSettings_.get());

                ImGui::Separator();
                if (ImGui::Button("Bake"))
                {
                    return false;
                }
                return true;
            }));
        }
        ImGui::EndPopup();
    }
}