#pragma once

#include <functional>
#include <memory>
#include <string>
#include <vector>

#include <Urho3D/Core/Context.h>
#include <Urho3D/Math/Rect.h>
#include <Urho3D/Math/Color.h>
#include <Urho3D/Math/Vector4.h>
#include <Urho3D/ThirdParty/ImGui/imgui.h>

struct UIColors {
    static const Urho3D::Color SelectionColor;
    static const Urho3D::Color PassiveColor;
    static const Urho3D::Color XColor;
    static const Urho3D::Color YColor;
    static const Urho3D::Color ZColor;
    static const Urho3D::Color XColor_Dim;
    static const Urho3D::Color YColor_Dim;
    static const Urho3D::Color ZColor_Dim;
};

enum EditorSystemValues
{
    ESV_FogColor,
    ESV_RenderPath,
    ESV_2DMode,
    
    ESV_ShadowQuality,
    ESV_ShadowResolution,
    ESV_HDR,
    ESV_TextureQuality,
    ESV_MaterialQuality,
    
    ESV_ShowGrid3D,
    ESV_GridSize,
    ESV_GridSubdivisions,
    ESV_GridScale
};

struct IndentScope
{
    IndentScope() {
        ImGui::Indent();
    }
    ~IndentScope()
    {
        ImGui::Unindent();
    }
};

struct WidthIndentScope
{
    WidthIndentScope() {
        ImGui::Indent();
        ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());
    }
    ~WidthIndentScope()
    {
        ImGui::PopItemWidth();
        ImGui::Unindent();
    }
};

struct ImTheSame {
    int id_ = -1;

    bool IsSame();
    void Mark();
};

inline ImVec4 ToImVec4(const Urho3D::Vector4& r) {
    return ImVec4(r.x_, r.y_, r.z_, r.w_);
}

inline ImVec4 ToImVec4(const Urho3D::Rect& r) {
    return ImVec4(r.Left(), r.Top(), r.Right(), r.Bottom());
}

inline ImVec4 ToImVec4(const Urho3D::IntRect& r) {
    return ImVec4(r.left_, r.top_, r.right_, r.bottom_);
}

intptr_t GetEditorIconTexture();
ImVec4 GetEditorIconUV(const Urho3D::String& icon);

namespace ImGuiUX
{
    void StandardPopupChecks();
    bool MenuButton(const char* text, const char* menuID, const char* tip);
    bool ToggleButton(const char* text, bool state);
    bool ToggleMenuButton(const char* text, const char* menuID, const char* tip, bool state);
    bool ButtonedText(const char* text, const char* buttonText);

    void PushBold();
    void PopBold();
    void PushLargeBold();
    void PopLargeBold();

    bool AutoMenu(const char* txt);
    bool AutoMenu(const char* txt, const char* shortCut);
    void CheckAutoSeparator();
    void AutoSeparator();
    void EndAutoMenu();
}

struct ErrorButton
{
    std::string text_;
    std::function<void()> call_;
};

struct ErrorMessage
{
    std::string title_ = "Error";
    std::string message_;
    std::vector<ErrorButton> buttons_;

    ErrorMessage(const std::string& msg);
    ErrorMessage(const std::string& msg, const std::string& title);
    ErrorMessage(const std::string& msg, const std::string& title, const std::vector<ErrorButton>& buttons);
};

struct ModalWindow
{
    std::function<bool()> windowFunction_;
    std::string title_;
    
    ModalWindow(const std::string& msg, std::function<bool()> windowFunc);
};

class ModalWindows
{
public:
    void Run();

    void Push(const ErrorMessage& msg);
    void PushModal(const ModalWindow& win);
    void PushTool(const ModalWindow& win);

    static ModalWindows* Get();

private:
    static std::unique_ptr<ModalWindows> inst_;

    std::vector<ErrorMessage> messages_;
    std::vector<ModalWindow> nonModals_;
    std::vector<ModalWindow> windows_;
};

class IMouseCapture
{
public:
    virtual bool ProcessKeys() { return true; }
    virtual bool ProcessCapture(const Urho3D::IntVector2& pos, const Urho3D::IntVector2& delta) = 0;
    virtual void EndCapture() { }
};

class MouseCapture
{
public:
    static void Capture(IMouseCapture* cap, int forButton);
    static bool Process(const Urho3D::IntVector2& pos, const Urho3D::IntVector2& delta);
    static bool ProcessKeys();

    static MouseCapture* Get();

    bool CheckDeactivation(int button) { return button == capturedButton_; }
    void Deactivate();
    void SetContext(Urho3D::Context* ctx) { context_ = ctx; }

    IMouseCapture* GetActive() { return active_; }

private:
    static std::unique_ptr<MouseCapture> inst_;
    IMouseCapture* active_ = nullptr;
    Urho3D::Context* context_;
    int capturedButton_ = 0;
};

template<typename T, typename K>
std::vector<std::shared_ptr<T> > CastVector(const std::vector<std::shared_ptr<K> >& src)
{
    std::vector<std::shared_ptr<T> > ret;
    for (auto c : src)
        if (auto d = std::dynamic_pointer_cast<T>(c))
            ret.push_back(d);
    return ret;
}

void ShowQuickAction(bool shouldOpen);