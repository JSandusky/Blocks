#include "DocType_Scene.h"

#include <Urho3D/Audio/Audio.h>
#include <Urho3D/Math/BoundingBox.h>
#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/Graphics/Graphics.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Input/Input.h>
#include <Urho3D/Input/InputEvents.h>
#include <Urho3D/IO/Log.h>
#include <Urho3D/Graphics/Light.h>
#include <Urho3D/Graphics/Material.h>
#include <Urho3D/Graphics/Model.h>
#include <Urho3D/Scene/Node.h>
#include <Urho3D/Graphics/Octree.h>
#include <Urho3D/Graphics/ParticleEffect.h>
#include <Urho3D/Graphics/ParticleEmitter.h>
#include <Urho3D/Graphics/RenderSurface.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Scene/Scene.h>
#include <Urho3D/Audio/Sound.h>
#include <Urho3D/Audio/SoundListener.h>
#include <Urho3D/Audio/SoundSource3D.h>
#include <Urho3D/Scene/SplinePath.h>
#include <Urho3D/Graphics/StaticModel.h>
#include <Urho3D/Graphics/StaticModelGroup.h>
#include <Urho3D/Resource/XMLElement.h>
#include <Urho3D/Resource/XMLFile.h>
#include <Urho3D/Graphics/Zone.h>

// includes for task functions
#include <Urho3D/Navigation/NavigationMesh.h>

#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>
#include <Urho3D/ThirdParty/ImGui/ImGuizmo.h>
#include <Urho3D/ThirdParty/ImGui/imgui_ext.h>

#include "Block.h"
#include "Clipboard.h"
#include "DataObject.h"
#include "DocType_CommonActions.h"
#include "Doc_SelectableAction.h"
#include "GUI_Pane3D.h"
#include "Urho_Undo.h"
#include "Urho_Util.h"
#include "UX.h"

#ifdef WIN32
#include <Windows.h>
#include <Commdlg.h>
#include <tchar.h>
#endif

#include <algorithm>

#include <Urho3D/DebugNew.h>

#define EDITOR_CAMERA_NAME "Editor Camera"

extern bool IsShiftDown();

using namespace Urho3D;

extern std::unique_ptr<DataObject> gizmoSettings_;
extern std::unique_ptr<DataObject> viewportSettings_;

static Vector3 sceneView_RayHit = Vector3(0,0,0);

void SetupTestScene(Urho3D::SharedPtr<Urho3D::Scene> scene, Urho3D::SharedPtr<Urho3D::Node> camNode)
{
    auto cache = scene->GetContext()->GetSubsystem<ResourceCache>();

    // Create octree, use also default volume (-1000, -1000, -1000) to (1000, 1000, 1000)
    scene->CreateComponent<Octree>();

    // Create a Zone component for ambient lighting & fog control
    Node* zoneNode = scene->CreateChild("Zone");
    auto* zone = zoneNode->CreateComponent<Zone>();
    zone->SetBoundingBox(Urho3D::BoundingBox(-1000.0f, 1000.0f));
    zone->SetAmbientColor(Color(0.2f, 0.2f, 0.2f));
    zone->SetFogColor(Color(0.39f, 0.39f, 1.0f));
    zone->SetFogStart(100.0f);
    zone->SetFogEnd(300.0f);

    // Create a directional light without shadows
    Node* lightNode = scene->CreateChild("DirectionalLight");
    lightNode->SetDirection(Vector3(0.5f, -1.0f, 0.5f));
    auto* light = lightNode->CreateComponent<Light>();
    light->SetLightType(LIGHT_DIRECTIONAL);
    light->SetColor(Color(0.2f, 0.2f, 0.2f));
    light->SetSpecularIntensity(1.0f);
}

#define ACTION_REBUILD_NAVIGATION_MESHES ICON_FA_MAP_MARKER " Rebuild Navigation Meshes"
#define ACTION_FILL_STATIC_MODEL_GROUP "Add Children to Static-Model Group"
#define ACTION_FILL_SPLINE "Add Children to Spline"
#define ACTION_UPDATE_PREFABS ICON_FA_SYNC " Update Prefabs"
#define ACTION_BAKE_CUBEMAPS ICON_FA_LIGHTBULB ICON_FA_GLOBE " Bake Environment Cubemaps"
#define ACTION_EXPORT_OBJ ICON_FA_DOWNLOAD " Export Selected to OBJ"
AppAction* Action_RebuildNavMeshes;
AppAction* Action_AddChildrenToStaticModel;
AppAction* Action_AddChildrenToSpline;
AppAction* Action_UpdatePrefabs;
AppAction* Action_BakeCubes;
AppAction* Action_ExportOBJ;

SceneDocumentType::SceneDocumentType() : DocumentType("Scene", "Scene (*.xml, *.bin)|*.xml;*.bin")
{
    AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", "Move Up", "Moves the current object upwards")));
    AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", "Move Down", "Moves the current object downwards")));

    Action_RebuildNavMeshes = (AppAction*)AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", ACTION_REBUILD_NAVIGATION_MESHES, "Regenerates navigation geometry for pathfinding")));
    Action_AddChildrenToStaticModel = (AppAction*)AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", ACTION_FILL_STATIC_MODEL_GROUP, "Adds all children of the selected node to its Static-Model Group component")));
    Action_AddChildrenToSpline = (AppAction*)AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", ACTION_FILL_SPLINE, "Adds all children of the selected node to its spline component")));
    Action_UpdatePrefabs = (AppAction*)AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", ACTION_UPDATE_PREFABS, "Updates all prefabs in the scene")));

    Action_BakeCubes = (AppAction*)AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", ACTION_BAKE_CUBEMAPS, "Renders cubemaps for selected zones")));
    Action_ExportOBJ = (AppAction*)AddAction(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", ACTION_EXPORT_OBJ, "Exports selected objects to an OBJ model")));
}

std::shared_ptr<DocumentBase> SceneDocumentType::NewDocument()
{
    return std::make_shared<SceneDocument>(BlockExe::GetInst()->GetContext());
}

std::shared_ptr<DocumentBase> SceneDocumentType::OpenPath(const Urho3D::String& path)
{
    return std::make_shared<SceneDocument>(BlockExe::GetInst()->GetContext(), path);
}

void SceneDocument::CommonConstruct()
{
    SubscribeToEvent("EDITOR_SELECTION_CHANGED", URHO3D_HANDLER(SceneDocument, OnSelectionChanged));
    auto ctx = BlockExe::GetInst()->GetContext();

    scene_ = SharedPtr<Scene>(new Scene(ctx));
    captureData_.reset(new CapturingData());
    captureData_->scene_ = scene_;

    SharedPtr<Node> cameraNode = SharedPtr<Node>(scene_->CreateChild(EDITOR_CAMERA_NAME));
    cameraNode->SetTemporary(true);
    auto camera = cameraNode->CreateComponent<Camera>();
    cameraNode->GetSubsystem<Audio>()->SetListener(cameraNode->CreateComponent<SoundListener>());

    SetupTestScene(scene_, cameraNode);

    guiViews_->topViews_.push_back(new GUI_SceneView3D(new View(this, cameraNode)));

    SubscribeToEvent(E_BINDINGTRIGGERED, URHO3D_HANDLER(SceneDocument, OnBindingAction));
}

void SceneDocument::OnBindingAction(Urho3D::StringHash, Urho3D::VariantMap& data)
{
    if (!IsActive())
        return;

    String action = data[BindingTriggered::P_ACTION].GetString();
    if (action == "Move Up")
    {
        for (auto sel : GetSelection().GetAll<UrhoNodeSelectable>())
            sel->node_->SetWorldPosition(sel->node_->GetWorldPosition() + Vector3(0, 2, 0));
    }
    else if (action == "Move Down")
    {
        for (auto sel : GetSelection().GetAll<UrhoNodeSelectable>())
            sel->node_->SetWorldPosition(sel->node_->GetWorldPosition() + Vector3(0, -2, 0));
    }
    if (action == ACTION_REBUILD_NAVIGATION_MESHES)
    {
        BakeNavigation();
    }
    if (action == ACTION_FILL_STATIC_MODEL_GROUP)
    {
        if (auto nodeSel = GetSelection().MostRecent<UrhoNodeSelectable>())
        {
            if (auto smg = nodeSel->node_->GetComponent<StaticModelGroup>())
            {
                smg->RemoveAllInstanceNodes();
                auto children = nodeSel->node_->GetChildren();
                for (auto child : children)
                    smg->AddInstanceNode(child);
            }
        }
    }
    if (action == ACTION_FILL_SPLINE)
    {
        if (auto nodeSel = GetSelection().MostRecent<UrhoNodeSelectable>())
        {
            if (auto spline = nodeSel->node_->GetComponent<SplinePath>())
            {
                auto children = nodeSel->node_->GetChildren();
                spline->ClearControlPoints();
                for (auto child : children)
                    spline->AddControlPoint(child);
            }
        }
    }
    if (action == ACTION_UPDATE_PREFABS)
    {
        Visit(SharedPtr<Node>(scene_.Get()), [](SharedPtr<Node> nd) {
            ReloadNodePrefab(nd);
        });
    }
    if (action == ACTION_BAKE_CUBEMAPS)
        BakeCubemaps();
    if (action == ACTION_EXPORT_OBJ)
    {
        ModalWindows::Get()->PushModal(ModalWindow(ICON_FA_DOWNLOAD " Export Selected to OBJ", [=]()->bool {
            extern std::unique_ptr<DataObject> secretApplicationSettings_;

            bool selectedOnly = secretApplicationSettings_->GetField("OBJ Selected Drawables Only").GetBool();
            bool rightHanded = secretApplicationSettings_->GetField("OBJ Right Handed").GetBool();
            bool zUp = secretApplicationSettings_->GetField("OBJ Z Up").GetBool();

            if (ImGui::Checkbox("Selection Only", &selectedOnly))
                secretApplicationSettings_->SetField("OBJ Selected Drawables Only", selectedOnly);
            if (ImGui::Checkbox("Right-handed Coordinates", &rightHanded))
                secretApplicationSettings_->SetField("OBJ Right Handed", selectedOnly);
            if (ImGui::Checkbox("Z Axis Up", &zUp))
                secretApplicationSettings_->SetField("OBJ Z Up", zUp);

            ImGui::Separator();
            if (ImGui::Button("Export"))
            {
                PODVector<Drawable*> drawables;
                scene_->GetDerivedComponents<Drawable>(drawables, true);
                if (selectedOnly)
                {
                    if (!GetSelection().empty())
                    {
                        auto cast = CastVector<UrhoNodeSelectable>(GetSelection());
                        auto toNodeVec = ToNodeVector(cast);
                        for (size_t i = 0; i < drawables.Size(); ++i)
                        {
                            if (std::find(toNodeVec.begin(), toNodeVec.end(), SharedPtr<Node>(drawables[i]->GetNode())) == toNodeVec.end())
                            {
                                drawables.Erase(i);
                                --i;
                            }
                        }
                    }
                }

                if (drawables.Empty())
                {
                    ModalWindows::Get()->Push(ErrorMessage("There are no drawables to export", "Cannot Perform", { { "Close" } }));
                    return false;
                }

                if (drawables.Size() > 0)
                {
                    auto path = GetSaveFile("Save OBJ Model", "*.obj", "Wavefront OBJ (*.obj)|*.obj");
                    if (!path.empty())
                    {
                        SharedPtr<File> file(new File(GetContext(), path.c_str(), FILE_WRITE));
                        WriteDrawablesToOBJ(drawables, file, zUp, rightHanded);
                        return false;
                    }
                }
            }
            return true;
        }));
    }
}

SceneDocument::SceneDocument(Context* ctx) :
    Document3D(ctx, 0x0)
{
    CommonConstruct();
    scene_->SetUpdateEnabled(false);
    auto cache = scene_->GetContext()->GetSubsystem<ResourceCache>();

    // Create a "floor" consisting of several tiles
    for (int y = -1; y <= 1; ++y)
    {
        for (int x = -1; x <= 1; ++x)
        {
            Node* floorNode = scene_->CreateChild("FloorTile");
            floorNode->SetPosition(Vector3(x * 20.5f, -0.5f, y * 20.5f));
            floorNode->SetScale(Vector3(20.0f, 1.0f, 20.f));
            auto* floorObject = floorNode->CreateComponent<StaticModel>();
            floorObject->SetModel(cache->GetResource<Model>("Models/Box.mdl"));
            floorObject->SetMaterial(cache->GetResource<Material>("Materials/Stone.xml"));
        }
    }
}

SceneDocument::SceneDocument(Context* ctx, const Urho3D::String& path) :
    Document3D(ctx, 0x0)
{
    filePath_ = path.CString();
    name_ = Urho3D::GetFileNameAndExtension(path).CString();
    CommonConstruct();
    scene_->SetUpdateEnabled(false);
    auto cache = scene_->GetSubsystem<ResourceCache>();
    if (auto xmlFile = cache->GetResource<XMLFile>(path))
    {
        if (xmlFile->GetRoot("node").NotNull())
        {
            wantNodeIcons_ = false;
            isPrefab_ = true;
            prefabNode_ = SharedPtr<Node>(scene_->CreateTemporaryChild());
            prefabNode_->LoadXML(xmlFile->GetRoot());
        }
        else
        {
            scene_->Clear();
            scene_->LoadXML(xmlFile->GetRoot());
        }

        if (auto ex = scene_->GetChild(EDITOR_CAMERA_NAME))
            ex->Remove();
        SharedPtr<Node> cameraNode = SharedPtr<Node>(scene_->CreateChild(EDITOR_CAMERA_NAME));
        cameraNode->SetTemporary(true);
        auto camera = cameraNode->CreateComponent<Camera>();
        cameraNode->GetSubsystem<Audio>()->SetListener(cameraNode->CreateComponent<SoundListener>());

        if (auto v = dynamic_cast<GUI_View3D*>(this->GetViewManager()->GetFirstView()))
        {
            v->view_->cameraNode_ = cameraNode;
            v->view_->viewport_->SetCamera(camera);
        }
    }
}

SceneDocument::~SceneDocument()
{
    scene_.Reset();
}

bool SceneDocument::Save()
{
    if (name_ == "< new document >" || filePath_.empty())
    {
#if WIN32
        OPENFILENAMEA saveFileStruct;
        memset(&saveFileStruct, 0, sizeof(OPENFILENAMEA));
        static char sz[MAX_PATH];
        memset(sz, 0, MAX_PATH);

        saveFileStruct.lStructSize = sizeof(saveFileStruct);
        saveFileStruct.lpstrDefExt = "*.xml";
        saveFileStruct.lpstrFile = sz;
        saveFileStruct.lpstrFile[0] = '\0';
        saveFileStruct.nMaxFile = MAX_PATH;
        saveFileStruct.lpstrFilter = "Scene XML Files (*.xml)\0*.xml\0\0";
        saveFileStruct.lpstrTitle = "Save Scene";

        auto result = GetSaveFileName(&saveFileStruct);
        if (saveFileStruct.lpstrFile[0] != '\0')
        {
            std::string fileName = saveFileStruct.lpstrFile;
            filePath_ = fileName;
            size_t lastSlash = fileName.find_last_of('\\');
            size_t dot = fileName.find_last_of('.');

            if (dot == std::string::npos) // no matter what flags are specified it is ALWAYS possible to get a name without an extension if UAC is on max
            {
                filePath_ += ".xml";
                name_ = fileName.substr(lastSlash + 1);
            }
            else
                name_ = fileName.substr(lastSlash + 1, dot - lastSlash - 1);
        }
        else
            return false;
#endif
    }

    CommonSave();

    //??document_->Save(filePath_.c_str());
    //??document_->SaveCooked((filePath_ + "b").c_str());
    ClearDirty();
    return true;
}

void SceneDocument::SaveAs()
{
    auto oldFilename = filePath_;
    filePath_.clear();
    if (Save())
    {
        // do nothing, we'll edit the new file
    }
    else
        filePath_ = oldFilename;
}

void SceneDocument::CommonSave()
{
    SharedPtr<XMLFile> doc(new XMLFile(scene_->GetContext()));

    if (auto v = dynamic_cast<GUI_View3D*>(GetViewManager()->GetFirstView()))
    {
        Image img(GetContext());
        v->view_->surface_->GetImage(img);
        img.Resize(128, 128);
        VectorBuffer buff;
        buff.Write(img.GetData(), img.GetWidth() * img.GetHeight() * sizeof(Color));
        if (isPrefab_ && prefabNode_)
            prefabNode_->SetVar("THUMBNAIL", Variant(buff));
        else
            scene_->SetVar("THUMBNAIL", Variant(buff));
    }

    auto camNode = scene_->GetChild(EDITOR_CAMERA_NAME);
    scene_->RemoveChild(camNode);

    if (isPrefab_ && prefabNode_)
        prefabNode_->SaveXML(doc->GetOrCreateRoot("node"));
    else
        scene_->SaveXML(doc->GetOrCreateRoot("scene"));
    doc->SaveFile(filePath_.c_str());

    scene_->AddChild(camNode);
}

bool SceneDocument::Close()
{
    if (dirty_)
    {
        closing_ = true;
        return false;
    }
    Document3D::Close();
    scene_.Reset();
    return true;
}

bool SceneDocument::CheckMultiGizmo()
{
    bool handled = false;
    bool cloned = false;
    if (GetGizmo())
    {
        if (UrhoGizmo* other = dynamic_cast<UrhoGizmo*>(GetGizmo().get()))
            cloned = other->didClone_;
        else if (MultiGizmo* other = dynamic_cast<MultiGizmo*>(GetGizmo().get()))
            cloned = other->didClone_;
    }
    if (GetSelection().Count() > 1)
    {
        std::vector<std::shared_ptr<UrhoNodeSelectable> > selectables;
        for (auto& sel : GetSelection())
            if (auto uNodeSel = std::dynamic_pointer_cast<UrhoNodeSelectable>(sel))
                selectables.push_back(uNodeSel);

        if (selectables.size() > 0)
        {
            GetGizmo().reset(new MultiGizmo(selectables));
            if (MultiGizmo* other = dynamic_cast<MultiGizmo*>(GetGizmo().get()))
                other->didClone_ = cloned;
            handled = true;
        }
        else if (selectables.size() == 1)
        {
            GetGizmo().reset(new UrhoGizmo(selectables[0]->node_));
            if (UrhoGizmo* other = dynamic_cast<UrhoGizmo*>(GetGizmo().get()))
                other->didClone_ = cloned;
            handled = true;
        }
    }
    else if (GetSelection().Count() == 1)
    {
        SharedPtr<Node> node;
        if (auto& nodeSel = GetSelection().MostRecent<UrhoNodeSelectable>())
            node = nodeSel->node_;
        else if (auto& compSel = GetSelection().MostRecent<UrhoComponentSelectable>())
            node = compSel->component_->GetNode();

        if (node)
        {
            GetGizmo().reset(new UrhoGizmo(node));
            if (UrhoGizmo* other = dynamic_cast<UrhoGizmo*>(GetGizmo().get()))
                other->didClone_ = cloned;
        }
        else
            GetGizmo().reset();
    }
    else
        GetGizmo().reset();
    return handled;
}

GUI_SceneView3D::GUI_SceneView3D(Document3D::View* view) :
    GUI_View3D(view)
{

}

GUI_SceneView3D::~GUI_SceneView3D()
{

}

GUI_PaneView* GUI_SceneView3D::Clone()
{
    auto camClone = view_->cameraNode_->Clone();
    camClone->SetTemporary(true);
    auto v = new Document3D::View(view_->doc_, SharedPtr<Node>(camClone));
    return new GUI_SceneView3D(v);
}

void GUI_SceneView3D::Activate() 
{ 
    GUI_View3D::Activate();
    view_->doc_->GetSubsystem<Audio>()->SetListener(view_->cameraNode_->GetOrCreateComponent<SoundListener>());
}

void GUI_SceneView3D::DoBoxSelect(Urho3D::Frustum f)
{
    auto scene = view_->cameraNode_->GetScene();
    auto octree = scene->GetOrCreateComponent<Octree>();
    PODVector<Drawable*> results;
    FrustumOctreeQuery q(results, f);
    octree->GetDrawables(q);

    if (results.Size() > 0)
    {
        view_->doc_->GetSelection().DeselectAll();
        for (size_t i = 0; i < results.Size(); ++i)
        {
            if (!dynamic_cast<StaticModel*>(results[i]) && !dynamic_cast<ParticleEmitter*>(results[i]))
                continue;
            view_->doc_->GetSelection().AddSelection(std::make_shared<UrhoNodeSelectable>(results[i]->GetNode()));
        }
    }
}

static bool gizmoUsed = false;
void GUI_SceneView3D::Draw(const Urho3D::IntRect& r)
{
    auto doc = dynamic_cast<SceneDocument*>(view_->doc_);
    ImGui::PushID(doc);

    view_->CheckSize(r.Width(), r.Height());

    auto winPos = ImGui::GetWindowPos();
    auto winSize = ImGui::GetWindowSize();
    const bool isActive = IsActive();
    ImGui::SetCursorPos(ImVec2(r.left_, r.top_));

    auto imgSize = ImVec2(r.Width(), r.Height());
    ImGui::Image((ImTextureID)(5000 + view_->viewID_), imgSize);
    auto imgMin = ImGui::GetItemRectMin();
    auto imgMax = ImGui::GetItemRectMax();
    bool imageHovered = ImGui::IsItemHovered();

    Vector3 rayPosition(0, 0, 0);
    Drawable* hitDrawable = 0x0;
    auto rayTest = [&]() {
        // Get a raycast hit for placement
        if (auto octree = doc->scene_->GetOrCreateComponent<Octree>())
        {
            auto mp = ImGui::GetMousePos();
            float fx = (mp.x - winPos.x - r.left_) / ((float)r.Width());
            float fy = (mp.y - winPos.y - r.top_) / ((float)r.Height());
            auto ray = view_->cameraNode_->GetOrCreateComponent<Camera>()->GetScreenRay(fx, fy);

            PODVector<RayQueryResult> result;
            Urho3D::RayOctreeQuery q(result, ray, RAY_TRIANGLE_UV, 50000, DRAWABLE_GEOMETRY);
            octree->Raycast(q);
            while (!result.Empty() && result.Front().node_->GetName().StartsWith("##"))
                result.Erase(0);
            if (result.Size() > 0)
            {
                rayPosition = result[0].position_;
                hitDrawable = result[0].drawable_;

                // If cursor drawing is enabled then draw a cross so it's visible where things are to hit
                if (viewportSettings_->GetField("Draw Cursor Target").GetBool())
                    view_->viewport_->GetScene()->GetComponent<DebugRenderer>()->AddCross(rayPosition, 1.0f, Color::CYAN, false);
            }
        }
        sceneView_RayHit = rayPosition;
    };
    if (imageHovered)
        rayTest();

    if (ImGui::BeginDragDropTarget())
    {
        if (auto payload = ImGui::AcceptDragDropPayload("U_RES"))
        {
            rayTest();
            String resPath((const char*)payload->Data, payload->DataSize);
            auto cache = doc->GetSubsystem<ResourceCache>();

            if (resPath.EndsWith(".xml", false))
            {
                if (auto res = cache->GetResource<XMLFile>(resPath))
                {
                    if (res->GetRoot("node").NotNull())
                    {
                        if (auto newNode = CreateNodeFromFile(doc->scene_, resPath))
                        {
                            newNode->GetScene()->RegisterVar("PREFAB_PATH");
                            newNode->SetVar("PREFAB_PATH", resPath);
                            doc->GetSelection().DeselectAll();
                            doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(newNode));

                            newNode->SetWorldPosition(sceneView_RayHit);
                        }
                    }
                    else if (res->GetRoot("particleeffect").NotNull() || res->GetRoot("particleemitter").NotNull())
                    {
                        if (auto pfx = cache->GetResource<ParticleEffect>(resPath))
                        {
                            auto pfxnode = doc->scene_->CreateChild();
                            pfxnode->GetOrCreateComponent<ParticleEmitter>()->SetEffect(pfx);
                            pfxnode->SetWorldPosition(sceneView_RayHit);
                            doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(pfxnode)));
                        }
                    }
                    else if (res->GetRoot("material").NotNull() && hitDrawable != nullptr)
                    {
                        if (auto mat = cache->GetResource<Material>(resPath))
                        {
                            if (auto model = dynamic_cast<StaticModel*>(hitDrawable))
                                model->SetMaterial(mat);
                        }
                    }
                }
            }
            else if (resPath.EndsWith(".wav"))
            {
                if (auto sfx = cache->GetResource<Sound>(resPath))
                {
                    auto sfxnode = doc->scene_->CreateChild();
                    sfxnode->SetWorldPosition(rayPosition);
                    auto comp = sfxnode->GetOrCreateComponent<SoundSource3D>();
                    comp->Play(sfx);
                    comp->SetGain(1.0f);
                    doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(sfxnode)));
                }
            }
            else if (resPath.EndsWith(".mdl"))
            {
                if (auto mdl = cache->GetResource<Model>(resPath))
                {
                    auto mdlNode = doc->scene_->CreateChild();
                    mdlNode->SetWorldPosition(rayPosition);
                    auto comp = mdlNode->GetOrCreateComponent<StaticModel>();
                    comp->SetModel(mdl);
                    doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(mdlNode)));
                }
            }
        }
        ImGui::EndDragDropTarget();
    }

    if (auto& giz = doc->GetGizmo())
    {
        auto boldFont = ImGui::GetIO().Fonts->Fonts[3];
        ImGui::PushFont(boldFont);

        ImGui::SetCursorPos(ImVec2(20, 15));
        ImGui::BeginGroup();
        if (ImGuiUX::ToggleButton(ICON_FA_MOUSE_POINTER, UrhoGizmo::mode_ == UrhoGizmo::NONE))
            UrhoGizmo::mode_ = UrhoGizmo::NONE;
        ImGui::SameLine();
        if (ImGuiUX::ToggleButton(ICON_FA_ARROWS_ALT, UrhoGizmo::mode_ == UrhoGizmo::TRANSLATE))
            UrhoGizmo::mode_ = UrhoGizmo::TRANSLATE;
        ImGui::SameLine();
        if (ImGuiUX::ToggleButton(ICON_FA_SYNC_ALT, UrhoGizmo::mode_ == UrhoGizmo::ROTATE))
            UrhoGizmo::mode_ = UrhoGizmo::ROTATE;
        ImGui::SameLine();
        if (ImGuiUX::ToggleButton(ICON_FA_EXPAND_ARROWS_ALT, UrhoGizmo::mode_ == UrhoGizmo::SCALE))
            UrhoGizmo::mode_ = UrhoGizmo::SCALE;
        ImGui::SameLine();
        if (ImGuiUX::ToggleButton(ICON_FA_CUBE, UrhoGizmo::mode_ == UrhoGizmo::BOX))
            UrhoGizmo::mode_ = UrhoGizmo::BOX;
        ImGui::SameLine();

        if (ImGuiUX::ToggleButton(ICON_FA_GLOBE, UrhoGizmo::isLocal_ == false))
            UrhoGizmo::isLocal_ = !giz->isLocal_;
        ImGui::SameLine();

        bool snappingOn = gizmoSettings_->GetField("Snap Position").GetBool() || gizmoSettings_->GetField("Snap Rotation").GetBool() || IsShiftDown();
        ImGuiUX::ToggleMenuButton(ICON_FA_MAGNET, "#snap_settings", "Snapping", snappingOn);

        ImGui::PopFont();
        ImGui::EndGroup();
        if (ImGui::IsItemHovered())
            imageHovered = false;

        if (ImGui::BeginPopup("#snap_settings", ImGuiWindowFlags_Popup))
        {
            ImGuiUX::StandardPopupChecks();

            auto snapPos = gizmoSettings_->GetField("Snap Position").GetBool();
            auto snapRot = gizmoSettings_->GetField("Snap Rotation").GetBool();
            auto snapPosSpace = gizmoSettings_->GetField("Snap position spacing").GetFloat();
            auto snapRotSpace = gizmoSettings_->GetField("Snap rotation degrees").GetFloat();

            ImGui::Text("Snap Position");
            if (ImGui::Checkbox("##Snap Position", &snapPos))
                gizmoSettings_->SetField("Snap Position", snapPos);
            ImGui::SameLine();
            if (ImGui::DragFloat("##Snap position spacing", &snapPosSpace, 0.1f))
                gizmoSettings_->SetField("Snap position spacing", snapPosSpace);
            
            ImGui::Text("Snap Rotation");
            if (ImGui::Checkbox("##Snap Rotation", &snapRot))
                gizmoSettings_->SetField("Snap Rotation", snapRot);
            ImGui::SameLine();
            if (ImGui::DragFloat("##Snap rotation degrees", &snapRotSpace, 0.1f))
                gizmoSettings_->SetField("Snap rotation degrees", snapRotSpace);

            ImGui::EndPopup();
        }
    }

    auto& eventData = doc->GetEventDataMap();
    static StringHash eventID("EDITOR_VIEWPORT_DRAWN");
    static StringHash camID("Camera");
    static StringHash sceneID("Scene");
    eventData[camID] = view_->cameraNode_;
    eventData[sceneID] = doc->GetScene();
    doc->SendEvent(eventID, eventData);

    // Filtering icon
    {
        ImGui::PushID(this);
        ImGui::SetCursorPos(ImVec2(r.right_ - 50, r.top_ + 15));
        ImGuiUX::PushLargeBold();
        ImGui::BeginGroup();
        ImGuiUX::MenuButton(ICON_FA_EYE, "#camera_view", "View Mode");
        ImGui::EndGroup();
        ImGui::PopFont();
        if (ImGui::IsItemHovered())
            imageHovered = false;

        if (ImGui::BeginPopup("#camera_view"))
        {
            ImGuiUX::StandardPopupChecks();

            ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());

            ImGui::Text("Render Mode");
            int viewMode = view_->cameraNode_->GetOrCreateComponent<Camera>()->GetFillMode();
            if (ImGui::Combo("##ender_mode", &viewMode, "Solid\0Wireframe\0Point\0"))
                view_->cameraNode_->GetOrCreateComponent<Camera>()->SetFillMode((FillMode)viewMode);

            ImGui::Text("Location");
            auto camPos = view_->cameraNode_->GetWorldPosition();
            ImGui::Text("%.3f %.3f %.3f", camPos.x_, camPos.y_, camPos.z_);

            ImGui::Text("View Mask");
            unsigned drawMask = view_->cameraNode_->GetOrCreateComponent<Camera>()->GetViewMask();
            if (ImGui::BitField("##view_mask", &drawMask))
                view_->cameraNode_->GetOrCreateComponent<Camera>()->SetViewMask(drawMask);

            ImGui::PopItemWidth();
            ImGui::EndPopup();
        }

        ImGui::PopID();
    }

    auto& sel = view_->doc_->GetSelection();
    auto debugRen = view_->viewport_->GetScene()->GetOrCreateComponent<DebugRenderer>();
    if (!sel.IsEmpty())
    {
        for (size_t i = 0; i < sel.Count(); ++i)
        {
            if (auto selNode = sel.Get<UrhoNodeSelectable>(i))
            {
                auto comps = selNode->node_->GetComponents();
                for (size_t i = 0; i < comps.Size(); ++i)
                    comps[i]->DrawDebugGeometry(debugRen, true);
                debugRen->AddNode(selNode->node_);
            }
            else if (auto selComp = sel.Get<UrhoComponentSelectable>(i))
            {
                selComp->component_->DrawDebugGeometry(debugRen, true);
            }
        }
    }

    bool doingBox = CheckBoxSelect(r.left_ + winPos.x, r.top_ + winPos.y, imageHovered);

    if (doc->GetGizmo() && !doingBox)
    {
        ImGuizmo::SetContext(view_->gizmoContext_);
        extern std::unique_ptr<DataObject> gizmoSettings_;
        ImGuizmo::SetDrawText(view_->gizmoContext_, gizmoSettings_->GetField("Show Gizmo Delta Metrics").GetBool());
        gizmoUsed = doc->GetGizmo()->Draw(view_->cameraNode_->GetOrCreateComponent<Camera>(), 
            IntRect(imgMin.x, imgMin.y, imgMax.x, imgMax.y), 
            debugRen);
        //gizmoUsed = doc->GetGizmo()->Draw(view_->cameraNode_->GetOrCreateComponent<Camera>(), IntRect(winPos.x, winPos.y, winPos.x + winSize.x, winPos.y + winSize.y), debugRen);
    }
    else
        gizmoUsed = false;

    bool wasHovered = false;
    static bool dragged = false;

    ImGui::PushID(this);
    if (imageHovered && !doingBox)
    {
        wasHovered = true;
        bool ctx = false;

        extern bool IsCtrlDown();
        if (ImGui::IsMouseDoubleClicked(1))
        {
            ImGui::OpenPopup("#tree_node_ctx");
            ctx = true;
        }
        if (ImGui::IsMouseDragging(1) && !gizmoUsed && !ctx)
        {
            Activate();
            MouseCapture::Capture(this, Urho3D::MOUSEB_RIGHT);
        }
        else if (ImGui::IsMouseClicked(0) && !gizmoUsed && !ctx)
        {
            Activate();
            if (auto camera = view_->cameraNode_->GetComponent<Camera>())
            {
                auto mp = ImGui::GetMousePos();
                float fx = (mp.x - winPos.x - r.left_) / ((float)r.Width());
                float fy = (mp.y - winPos.y - r.top_) / ((float)r.Height());
                auto ray = camera->GetScreenRay(fx, fy);
                if (auto scene = view_->viewport_->GetScene())
                {
                    if (auto octree = scene->GetComponent<Octree>())
                    {
                        PODVector<RayQueryResult> result;
                        Urho3D::RayOctreeQuery q(result, ray, RAY_TRIANGLE, 50000, DRAWABLE_GEOMETRY);
                        octree->Raycast(q);
                        while (!result.Empty() && result.Front().node_->GetName().StartsWith("##"))
                            result.Erase(0);
                        if (result.Size() > 0)
                        {
                            SharedPtr<Node> nd(result.Front().node_);
                            if (nd)
                            {
                                // Check if it's already selected
                                bool bypass = false;
                                for (auto existingSel : view_->doc_->GetSelection())
                                {
                                    if (existingSel->Is(nd.Get()))
                                    {
                                        bypass = true;
                                        break;
                                    }
                                }
                                
                                if (ImGui::GetIO().KeyCtrl)
                                {
                                    if (!bypass)
                                    {
                                        view_->doc_->GetSelection().AddSelection(std::make_shared<UrhoNodeSelectable>(nd));
                                        doc->GetGizmo().reset(new UrhoGizmo(nd));
                                    }
                                    else
                                        view_->doc_->GetSelection().Deselect(nd.Get());
                                }
                                else if (!bypass)
                                {
                                    view_->doc_->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(nd));
                                    doc->GetGizmo().reset(new UrhoGizmo(nd));
                                }
                            }

                            doc->CheckMultiGizmo();
                            result.Clear();
                        }
                        else
                        {
                            doc->GetSelection().DeselectAll();
                            doc->GetGizmo().reset();
                        }
                    }
                }
            }
        }
    }

    if (ImGui::BeginPopup("#tree_node_ctx"))
    {
        if (auto sel = doc->GetSelection().MostRecent<UrhoNodeSelectable>())
        {
            FillNodeContextMenu(sel->node_.Get(), view_->cameraNode_.Get(), &sceneView_RayHit);
        }
        else
            FillNodeContextMenu(0x0, view_->cameraNode_.Get(), &sceneView_RayHit);
        ImGui::EndPopup();
    }
    ImGui::PopID();

    if (doc->viewCamera_)
    {
        ImGui::SetCursorPos(ImVec2(winSize.x - 340, winSize.y - 260));
        ImGui::Image((ImTextureID)doc->viewTexID_, ImVec2(320, 240));
    }

    if (IsActive())
    {
        if (imageHovered && MouseCapture::Get()->GetActive() == nullptr)
            ProcessKeyboardInput(1.5f);

        // use mouse wheel to zoom in/out
        if (imageHovered && ImGui::GetIO().MouseWheel != 0)
        {
            float delta = ImGui::GetIO().MouseWheel;
            if (IsShiftDown())
                delta *= 10;
            view_->cameraNode_->SetWorldPosition(view_->cameraNode_->GetWorldPosition() + view_->cameraNode_->GetWorldDirection() * delta);
        }

        ImGui::GetWindowDrawList()->AddRect(
            imgMin,
            imgMax,
            ImColor(ImVec4(100 / 255.0f, 149 / 255.0f, 237 / 255.0f, 1)), 2.0f, 15, 3);
    }

    ImGui::PopID();
}

void SceneDocument::PreDraw()
{
    if (!scene_)
        return;
    Document3D::PreDraw();
    //CheckMultiGizmo();
    if (auto sel = GetSelection().MostRecent<UrhoNodeSelectable>())
        InitializeCameraView(SharedPtr<Camera>(sel->node_->GetComponent<Camera>()));
    else if (auto sel = GetSelection().MostRecent<UrhoComponentSelectable>())
        InitializeCameraView(SharedPtr<Camera>(dynamic_cast<Camera*>(sel->component_.Get())));
    else
        DeinitializeCameraView();
}

void SceneDocument::DrawMasterButtons()
{

    ImGuiUX::MenuButton(ICON_FA_EDIT, "#main_menu_edit", "Edit");
    ImGuiUX::MenuButton(ICON_FA_SLIDERS_H, "#main_menu_tasks", "Tasks");
    DrawViewManagementWidgets();

    if (ImGui::BeginPopup("#main_menu_edit", ImGuiWindowFlags_ChildMenu))
    {
        if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
            ImGui::CloseCurrentPopup();

        if (GetSelection().Count())
        {
            if (ImGuiUX::AutoMenu(ICON_FA_CIRCLE_NOTCH " Clear Selection"))
                GetSelection().DeselectAll();
            ImGuiUX::AutoSeparator();

            if (ImGuiUX::AutoMenu(ICON_FA_CUT " Cut"))
                StandardActions::CutScene->ForceTrigger();
            if (ImGuiUX::AutoMenu(ICON_FA_COPY " Copy"))
                StandardActions::CopyScene->ForceTrigger();

            if (Clipboard::GetClipboardDataType() == 0)
                ImGui::Separator();
        }

        if (Clipboard::GetClipboardDataType() && ImGuiUX::AutoMenu(ICON_FA_PASTE " Paste"))
            StandardActions::PasteScene->ForceTrigger();
        ImGuiUX::AutoSeparator();
        if (ImGuiUX::AutoMenu(ICON_FA_SYNC_ALT " Reset to Default"))
            StandardActions::ResetToDefault->ForceTrigger();
        ImGuiUX::AutoSeparator();
        if (ImGuiUX::AutoMenu(ICON_FA_SYNC_ALT " Reset Position"))
            StandardActions::ResetPosition->ForceTrigger();
        if (ImGuiUX::AutoMenu(ICON_FA_SYNC_ALT " Reset Rotation"))
            StandardActions::ResetRotation->ForceTrigger();
        if (ImGuiUX::AutoMenu(ICON_FA_SYNC_ALT " Reset Scale"))
            StandardActions::ResetScale->ForceTrigger();
        if (ImGuiUX::AutoMenu(ICON_FA_SYNC_ALT " Reset Transform"))
            StandardActions::ResetTransform->ForceTrigger();
        ImGui::Separator();
        bool updating = scene_->IsUpdateEnabled();
        if (ImGui::MenuItem(ICON_FA_PLAY " Toggle Update", 0x0, &updating))
            scene_->SetUpdateEnabled(updating);
        if (ImGuiUX::AutoMenu(ICON_FA_EYE " View Closer"))
        {
            if (auto camera = scene_->GetChild(EDITOR_CAMERA_NAME))
            {
                Urho3D::BoundingBox bb;
                for (auto sel : GetSelection())
                {
                    if (auto selNode = std::dynamic_pointer_cast<UrhoNodeSelectable>(sel))
                    {
                        PODVector<Drawable*> drawables;
                        selNode->node_->GetDerivedComponents<Drawable>(drawables, true);
                        if (drawables.Size())
                            for (auto draw : drawables)
                                bb.Merge(draw->GetWorldBoundingBox());
                        else
                            bb.Merge(Urho3D::BoundingBox(selNode->node_->GetWorldPosition() - Vector3::ONE, selNode->node_->GetWorldPosition() + Vector3::ONE));
                    }
                }

                if (bb.Defined())
                {                    
                    Vector3 camPos = camera->GetWorldPosition();
                    Vector3 centroid = bb.Center();
                    Focus(bb, (camPos - centroid).Normalized(), &camPos, &centroid);
                    
                    camera->SetWorldPosition(camPos);
                    camera->LookAt(centroid);// sel->node_->GetWorldPosition());
                }
                else
                    camera->LookAt(Vector3(0, 0, 0));
            }
        }
        ImGuiUX::EndAutoMenu();
        ImGui::EndPopup();
    }
    if (ImGui::BeginPopup("#main_menu_tasks", ImGuiWindowFlags_ChildMenu))
    {
        if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
            ImGui::CloseCurrentPopup();

        if (ImGui::MenuItem(ICON_FA_LIGHTBULB " Lighting Settings"))
            ModalWindows::Get()->PushTool(ModalWindow(ICON_FA_LIGHTBULB " Lighting Settings", LightingSettingsDialog));
        ImGui::MenuItem(ICON_FA_LIGHTBULB ICON_FA_IMAGE " Bake Lightmaps");
        if (ImGui::MenuItem(ICON_FA_LIGHTBULB ICON_FA_GLOBE " Bake Environment Cubemaps"))
            BakeCubemaps();
        ImGui::Separator();
        if (ImGui::MenuItem(ICON_FA_DOWNLOAD " Export Selected to OBJ"))
            Action_ExportOBJ->ForceTrigger();
        
        if (ImGui::MenuItem(ICON_FA_TACHOMETER_ALT " Static Batching Wizard"))
        {
            extern std::unique_ptr<DataObject> batchOptimizerSettings_;

            ModalWindows::Get()->PushModal(ModalWindow(ICON_FA_TACHOMETER_ALT " Static Batching Wizard", []() -> bool {
                DataObject::DrawEditor(batchOptimizerSettings_.get());
                ImGui::Separator();
                if (ImGui::Button("Optimize"))
                    return false;
                return true;
            }));
        }
        ImGui::Separator();
        if (ImGui::MenuItem(ICON_FA_MAP_MARKER_ALT " Rebuild Navigation Meshes"))
            BakeNavigation();
        if (ImGui::MenuItem(ICON_FA_SYNC " Update Prefabs"))
            Action_UpdatePrefabs->ForceTrigger();
        ImGui::Separator();
        if (ImGui::MenuItem("Add Children to Static-Model Group"))
            Action_AddChildrenToStaticModel->ForceTrigger();
        if (ImGui::MenuItem("Add Children to Spline"))
            Action_AddChildrenToSpline->ForceTrigger();

        ImGui::EndPopup();
    }
    

}

void SceneDocument::BakeLightmaps()
{

}

void SceneDocument::BakeCubemaps()
{
    bool success = false;
    PODVector<Zone*> capturedThisCall;

    bool alreadyCapturing = captureData_->activeCapture_.Size() > 0; // May have managed to quickly queue up a second round of zones to render cubemaps for

    PODVector<Zone*> zones;
    for (unsigned i = 0; i < GetSelection().size(); ++i)
    {
        if (auto nodeSel = std::dynamic_pointer_cast<UrhoNodeSelectable>(GetSelection()[i]))
        {
            nodeSel->node_->GetComponents<Zone>(zones, true);
        }
        else if (auto compSel = std::dynamic_pointer_cast<UrhoComponentSelectable>(GetSelection()[i]))
        {
            if (Zone* z = dynamic_cast<Zone*>(compSel->component_.Get()))
                zones.Push(z);
        }
    }

    for (unsigned z = 0; z < zones.Size(); ++z)
    {
        Zone* zone = zones[z];
        if (zone)
        {
            captureData_->activeCapture_.Push(SharedPtr<CubeCapture>(new CubeCapture(captureData_.get(), zone, scene_->GetName(), zone->GetNode()->GetName(), zone->GetID(), 128)));
            capturedThisCall.Push(zone);
        }
    }

    // Start rendering cubemaps if there are any to render and the queue isn't already running
    if (captureData_->activeCapture_.Size() > 0 && !alreadyCapturing)
    {
        captureData_->PrepareZonesForCubeRendering(scene_);
        captureData_->activeCapture_[0]->Start();
    }

    if (capturedThisCall.Size() <= 0)
        URHO3D_LOGINFO("Generating cubemaps for " + String(capturedThisCall.Size()) + " zones");
}

void SceneDocument::OptimizeMeshes()
{

}

void SceneDocument::BakeNavigation()
{
    PODVector<NavigationMesh*> navMeshes;
    scene_->GetDerivedComponents<NavigationMesh>(navMeshes, true);
    for (auto navMesh : navMeshes)
        navMesh->Build();
    if (navMeshes.Size())
    {
        URHO3D_LOGINFO("Regenerated " + String(navMeshes.Size()) + " navigation meshes");
    }
}

MultiGizmo::MultiGizmo(std::vector<std::shared_ptr<UrhoNodeSelectable> > items)
{
    items_ = items;
    int idx = 0;
    for (auto i : items_)
        i->AccumulateTransform(originalMatrices_, idx);

    Vector3 trans(0, 0, 0);
    Quaternion rot = Quaternion::IDENTITY;
    Vector3 scale(1, 1, 1);
    for (auto transform : originalMatrices_)
    {
        Vector3 lclTrans;
        Quaternion lclRot;
        Vector3 lclScl;
        transform.Decompose(lclTrans, lclRot, lclScl);

        trans += lclTrans;
        rot += lclRot;
        scale += lclScl;
    }

    rot.Normalize();
    trans /= originalMatrices_.size();
    rot *= (1.0f / originalMatrices_.size());
    rot.Normalize();

    scale = Vector3(1, 1, 1);
    scale /= originalMatrices_.size();

    centroidMat_ = Matrix3x4(trans, items_.size() == 1 ? rot : Quaternion::IDENTITY, Vector3(1,1,1)).ToMatrix4();
}

bool MultiGizmo::Draw(Urho3D::Camera* camera, const Urho3D::IntRect& rect, Urho3D::DebugRenderer* render)
{
    if (mode_ == NONE || mode_ == SCALE || mode_ == BOX)
        return false;

    if (items_.empty())
        return false;

    std::vector<Matrix3x4> transforms;
    int idx = 0;
    for (auto i : items_)
        i->AccumulateTransform(transforms, idx);

    Vector3 trans(0, 0, 0);
    Quaternion rot = Quaternion::IDENTITY;
    Vector3 scale(1, 1, 1);
    for (auto transform : transforms)
    {
        Vector3 lclTrans;
        Quaternion lclRot;
        Vector3 lclScl;
        transform.Decompose(lclTrans, lclRot, lclScl);

        trans += lclTrans;
        rot += lclRot;
        scale += lclScl;
    }

    rot.Normalize();
    trans /= transforms.size();
    rot *= (1.0f / transforms.size());
    rot.Normalize();

    scale = Vector3(1, 1, 1);
    scale /= transforms.size();

    auto viewMat = camera->GetView().ToMatrix4().Transpose();
    auto projMat = camera->GetProjection().Transpose();

    ImGuiIO& io = ImGui::GetIO();
    ImGuizmo::SetDrawlist();
    ImGuizmo::Enable(true);
    ImGuizmo::SetRect(rect.left_, rect.top_, rect.Width(), rect.Height());

    Matrix4 refMat = Matrix3x4(trans, items_.size() == 1 ? rot : Quaternion::IDENTITY, Vector3(1,1,1)).ToMatrix4();
    Matrix4 editMat = refMat.Transpose();
    Matrix4 deltaMat;

    extern std::unique_ptr<DataObject> gizmoSettings_;
    Vector3 snap(0, 0, 0);
    Vector3 boundsSnap(0, 0, 0);

    extern bool IsShiftDown();
    if ((mode_ == TRANSLATE || mode_ == BOX) && (gizmoSettings_->GetField("Snap Position").GetBool() || IsShiftDown()))
    {
        float f = gizmoSettings_->GetField("Snap position spacing").GetFloat();
        snap = Vector3(f, f, f);
    }
    else if (mode_ == ROTATE && (gizmoSettings_->GetField("Snap Rotation").GetBool() || IsShiftDown()))
    {
        float f = gizmoSettings_->GetField("Snap rotation degrees").GetFloat();
        snap = Vector3(f, f, f);
    }

    auto mode = mode_ == TRANSLATE ? ImGuizmo::TRANSLATE : (mode_ == ROTATE) ? ImGuizmo::ROTATE : ImGuizmo::SCALE;
    ImGui::PushClipRect(ImVec2(rect.left_, rect.top_), ImVec2(rect.right_, rect.bottom_), true);
    ImGuizmo::Manipulate(viewMat.Data(), projMat.Data(), mode, ImGuizmo::WORLD, (float*)editMat.Data(), (float*)deltaMat.Data(), &snap.x_);
    ImGui::PopClipRect();

    if (ImGuizmo::IsUsing())
    {
        Vector3 trans, scl;
        Quaternion rot;

        editMat = editMat.Transpose();
        editMat.Decompose(trans, rot, scl);
        deltaMat = deltaMat.Transpose();

        // What in the fuck is this shit? ImGuizmo has to go, it's not even remotely fucking consistent.
        extern bool IsCtrlDown();
        if (IsCtrlDown() && !ImGuizmo::GetMarkerBit(1))
        {
            ImGuizmo::SetMarkerBit(1, true);
            //didClone_ = true;
            std::vector<std::shared_ptr<UrhoNodeSelectable> > newItems;
            UndoRedoList actions;
            std::vector<std::shared_ptr<UrhoNodeSelectable>> oldItems = items_;
            for (size_t i = 0; i < items_.size(); ++i)
            {
                auto& n = items_[i];
                auto clone = n->node_->Clone(n->node_->GetID() < FIRST_LOCAL_ID ? REPLICATED : LOCAL);
                newItems.push_back(std::make_shared<UrhoNodeSelectable>(clone));
                actions.push_back(std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(n->node_->GetParent()), SharedPtr<Node>(clone), true));
            }
            items_ = newItems;

            SelectionList oldSel = DocumentManager::Get()->GetActiveDocument()->GetSelection();
            SelectionList newSel = CastVector<Selectable>(newItems);
            DocumentManager::Get()->GetActiveDocument()->GetSelection().Set(newSel);
            DocumentManager::Get()->GetActiveDocument()->GetUndoStack().PushNew(
                std::make_shared<MultiUndoRedo>(ICON_FA_CLONE " ^3Clone " + String(newItems.size()) + " nodes", actions))->AttachSelectables(oldSel, newSel);
        }
        else if (!IsCtrlDown())
            ImGuizmo::SetMarkerBit(1, false);

        if (items_.size() == 0)
            return true;

        SelectionList oldSelection = DocumentManager::Get()->GetActiveDocument()->GetSelection();
        String idList;
        std::vector<std::shared_ptr<UndoRedo> > actions;
        for (size_t i = 0; i < items_.size(); ++i)
        {
            auto& sel = items_[i];
            auto oldP = sel->node_->GetWorldPosition();
            auto oldQ = sel->node_->GetWorldRotation();
            auto oldS = sel->node_->GetWorldScale();

            if (mode_ == ImGuizmo::ROTATE)
                sel->node_->RotateAround(refMat.Translation(), -deltaMat.Rotation(), TS_WORLD);
            else if (mode_ == ImGuizmo::SCALE && deltaMat.Scale().Length() > 0.001f)
                sel->node_->SetWorldScale(originalMatrices_[i].Scale() * deltaMat.Scale());
            else
                sel->node_->Translate(deltaMat.Translation(), TS_WORLD);

            auto newP = sel->node_->GetWorldPosition();
            auto newQ = sel->node_->GetWorldRotation().Normalized();
            auto newS = sel->node_->GetWorldScale();

            actions.push_back(std::make_shared<UrhoTransformUndoRedo>(sel->node_,
                oldP, oldQ, oldS,
                newP, newQ, newS
                ));
            if (i > 0)
                idList += ", ";
            idList += String(sel->node_->GetID());
        }

        DocumentManager::Get()->GetActiveDocument()->GetUndoStack().PushNew(
            std::make_shared<MultiUndoRedo>((ICON_FA_ARROWS_ALT " ^3Transform " + String(items_.size()) + " nodes: " + idList), actions)
        )->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

        int moveType = ImGuizmo::GetAxis();
        DrawGrid(moveType, trans, render);

        return true;
    }
    else
        ImGuizmo::SetMarkerBit(1, false);
    return false;
}

void SceneDocument::InitializeCameraView(SharedPtr<Camera> camera)
{
    if (!camera || !camera->IsEnabledEffective())
    {
        DeinitializeCameraView();
        return;
    }

    if (!viewport_)
    {
        viewport_ = new Viewport(GetContext(), scene_, camera);
        viewTexture_ = new Texture2D(GetContext());
        viewTexture_->SetSize(320, 230, Urho3D::Graphics::GetRGBAFormat(), TEXTURE_RENDERTARGET);
        viewSurface_ = viewTexture_->GetRenderSurface();
        viewSurface_->SetViewport(0, viewport_);
        viewTexID_ = 5000 + (++View::nextViewID_);
        BlockExe::GetInst()->GetImGuiElem()->AddTexture(viewTexID_, viewTexture_);
    }

    viewCamera_ = camera;
    viewport_->SetCamera(camera);
    viewSurface_->SetUpdateMode(Urho3D::SURFACE_UPDATEALWAYS);
}

void SceneDocument::DeinitializeCameraView()
{
    viewCamera_.Reset();
    if (viewSurface_)
        viewSurface_->SetUpdateMode(Urho3D::SURFACE_MANUALUPDATE);
}

void SceneDocument::OnSelectionChanged(StringHash, VariantMap&)
{
    CheckMultiGizmo();
}