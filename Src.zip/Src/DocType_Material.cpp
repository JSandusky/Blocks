#include "DocType_Material.h"

#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Audio/SoundListener.h>
#include <Urho3D/Graphics/Technique.h>

#include <Urho3D/Graphics/Texture.h>
#include <Urho3D/Graphics/Texture2D.h>
#include <Urho3D/Graphics/Texture2DArray.h>
#include <Urho3D/Graphics/TextureCube.h>
#include <Urho3D/Graphics/Texture3D.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include <Urho3D/Scene/ObjectAnimation.h>
#include <Urho3D/Scene/ValueAnimation.h>

#include "Block.h"
#include "DataObject.h"
#include "GUI_Pane3D.h"
#include "Urho_Util.h"
#include "UX.h"

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

extern void SetupTestScene(Urho3D::SharedPtr<Urho3D::Scene> scene, Urho3D::SharedPtr<Urho3D::Node> camNode);

MaterialDocumentType::MaterialDocumentType() : DocumentType("Material", "Material (*.xml)|*.xml")
{

}

std::shared_ptr<DocumentBase> MaterialDocumentType::NewDocument()
{
    return std::make_shared<MaterialDocument>(BlockExe::GetInst()->GetContext());
}

std::shared_ptr<DocumentBase> MaterialDocumentType::OpenPath(const Urho3D::String& path)
{
    return std::make_shared<MaterialDocument>(BlockExe::GetInst()->GetContext(), path);
}

class GUI_MaterialView : public GUI_View3D
{
public:
    MaterialDocument* doc_;

    GUI_MaterialView(Document3D::View* v) :
        GUI_View3D(v)
    {
        doc_ = dynamic_cast<MaterialDocument*>(v->doc_);
    }

    ~GUI_MaterialView()
    {
        doc_ = 0x0;
    }

    GUI_PaneView* Clone()
    {
        auto camClone = view_->cameraNode_->Clone();
        camClone->SetTemporary(true);
        auto v = new Document3D::View(view_->doc_, SharedPtr<Node>(camClone));
        return new GUI_MaterialView(v);
    }

    virtual void Draw(const Urho3D::IntRect& r) override {
        ImGui::PushID(doc_);

        auto winPos = ImGui::GetWindowPos();
        auto winSize = ImGui::GetWindowSize();
        const bool isActive = IsActive();

        GUI_View3D::Draw(r);

        auto boldFont = ImGui::GetIO().Fonts->Fonts[3];
        ImGui::PushFont(boldFont);

        ImGui::SetCursorPos(ImVec2(20, 20));
        ImGui::BeginGroup();
        if (ImGui::Button(ICON_FA_PLAY))
            doc_->scene_->SetUpdateEnabled(true);
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_PAUSE))
            doc_->scene_->SetUpdateEnabled(false);
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_SYNC_ALT))
            doc_->scene_->SetElapsedTime(0.0f);
        ImGui::SameLine();
        if (doc_->scene_->IsUpdateEnabled())
            ImGui::Text(" Playing");
        else
            ImGui::Text(" Paused");
        ImGui::Text("Time: %.3f", doc_->scene_->GetElapsedTime());
        ImGui::Checkbox("Animate Light", &doc_->animateLight_);
        ImGui::EndGroup();

        ImGui::PopFont();

        ImGui::PopID();
    }
};

template<typename T, typename CAST = T, typename CALL = T>
struct MaterialUndoRedo : public UndoRedo
{
    typedef String(*STRING_FUNC)(CAST val);

    typedef void (Material::*FUNC_PTR)(CALL);
    MaterialUndoRedo(MaterialDocument* doc, String name, Material* mat, FUNC_PTR ptr, T oldValue, T newValue, STRING_FUNC strFunc = [](CAST val) -> String { return String(val); }) :
        doc_(doc),
        name_(name),
        mat_(mat),
        ptr_(ptr),
        oldValue_(oldValue),
        newValue_(newValue),
        strFunc_(strFunc)
    {
        UpdateText();
    }

    virtual Urho3D::String GetText() override { return text_; }

    virtual void Execute(bool isUndo, DocumentBase* forDoc) override {
        doc_->MarkDirty();
        if (isUndo)
            (mat_->*ptr_)(oldValue_);
        else
            (mat_->*ptr_)(newValue_);
    }

    virtual bool CanMergeWith(UndoRedo* rhs) const override {
        if (auto other = dynamic_cast<MaterialUndoRedo*>(rhs))
            return other->ptr_ == ptr_;
        return false;
    }

    virtual void Merge(UndoRedo* rhs) override {
        if (auto other = dynamic_cast<MaterialUndoRedo*>(rhs))
        {
            newValue_ = other->newValue_;
            text_ = other->text_;
        }
    }

    void UpdateText()
    {
        text_ = (ICON_FA_PENCIL_ALT " ^3 Set " + name_ + " " + strFunc_((CAST)newValue_));
    }

    FUNC_PTR ptr_;
    MaterialDocument* doc_;
    Material* mat_;
    T oldValue_;
    T newValue_;
    String name_;
    STRING_FUNC strFunc_;
    Urho3D::String text_;
};

struct MaterialTextureUndo : public UndoRedo {

    MaterialTextureUndo(MaterialDocument* doc, Material* mat, unsigned texID, ResourceRef oldRef, ResourceRef newRef) :
        doc_(doc),
        material_(mat),
        idx_(texID),
        oldValue_(oldRef),
        newValue_(newRef)
    {
        text_ = (ICON_FA_IMAGE " ^3Set " + Material::GetTextureUnitName((TextureUnit)texID) + " to " + newRef.name_);
    }

    virtual Urho3D::String GetText() override { return text_; }

    virtual void Execute(bool isUndo, DocumentBase* forDoc) {
        doc_->MarkDirty();
        if (isUndo)
        {
            auto tex = BlockExe::GetInst()->GetContext()->GetSubsystem<ResourceCache>()->GetResource<Texture2D>(oldValue_.name_);
            material_->SetTexture((TextureUnit)idx_, tex);
        }
        else
        {
            if (auto tex = BlockExe::GetInst()->GetContext()->GetSubsystem<ResourceCache>()->GetResource<Texture2D>(newValue_.name_))
                material_->SetTexture((TextureUnit)idx_, tex);
            else if (auto tex = BlockExe::GetInst()->GetContext()->GetSubsystem<ResourceCache>()->GetResource<TextureCube>(newValue_.name_))
                material_->SetTexture((TextureUnit)idx_, tex);
            else if (auto tex = BlockExe::GetInst()->GetContext()->GetSubsystem<ResourceCache>()->GetResource<Texture2DArray>(newValue_.name_))
                material_->SetTexture((TextureUnit)idx_, tex);
            else if (auto tex = BlockExe::GetInst()->GetContext()->GetSubsystem<ResourceCache>()->GetResource<Texture3D>(newValue_.name_))
                material_->SetTexture((TextureUnit)idx_, tex);
        }
    }

    MaterialDocument* doc_;
    Material* material_;
    unsigned idx_;
    ResourceRef oldValue_;
    ResourceRef newValue_;
    Urho3D::String text_;
};

struct MaterialShaderParamCreateDelete : public UndoRedo {
    MaterialShaderParamCreateDelete(const MaterialDocument* doc, Material* mat, MaterialShaderParameter param, bool isCreate) :
        doc_(doc),
        mat_(mat),
        param_(param),
        isCreate_(isCreate)
    {
        if (isCreate)
            text_ = (ICON_FA_ASTERISK " ^2Add shader parameter " + param_.name_ + " -> " + param_.value_.ToString());
        else
            text_ = (ICON_FA_TRASH " ^1Delete shader parameter " + param_.name_ + " -> " + param_.value_.ToString());
    }

    virtual Urho3D::String GetText() override { return text_; }

    virtual void Execute(bool isUndo, DocumentBase* forDoc) override {
        doc_->MarkDirty();
        if ((isUndo && isCreate_) || (!isUndo && !isCreate_))
        {
            mat_->RemoveShaderParameter(param_.name_);
            doc_->ScheduleRecollect();
        }
        else
        {
            mat_->SetShaderParameter(param_.name_, param_.value_);
            doc_->ScheduleRecollect();
        }
    }

    const MaterialDocument* doc_;
    Material* mat_;
    MaterialShaderParameter param_;
    bool isCreate_;
    Urho3D::String text_;
};

struct MaterialShaderParamEdit : public UndoRedo {
    MaterialShaderParamEdit(const MaterialDocument* doc, Material* mat, MaterialShaderParameter oldValue, MaterialShaderParameter newValue) :
        doc_(doc),
        mat_(mat),
        oldValue_(oldValue),
        newValue_(newValue)
    {
        text_ = (ICON_FA_TRASH " ^3Set shader parameter " + newValue.name_ + " to " + newValue.value_.ToString());
    }

    virtual Urho3D::String GetText() override { return text_; }

    virtual void Execute(bool isUndo, DocumentBase* forDoc) override
    {
        doc_->MarkDirty();
        if (isUndo)
        {
            mat_->SetShaderParameter(oldValue_.name_, oldValue_.value_);
        }
        else
        {
            mat_->SetShaderParameter(newValue_.name_, newValue_.value_);
        }
        doc_->ScheduleParamUpdate();
    }

    virtual bool CanMergeWith(UndoRedo* rhs) const override {
        if (auto other = dynamic_cast<MaterialShaderParamEdit*>(rhs))
            return other->newValue_.name_ == newValue_.name_;
        return false;
    }

    virtual void Merge(UndoRedo* rhs) override {
        if (auto other = dynamic_cast<MaterialShaderParamEdit*>(rhs))
        {
            newValue_ = other->newValue_;
            text_ = other->text_;
        }
    }

    const MaterialDocument* doc_;
    Material* mat_;
    MaterialShaderParameter oldValue_;
    MaterialShaderParameter newValue_;
    Urho3D::String text_;
};

void MaterialDocument::CommonConstruct()
{
    wantNodeIcons_ = false;
    auto ctx = BlockExe::GetInst()->GetContext();

    auto cache = ctx->GetSubsystem<ResourceCache>();

    scene_ = new Scene(ctx);

    SharedPtr<Node> cameraNode = SharedPtr<Node>(scene_->CreateChild("Editor Camera"));
    auto camera = cameraNode->CreateComponent<Camera>();
    cameraNode->CreateComponent<SoundListener>();
    camera->SetTemporary(true);

    // Construct a test scene
    if (!LoadEditorScene(scene_, "MaterialEditor.xml"))
        SetupTestScene(scene_, cameraNode);

    cameraNode->SetWorldPosition(Vector3(0, 2, -4));
    cameraNode->LookAt(Vector3(0, 0, 0));

    model_ = Urho3D::SharedPtr<Model>(cache->GetResource<Model>("Data/Models/Sphere.mdl"));
    auto node = scene_->CreateChild("PREVIEW_NODE");
    node->SetTemporary(true);
    node->SetWorldPosition(Vector3(0, 0, 0));
    previewModel_ = Urho3D::SharedPtr<StaticModel>(node->GetOrCreateComponent<StaticModel>());
    previewModel_->SetModel(model_);    

    guiViews_->topViews_.push_back(new GUI_MaterialView(new View(this, cameraNode)));
}

MaterialDocument::MaterialDocument(Context* ctx) :
    Document3D(ctx, 0x0)
{
    CommonConstruct();

    material_ = Urho3D::SharedPtr<Material>(new Material(GetContext()));
    previewModel_->SetMaterial(material_);

    if (auto lightNode = scene_->GetChild("DirectionalLight"))
    {
        SharedPtr<ObjectAnimation> newAnim(new ObjectAnimation(ctx));
        SharedPtr<ValueAnimation> valAnim(new ValueAnimation(ctx));
        valAnim->SetKeyFrame(0.0f, Vector3(10, 10, 0));
        valAnim->SetKeyFrame(3.0f, Vector3(-10, 10, 0));
        valAnim->SetKeyFrame(5.0f, Vector3(0, 10, 10));
        newAnim->AddAttributeAnimation("Position", valAnim);
        lightNode->SetObjectAnimation(newAnim);
    }

    CollectMaterialParams();
}

MaterialDocument::MaterialDocument(Context* ctx, const Urho3D::String& path) :
    Document3D(ctx, 0x0)
{
    filePath_ = path.CString();
    name_ = Urho3D::GetFileNameAndExtension(path).CString();
    CommonConstruct();

    auto cache = scene_->GetSubsystem<ResourceCache>();
    material_ = cache->GetResource<Material>(path);
    previewModel_->SetMaterial(material_);

    CollectMaterialParams();
}

MaterialDocument::~MaterialDocument()
{

}

void MaterialDocument::CollectMaterialParams()
{
    materialParams_.Clear();

    auto params = material_->GetShaderParameters();
    for (auto kvp : params)
        materialParams_.Push(kvp.second_);
}

bool MaterialDocument::Save()
{
    if (filePath_.empty())
    {
        auto fileName = GetSaveFile_PairName("Save Material", "*.xml", "Material (*.xml)|*.xml");

        if (!fileName.first.empty())
        {
            filePath_ = fileName.first;
            name_ = fileName.second;
        }
        else
            return false;
    }

    material_->SaveFile(filePath_.c_str());
    ClearDirty();
    return true;
}

void MaterialDocument::SaveAs()
{
    auto oldFilePath = filePath_;
    filePath_.clear();
    if (Save())
    {

    }
    else
        filePath_ = oldFilePath; // if save fails then revert path
}

bool MaterialDocument::Close()
{
    Document3D::Close();
    scene_.Reset();
    return true;
}

void MaterialDocument::ScheduleParamUpdate() const
{ 
    updateParams_ = true; 
}

void MaterialDocument::ScheduleRecollect() const
{ 
    flushParams_ = true; 
}

void MaterialDocument::PreDraw()
{
    if (!scene_)
        return;
    UpdateNodeIcons();

    if (animateLight_)
    {
        if (auto lightNode = scene_->GetChild("DirectionalLight"))
        {
            //lightTime_ += ImGui::GetTime();
            //float lightTerm = math::PingPongMod(ImGui::GetTime(), 1.5f) / 1.5f;
            //float lightPos = math::PingPongMod(ImGui::GetTime(), 2.0f) / 2.0f;
            //lightNode->SetWorldDirection(
            //    (Vector3(-2, -1, 0).Normalized().Lerp(Vector3(2, -1, 1).Normalized(), lightTerm)).Normalized()
            //);
            //lightNode->SetWorldPosition((Vector3(-4, 2, 0).Lerp(Vector3(4, 2, 2), lightPos)));
        }
    }

    auto debugRen = scene_->GetOrCreateComponent<DebugRenderer>();
    DrawGrid_3D(debugRen, Vector3(0, 0, 0));
    if (drawAxes_)
    {
        debugRen->AddLine(Vector3(0, 0.001f, 0), Vector3(5, 0.001f, 0), Color::RED);
        debugRen->AddLine(Vector3(0, 0.001f, 0), Vector3(0, 0.001f, 5), Color::BLUE);
    }
}

void MaterialDocument::DrawProperties(ImGuiTextFilter* filter)
{
    if (updateParams_)
    {
        for (auto& p : materialParams_)
            p.value_ = material_->GetShaderParameter(p.name_);
        updateParams_ = false;
    }
    if (flushParams_)
    {
        CollectMaterialParams();
        flushParams_ = false;
    }

    auto ctx = scene_->GetContext();
    auto cache = ctx->GetSubsystem<ResourceCache>();

    ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());

    static const char* CULL_STRINGS = "None\0Counter-Clockwise\0Clockwise\0\0";
    static const char* FILL_STRINGS = "Solid\0Wireframe\0Point\0\0";

    ImGui::Checkbox("Draw Axes", &drawAxes_);

    ResourceRef previewRes(StringHash("Model"), model_->GetName().Replaced("//","/"));
    ImGui::Text("Preview Model");
    if (ImGuiElement::EditResourceRef("modelres", previewRes))
    {
        auto cache = previewModel_->GetSubsystem<ResourceCache>();
        if (auto mdlThing = cache->GetResource<Model>(previewRes.name_))
        {
            model_ = mdlThing;
            auto mat = previewModel_->GetMaterial();
            previewModel_->SetModel(model_);
            previewModel_->SetMaterial(mat);
        }
    }

    int fillMode = material_->GetFillMode();
    int oldFillMode = fillMode;
    ImGui::Text("Filling Mode");
    if (ImGui::Combo("##fillmode", &fillMode, FILL_STRINGS))
    {
        GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<Urho3D::FillMode>>(this, "Filling Mode", material_.Get(), &Material::SetFillMode, (FillMode)oldFillMode, (FillMode)fillMode, [](FillMode val) -> String {
            if (val == FillMode::FILL_SOLID)
                return "Solid";
            else if (val == FillMode::FILL_POINT)
                return "Point";
            return "Wire";
        }))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());
    }

    bool alphaCoverage = material_->GetAlphaToCoverage();
    bool oldAC = alphaCoverage;
    if (ImGui::Checkbox("Alpha To Coverage", &alphaCoverage))
        GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<bool>>(this, "Alpha to Coverage", material_.Get(), &Material::SetAlphaToCoverage, oldAC, alphaCoverage))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

    bool lineAntialias = material_->GetLineAntiAlias();
    bool oldLineAnti = lineAntialias;
    if (ImGui::Checkbox("Line Antialias", &lineAntialias))
        GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<bool>>(this, "Line Antialias", material_.Get(), &Material::SetLineAntiAlias, oldLineAnti, lineAntialias))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

    bool occlusion = material_->GetOcclusion();
    bool oldOcclusion = occlusion;
    if (ImGui::Checkbox("Occlusion", &occlusion))
        GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<bool>>(this, "Occlusion", material_.Get(), &Material::SetOcclusion, oldOcclusion, occlusion))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());;

    int renderOrder = material_->GetRenderOrder();
    int oldRenderOrder = renderOrder;
    ImGui::Text("Render Order");
    if (ImGui::DragInt("##render_order", &renderOrder, 1.0f, 0, 255))
        GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<unsigned char, int>>(this, "Render Order", material_.Get(), &Material::SetRenderOrder, oldRenderOrder, renderOrder))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());;

    static auto CullingConverter = [](CullMode val) -> String {
        if (val == CullMode::CULL_CCW)
            return "Counter-clockwise";
        else if (val == CullMode::CULL_CW)
            return "Clockwise";
        return "None";
    };

    int cullMode = material_->GetCullMode();
    int oldCullMode = cullMode;
    ImGui::Text("Culling");
    if (ImGui::Combo("##culling", &cullMode, CULL_STRINGS))
        GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<CullMode>>(this, "Face Culling Mode", material_.Get(), &Material::SetCullMode, (CullMode)oldCullMode, (CullMode)cullMode, CullingConverter))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

    if (ImGui::CollapsingHeader("Shadows"))
    {
        WidthIndentScope scope;

        int cullMode = material_->GetShadowCullMode();
        int oldCullMode = cullMode;
        ImGui::Text("Culling");
        if (ImGui::Combo("##shadowcull", &cullMode, CULL_STRINGS))
            GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<CullMode>>(this, "Shadow Face Culling Mode", material_.Get(), &Material::SetShadowCullMode, (CullMode)oldCullMode, (CullMode)cullMode, CullingConverter))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

        auto depthBias = material_->GetDepthBias();
        auto oldBias = depthBias;
        ImGui::Text("Constant Bias");
        if (ImGui::DragFloat("##constbias", &depthBias.constantBias_))
            GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<BiasParameters, BiasParameters, const BiasParameters&>>(this, "Constant Bias", material_.Get(), &Material::SetDepthBias, oldBias, depthBias, [](BiasParameters v) -> String { return String(v.constantBias_); }))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

        ImGui::Text("Slope Bias");
        if (ImGui::DragFloat("##slopebias", &depthBias.slopeScaledBias_))
            GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<BiasParameters, BiasParameters, const BiasParameters&>>(this, "Slope Scaled Bias", material_.Get(), &Material::SetDepthBias, oldBias, depthBias, [](BiasParameters v) -> String { return String(v.slopeScaledBias_); }))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

        ImGui::Text("Normal Offset");
        if (ImGui::DragFloat("##normoffset", &depthBias.normalOffset_))
            GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<BiasParameters, BiasParameters, const BiasParameters&>>(this, "Normal Offset", material_.Get(), &Material::SetDepthBias, oldBias, depthBias, [](BiasParameters v) -> String { return String(v.normalOffset_); }))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());
    }

    if (ImGui::CollapsingHeader("Textures"))
    {
        WidthIndentScope scope;

        for (int i = 0; i < 8; ++i)
        {
            auto tex = material_->GetTexture((TextureUnit)i);
            String texUnitName = Material::GetTextureUnitName((TextureUnit)i);
            texUnitName[0] = std::toupper(texUnitName[0]);
            ImGui::PushID(i + 1);
            
            ResourceRef ref("Texture", "");
            if (tex)
                ref.name_ = tex->GetName();

            auto oldRef = ref;
            ImGui::Text(texUnitName.CString());
            if (ImGuiElement::EditResourceRef("thing", ref))
                GetUndoStack().PushNew(std::make_shared<MaterialTextureUndo>(this, material_.Get(), i, oldRef, ref))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

            ImGui::PopID();
        }
    }

    if (ImGui::CollapsingHeader("Techniques"))
    {
        WidthIndentScope scope;

        Vector<TechniqueEntry> techniques = material_->GetTechniques();
        bool changed = false;
        ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth() - 30);
        for (size_t i = 0; i < techniques.Size(); ++i)
        {
            auto tech = techniques[i];
            ImGui::PushID(i + 500);
            ImGui::BeginGroup();
            ResourceRef r(StringHash("Technique"), tech.technique_ ? tech.technique_->GetName() : "");

            ImGui::Text("Technique");
            if (ImGuiElement::EditResourceRef("tech_res", r))
            {
                techniques[i].technique_ = cache->GetResource<Technique>(r.name_);
                changed = true;
            }

            ImGui::Text("LOD Distance");
            changed |= ImGui::DragFloat("##lod", &techniques[i].lodDistance_);

            ImGui::Text("Quality Level");
            changed |= ImGui::DragInt("##qol", &techniques[i].qualityLevel_, 1.0f, 0, 128);

            ImGui::EndGroup();
            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_MINUS "##asdfas"))
            {
                techniques.Erase(i);
                --i;
                changed = true;
            }
            ImGui::PopID();
        }
        ImGui::PopItemWidth();
        if (ImGui::Button(ICON_FA_PLUS))
        {
            techniques.Push(TechniqueEntry(new Technique(ctx), 0, 0));
            changed = true;
        }

        if (changed)
        {
            material_->SetNumTechniques(techniques.Size());
            for (size_t i = 0; i < techniques.Size(); ++i)
                material_->SetTechnique(i, techniques[i].technique_, techniques[i].qualityLevel_, techniques[i].lodDistance_);
            MarkDirty();
        }
    }

    if (ImGui::CollapsingHeader("Shader Data"))
    {
        WidthIndentScope scope;

        String defVert = material_->GetVertexShaderDefines();
        String oldDefVert = defVert;
        String defGeom = material_->GetGeometryShaderDefines();
        String oldDefGeom = defGeom;
        String defPix = material_->GetPixelShaderDefines();
        String oldDefPix = defPix;

        ImGui::Text("Vertex Shader Defines");
        if (ImGuiElement::EditString("##vert_def", defVert))
            GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<String, String, const String&> >(this, "Vertex Shader Defines", material_.Get(), &Material::SetVertexShaderDefines, oldDefVert, defVert))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());
        ImGui::Text("Geometry Shader Defines");
        if (ImGuiElement::EditString("##geom_def", defGeom))
            GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<String, String, const String&> >(this, "Geometry Shader Defines", material_.Get(), &Material::SetGeometryShaderDefines, oldDefGeom, defGeom))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());
        ImGui::Text("Pixel Shader Defines");
        if (ImGuiElement::EditString("##pixel_def", defPix))
            GetUndoStack().PushNew(std::make_shared<MaterialUndoRedo<String, String, const String&> >(this, "Pixel Shader Defines", material_.Get(), &Material::SetPixelShaderDefines, oldDefPix, defPix))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());

        ImGui::Text("Shader Parameters");

        float w = ImGui::GetContentRegionAvailWidth();
        bool changed = false;
        static int varTypeIndex = 0;
        static String newVarName;
        ImGui::PushItemWidth((w - 50) / 2);
        ImGui::Combo("##type", &varTypeIndex, "Int\0Float\0Vector2\0Vector3\0Vector4\0Color\0\0");
        ImGui::SameLine();
        ImGuiElement::EditString("##new_var_name", newVarName);
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_PLUS))
        {
            if (!newVarName.Empty())
            {
                switch (varTypeIndex) {
                case 0: GetUndoStack().PushNew(std::make_shared<MaterialShaderParamCreateDelete>(this, material_.Get(), MaterialShaderParameter { newVarName, (int)0 }, true))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get()); break;
                case 1: GetUndoStack().PushNew(std::make_shared<MaterialShaderParamCreateDelete>(this, material_.Get(), MaterialShaderParameter { newVarName, 0.0f }, true))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get()); break;
                case 2: GetUndoStack().PushNew(std::make_shared<MaterialShaderParamCreateDelete>(this, material_.Get(), MaterialShaderParameter { newVarName, Vector2(0,0) }, true))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get()); break;
                case 3: GetUndoStack().PushNew(std::make_shared<MaterialShaderParamCreateDelete>(this, material_.Get(), MaterialShaderParameter { newVarName, Vector3(0,0,0) }, true))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get()); break;
                case 4: GetUndoStack().PushNew(std::make_shared<MaterialShaderParamCreateDelete>(this, material_.Get(), MaterialShaderParameter { newVarName, Vector4(0,0,0,0) }, true))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get()); break;
                case 5: GetUndoStack().PushNew(std::make_shared<MaterialShaderParamCreateDelete>(this, material_.Get(), MaterialShaderParameter { newVarName, Color(1,1,1,1) }, true))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get()); break;
                }
            }
        }

        ImGui::PushItemWidth((w-50) * 0.5f);
        for (size_t i = 0; i < materialParams_.Size(); ++i)
        {
            auto& param = materialParams_[i];
            MaterialShaderParameter oldParam = { param.name_, param.value_ };
            ImGui::PushID(i);
            String name = param.name_;
            if (ImGuiElement::EditString("##pk_name", name))
            {
                material_->RemoveShaderParameter(param.name_);
                material_->SetShaderParameter(name, param.value_);
                param.name_ = name;
            }
            ImGui::SameLine();
            if (ImGuiElement::EditVariant(param.value_))
                GetUndoStack().PushNew(std::make_shared<MaterialShaderParamEdit>(this, material_.Get(), oldParam, param))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());
            ImGui::SameLine();
            if (ImGui::Button((ICON_FA_MINUS "##" + param.name_).CString(), ImVec2(30, 30)))
            {
                GetUndoStack().PushNew(std::make_shared<MaterialShaderParamCreateDelete>(this, material_.Get(), param, false))->RecordStandardSelectables(DocumentManager::Get()->GetActiveDocument().get());
                --i;
            }
            ImGui::PopID();
        }
        ImGui::PopItemWidth();
    }

    ImGui::PopItemWidth();    
}

void MaterialDocument::DrawMasterButtons()
{
    
}
