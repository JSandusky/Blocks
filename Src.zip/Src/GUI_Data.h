#pragma once

#include <Urho3D/Input/Input.h>
#include <Urho3D/Container/Str.h>

struct EditorShortCut
{
    int keyCode_ = -1;
    bool control_ = false;
    bool shift_ = false;
    bool alt_ = false;

    EditorShortCut();
    EditorShortCut(const Urho3D::String& path);

    void SetFromString(const Urho3D::String& path);
    bool Check() const;
    Urho3D::String GetText() const;
    void Reset();

    bool operator==(const EditorShortCut&) const;
};