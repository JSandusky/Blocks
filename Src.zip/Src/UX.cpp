#include "UX.h"

#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Graphics/Graphics.h>
#include <Urho3D/Input/Input.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Graphics/Texture2D.h>
#include <Urho3D/Resource/XMLElement.h>
#include <Urho3D/Resource/XMLFile.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/imgui_internal.h>
#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include "Block.h"
#include "Doc_SelectableAction.h"
#include "Doc_DocumentManager.h"

#include <algorithm>

#include <Urho3D/DebugNew.h>

const Urho3D::Color UIColors::SelectionColor(0.63f, 0.63f, 0.38f);
const Urho3D::Color UIColors::PassiveColor(0.7f, 0.7f, 0.7f);
const Urho3D::Color UIColors::XColor(1.0f, 0.0f, 0.0f);
const Urho3D::Color UIColors::YColor(0.0f, 1.0f, 0.0f);
const Urho3D::Color UIColors::ZColor(0.0f, 0.0f, 1.0f);
const Urho3D::Color UIColors::XColor_Dim(0.7f, 0.0f, 0.0f);
const Urho3D::Color UIColors::YColor_Dim(0.0f, 0.7f, 0.0f);
const Urho3D::Color UIColors::ZColor_Dim(0.0f, 0.0f, 0.7f);

static bool g_AutoMenuPushSeparator = false;

bool ImGuiUX::AutoMenu(const char* txt)
{
    if (g_AutoMenuPushSeparator)
    {
        ImGui::Separator();
        g_AutoMenuPushSeparator = false;
    }
    return ImGui::MenuItem(txt);
}

bool ImGuiUX::AutoMenu(const char* txt, const char* bind)
{
    if (g_AutoMenuPushSeparator)
    {
        ImGui::Separator();
        g_AutoMenuPushSeparator = false;
    }
    return ImGui::MenuItem(txt, bind);
}

void ImGuiUX::CheckAutoSeparator()
{
    if (g_AutoMenuPushSeparator)
        ImGui::Separator();
    g_AutoMenuPushSeparator = false;
}

void ImGuiUX::AutoSeparator()
{
    g_AutoMenuPushSeparator = true;
}

void ImGuiUX::EndAutoMenu()
{
    g_AutoMenuPushSeparator = false;
}

void ImGuiUX::StandardPopupChecks()
{
    if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
        ImGui::CloseCurrentPopup();
}

bool ImGuiUX::MenuButton(const char* txt, const char* popup, const char* tip)
{
    if (ImGui::Button(txt, ImVec2(36,36)))
    {
        ImGui::CloseCurrentPopup();
        ImGui::OpenPopup(popup);
        return true;
    }
    if (ImGui::IsItemHovered() && tip)
        ImGui::SetTooltip(tip);
    return false;
}

bool ImGuiUX::ToggleMenuButton(const char* text, const char* menuID, const char* tip, bool state)
{
    if (ImGuiUX::ToggleButton(text, state))
    {
        ImGui::CloseCurrentPopup();
        ImGui::OpenPopup(menuID);
        return true;
    }
    if (ImGui::IsItemHovered() && tip)
        ImGui::SetTooltip(tip);
    return false;
}

bool ImGuiUX::ToggleButton(const char* text, bool state)
{
    if (state)
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(.3f, .4f, .8f, 1.0f));

    bool ret = ImGui::Button(text, ImVec2(36,36));

    if (state)
        ImGui::PopStyleColor();

    return ret;
}

bool ImGuiUX::ButtonedText(const char* text, const char* buttonText)
{
    ImGui::Text(text); 
    ImGui::SameLine(ImGui::GetWindowContentRegionWidth() - 16);
    return ImGui::Button(ICON_FA_SYNC_ALT);
}

void ImGuiUX::PushBold()
{
    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[1]);
}

void ImGuiUX::PopBold()
{
    ImGui::PopFont();
}

void ImGuiUX::PushLargeBold()
{
    ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
}
void ImGuiUX::PopLargeBold()
{
    ImGui::PopFont();
}

ErrorMessage::ErrorMessage(const std::string& msg)
{
    message_ = msg;
}
ErrorMessage::ErrorMessage(const std::string& msg, const std::string& title)
{
    title_ = title;
    message_ = msg;
}
ErrorMessage::ErrorMessage(const std::string& msg, const std::string& title, const std::vector<ErrorButton>& buttons) : ErrorMessage(msg, title)
{
    buttons_ = buttons;
}

ModalWindow::ModalWindow(const std::string& msg, std::function<bool()> windowFunc)
{
    title_ = msg;
    windowFunction_ = windowFunc;
}

std::unique_ptr<ModalWindows> ModalWindows::inst_ = nullptr;

void ModalWindows::Run()
{
    bool pop = true;

    float w = BlockExe::GetInst()->GetSubsystem<Graphics>()->GetWidth();
    float ht = BlockExe::GetInst()->GetSubsystem<Graphics>()->GetHeight();
    for (size_t i = 0; i < nonModals_.size(); ++i)
    {
        auto& curMsg = nonModals_[i];
        ImGui::PushStyleColor(ImGuiCol_TitleBgActive, ImVec4(0.2, 0.2, 0.2, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButton, ImVec4(0.3, 0.3, 0.3, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButtonHovered, ImVec4(0.6, 0.3, 0, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButtonActive, ImVec4(0.8, 0.5, 0, 1));
        ImGui::SetNextWindowSizeConstraints(ImVec2(480, 0), ImVec2(480, 1080));

        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
        bool opened = true;
        ImGui::SetNextWindowSizeConstraints(ImVec2(400, 0), ImVec2(w * 0.5f, ht * 0.75f));
        opened = ImGui::Begin(curMsg.title_.c_str(), &pop, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_AlwaysAutoResize);
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
        if (opened)
        {
            opened &= curMsg.windowFunction_();
            ImGui::PopFont();
            ImGui::End();
        }
        else
            ImGui::PopFont();
        ImGui::PopFont();
        ImGui::PopStyleColor(4);

        if (!opened || !pop)
        {
            nonModals_.erase(nonModals_.begin() + i);
            --i;
        }
    }

    pop = true;
    if (messages_.size() > 0)
    {
        auto& curMsg = messages_.front();
        ImGui::OpenPopup(curMsg.title_.c_str());

        ImGui::PushStyleColor(ImGuiCol_ModalWindowDarkening, ImVec4(0.6, 0.2, 0.2, 0.33));
        ImGui::PushStyleColor(ImGuiCol_TitleBgActive, ImVec4(0.8, 0, 0, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButton, ImVec4(0.3, 0.3, 0.3, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButtonHovered, ImVec4(0.6, 0.3, 0, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButtonActive, ImVec4(0.8, 0.5, 0, 1));
        ImGui::SetNextWindowSizeConstraints(ImVec2(300, 100), ImVec2(480, 480));
        if (ImGui::BeginPopupModal(curMsg.title_.c_str(), &pop, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize))
        {
            ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());
            ImGui::TextWrapped(curMsg.message_.c_str());
            ImGui::PopItemWidth();

            ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 20);
            ImGui::Separator();

            float w = ImGui::GetWindowContentRegionWidth();
            if (curMsg.buttons_.empty())
                ImGui::SetCursorPosX(w - 80);
            else
                ImGui::SetCursorPosX(w - 80*curMsg.buttons_.size());

            for (size_t i = 0; i < curMsg.buttons_.size(); ++i)
            {
                if (i > 0)
                    ImGui::SameLine();
                if (ImGui::Button(curMsg.buttons_[i].text_.c_str()))
                {
                    pop = false;
                    if (curMsg.buttons_[i].call_)
                        curMsg.buttons_[i].call_();
                }
            }

            if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
            {
                pop = false;
                //if (curMsg.onCancel_)
                //    curMsg.onCancel_();
            }

            ImGui::EndPopup();
        }
        ImGui::PopStyleColor(5);
    }

    if (windows_.size() > 0)
    {
        auto& curMsg = windows_.front();
        ImGui::OpenPopup(curMsg.title_.c_str());

        ImGui::PushStyleColor(ImGuiCol_ModalWindowDarkening, ImVec4(0.0, 0.0, 0.0, 0.66));
        ImGui::PushStyleColor(ImGuiCol_TitleBgActive, ImVec4(0.2, 0.2, 0.2, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButton, ImVec4(0.3, 0.3, 0.3, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButtonHovered, ImVec4(0.6, 0.3, 0, 1));
        ImGui::PushStyleColor(ImGuiCol_CloseButtonActive, ImVec4(0.8, 0.5, 0, 1));
        ImGui::SetNextWindowSizeConstraints(ImVec2(480, 0), ImVec2(480, 400));
     
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
        ImGui::SetNextWindowSizeConstraints(ImVec2(400, 0), ImVec2(w * 0.5f, ht * 0.75f));
        bool opened = ImGui::BeginPopupModal(curMsg.title_.c_str(), &pop, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_AlwaysAutoResize);
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
        if (opened)
        {
            pop &= curMsg.windowFunction_();

            if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
                pop = false;

            ImGui::PopFont();
            ImGui::EndPopup();
        }
        else
            ImGui::PopFont();

        if (!ImGui::IsPopupOpen(curMsg.title_.c_str()))
            pop = false;

        ImGui::PopFont();
        ImGui::PopStyleColor(5);
    }

    if (!pop && messages_.size() > 0)
        messages_.erase(messages_.begin());
    else if (!pop && windows_.size() > 0)
        windows_.erase(windows_.begin());
}

void ModalWindows::Push(const ErrorMessage& msg)
{
    messages_.push_back(msg);
}

void ModalWindows::PushModal(const ModalWindow& win)
{
    windows_.push_back(win);
}

void ModalWindows::PushTool(const ModalWindow& win)
{
    // don't reinsert
    for (auto& nm : nonModals_)
    {
        if (nm.title_ == win.title_)
        {
            return;
        }
    }

    nonModals_.push_back(win);
}

ModalWindows* ModalWindows::Get()
{
    if (inst_ == nullptr)
        inst_.reset(new ModalWindows());
    return inst_.get();
}

std::unique_ptr<MouseCapture> MouseCapture::inst_;

void MouseCapture::Capture(IMouseCapture* cap, int forButton)
{
    if (Get()->active_ == nullptr)
    {
        Get()->capturedButton_ = forButton;
        Get()->active_ = cap;
        Get()->context_->GetSubsystem<Urho3D::Input>()->SetMouseMode(Urho3D::MM_RELATIVE);
        Get()->context_->GetSubsystem<Urho3D::Input>()->SetMouseVisible(false);
    }
}

bool MouseCapture::ProcessKeys()
{
    if (Get()->active_)
    {
        if (Get()->active_->ProcessKeys())
            return true;
        Get()->active_->EndCapture();
        Get()->active_ = nullptr;
    }
    return false;
}

bool MouseCapture::Process(const Urho3D::IntVector2& pos, const Urho3D::IntVector2& delta)
{
    if (Get()->active_)
    {
        if (Get()->active_->ProcessCapture(pos, delta))
            return true;
        Get()->active_->EndCapture();
    }
    Get()->active_ = nullptr;
    return false;
}

MouseCapture* MouseCapture::Get()
{
    if (inst_ == nullptr)
        inst_.reset(new MouseCapture());
    return inst_.get();
}

void MouseCapture::Deactivate()
{
    if (active_)
        active_->EndCapture();
    Get()->context_->GetSubsystem<Urho3D::Input>()->SetMouseMode(Urho3D::MM_FREE);
    Get()->context_->GetSubsystem<Urho3D::Input>()->SetMouseVisible(true);
    active_ = nullptr;
}

static Urho3D::HashMap<Urho3D::String, ImVec4> editorIcons_;
static intptr_t editorIconTexture_ = -1;

intptr_t GetEditorIconTexture()
{
    if (editorIconTexture_ == -1)
    {
        auto imguiElem = BlockExe::GetInst()->GetImGuiElem();

        auto cache = BlockExe::GetInst()->GetSubsystem<ResourceCache>();

        auto tex = cache->GetResource<Texture2D>("Textures/Editor/EditorIcons.png");

        editorIconTexture_ = 4999;
        imguiElem->AddTexture(editorIconTexture_, SharedPtr<Texture2D>(tex));

        float w = tex->GetWidth();
        float h = tex->GetHeight();

        auto texXml = cache->GetResource<XMLFile>("UI/EditorIcons.xml");
        XMLElement elem = texXml->GetRoot().GetChild("element");
        while (!elem.IsNull())
        {
            String typeName = elem.GetAttribute("type");
            XMLElement attrElem = elem.GetChild("attribute");
            Vector4 imgRect;

            if (attrElem.GetAttribute("name") != "Image Rect")
                attrElem = attrElem.GetNext("attribute");
            imgRect = Variant(VAR_VECTOR4, attrElem.GetAttribute("value")).GetVector4();

            editorIcons_[typeName] = ImVec4(imgRect.x_ / w, imgRect.y_ / h, imgRect.z_ / w, imgRect.w_ / h);

            elem = elem.GetNext("element");
        }
    }
    return editorIconTexture_;
}

ImVec4 GetEditorIconUV(const String& icon)
{
    const auto found = editorIcons_.Find(icon);
    if (found != editorIcons_.End())
        return found->second_;
    return ImVec4();
}

static bool     showingQuickAction = false;
static bool     quick_justShowed = false;
void ShowQuickAction(bool shouldOpen)
{
    auto input = BlockExe::GetInst()->GetSubsystem<Input>();
    if (showingQuickAction == false)
    {
        showingQuickAction = shouldOpen;
        quick_justShowed = true;
    }
    else
        showingQuickAction = ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)) ? false : showingQuickAction;

    if (showingQuickAction && quick_justShowed)
        ImGui::OpenPopup("Quick Action");

    ActionList list;
    if (auto dCast = dynamic_cast<IQuickActionSource*>(DocumentManager::Get()->GetActiveDocument().get()))
        dCast->CollectActions(list);
    
    auto binds = BlockExe::GetInst()->GetSubsystem<Input>()->GetInputBindings();
    for (size_t i = 0; i < binds.Size(); ++i)
        list.push_back(binds[i]);

    IQuickActionSource::FilterActions(list);
    //std::sort(list.begin(), list.end(), [](const SharedPtr<InputBinding>& lhs, const SharedPtr<InputBinding>& rhs) -> bool {
    //    if (lhs->groupName_.Compare(rhs->groupName_) < 0)
    //        return true;
    //    return false;
    //});

    bool forceClosed = false;
    ImGui::SetNextWindowSize(ImVec2(320, 480), ImGuiCond_Once);
    if (ImGui::BeginPopupModal("Quick Action", &showingQuickAction, ImGuiWindowFlags_NoCollapse | ImGuiWindowFlags_NoScrollbar))
    {
        //std::string searchText;
        if (ImGui::IsWindowAppearing())
            ImGui::SetKeyboardFocusHere();

        static ImGuiTextFilter filterNodes;
        filterNodes.Draw("");
        quick_justShowed = false;

        bool retDown = ImGui::IsKeyDown(ImGui::GetKeyIndex(ImGuiKey_Enter));

        ImGui::BeginChild("##options");

        for (size_t i = 0; i < list.size(); ++i)
        {
            if (!filterNodes.IsActive() || filterNodes.PassFilter(list[i]->actionName_.CString()))
            {
                // if return is hit then pick the first key
                if (ImGui::MenuItem(list[i]->actionName_.CString(), list[i]->groupName_.CString()) || input->GetKeyPress(KEY_RETURN))
                {
                    showingQuickAction = false;
                    if (auto c = dynamic_cast<AppAction*>(list[i].Get()))
                        c->ForceTrigger();
                }
            }
        }

        ImGui::EndChild();
        ImGui::EndPopup();
    }
    else
        showingQuickAction = false;
}