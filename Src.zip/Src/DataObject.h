#pragma once

#include <Urho3D/Resource/XMLElement.h>
#include <Urho3D/Core/Variant.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>

#include "Doc_DocumentManager.h"

#include <functional>
#include <memory>
#include <unordered_map>
#include <vector>

namespace Urho3D
{
    class XMLElement;
}

#define DF_POSITIVE (1)
// Path to an executable for a cmd-line program (cubemap filtering)
#define DF_PATH_EXE (1 << 1)
// as Vector4, but min/max packed into Z/W, will render as a ranged slider
#define DF_RANGED (1 << 2)
// Gets 64, 128, 256, 512, 1024, 2048, 4096 as options
#define DF_TEXTURE_SIZE (1 << 3)
// String is a path to a folder.
#define DF_FOLDER_PATH (1 << 4)
// Field (VariantVector) is a list of child DataObject's
#define DF_CHILD_LIST (1 << 5)
// Field is an identifier such as a name or ID
#define DF_PRIMARY_KEY (1 << 6)
#define DF_SPLITTER (1 << 7)

/// A property-member of a DataObject.
struct DataObjectField
{
    /// Name to be used for GUI display of the field.
    std::string displayName_;
    /// Internal name of the field for identification.
    std::string fieldName_;
    /// Default value to be used at initialization.
    Urho3D::Variant defaultValue_;
    /// Flags of additional traits of the field.
    unsigned dataFieldSettings_ = 0;

    /// Construct a new field.
    DataObjectField(const std::string& fieldName, const Urho3D::Variant& var, unsigned fieldSettings = 0)
    {
        fieldName_ = fieldName;
        defaultValue_ = var;
        dataFieldSettings_ = fieldSettings;
    }
};

/// A 'class' of a DataObject.
class DataObjectDefinition : public std::vector<DataObjectField>
{
public:
    /// Type of an actionalble command that can be executed against an instance of the DataObject.
    typedef std::vector < std::pair<std::string, std::function<void(class DataObject*)> > > DataObjectCmds;

    /// Text to be displayed for the DataObject type.
    std::string displayTitle_;
    /// Assitance text for explaining the purpose of the class.
    std::string displayDescription_;

    /// Internal name of the class.
    std::string objectTypeName_;
    /// Actionable commands that can be executed on instances of the class.
    DataObjectCmds commands_;
    /// Cached indices of field locations, keyed on the DataObjectField::fieldName_.
    std::unordered_map<std::string, unsigned> fieldIndices_;

    /// Construct a new class for DataObjects.
    DataObjectDefinition(const std::string& typeName, const std::vector<DataObjectField>& fields, const DataObjectCmds& cmds = DataObjectCmds());
};

/// General purpose data-container for application state and configuration.
class DataObject : public std::vector<Urho3D::Variant>
{
public:
    typedef std::function<void(const std::string& name, const Urho3D::Variant&)> ChangeCallback;

    /// Construct an instance of a specific 'class'.
    DataObject(const DataObjectDefinition* definition);

    /// Returns the index of the named property, -1 if not found.
    size_t IndexOf(const std::string& name) const;
    /// Returns the value of a field, or an empty Variant if not found.
    Urho3D::Variant GetField(const std::string& name) const;
    /// Sets the value of a field.
    void SetField(const std::string& name, const Urho3D::Variant& value);
    /// Returns the 'type data' of this DataObject.
    const DataObjectDefinition* GetDefinition() const { return definition_; }

    /// Writes field data into an XML root element.
    void SaveXML(Urho3D::XMLElement& intoElement);
    /// Reads field data from an XML element.
    void LoadXML(Urho3D::XMLElement& fromElement);

    /// Helper function for displaying a quick UI for a DataObject.
    static void DrawEditor(DataObject* forObject);

    void SetOnChange(ChangeCallback call) { onChange_ = call; }

private:
    void DispatchChange(const std::string&, const Urho3D::Variant&);

    ChangeCallback onChange_;
    /// Definition for this 'class' of object.
    const DataObjectDefinition* definition_;
};

/// Contains all known DataObject 'classes'.
class DataObjectDatabase
{
public:
    /// Destruct and free data.
    ~DataObjectDatabase();

    /// Record a 'class' with the database.
    void Register(DataObjectDefinition* definition);
    /// Get a 'class' definition by name, keyed on DataObjectDefinition::objectTypeName_.
    DataObjectDefinition* GetType(const std::string& typeDef);

    /// Returns the singleton instance.
    static DataObjectDatabase* GetInst();

private:
    /// Construct, hide away from access outside of the singleton accessor.
    DataObjectDatabase();

    /// List of all available DataObject 'classes'.
    std::vector<DataObjectDefinition*> definitions_;

    /// Singleton instance.
    static std::unique_ptr<DataObjectDatabase> inst_;
};

/// Specialization of the Selectable class for working with a DataObject.
class DataObjectSelectable : public Selectable
{
public:
    /// Construct for DataObject.
    DataObjectSelectable(DataObject* dataObject);

    /// Returns true if raw object 't' is equivalent to the contained data.
    virtual bool Is(void* t) const override;
    /// Returns true if the given selectable is equivalent to the contained data.
    virtual bool Is(std::shared_ptr<Selectable> t) const override;

    /// Render an ImGui editor for the contained DataObject.
    void DrawProperties(const ImGuiTextFilter* filter);

    /// Contained DataObject instance.
    DataObject* dataObject_;
};