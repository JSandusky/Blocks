#pragma once

#include <Urho3D/Container/Ptr.h>
#include <Urho3D/Core/Variant.h>

#include "Doc_DocumentManager.h"

namespace Urho3D
{
    class Component;
    class Node;
    class Serializable;
}

struct UrhoAttributeUndoRedo : public UndoRedo
{
    UrhoAttributeUndoRedo(Urho3D::SharedPtr<Urho3D::Serializable> target, unsigned attrIndex, Urho3D::Variant oldVal, Urho3D::Variant newVal);
    ~UrhoAttributeUndoRedo();

    virtual Urho3D::String GetText() override { return text_; }
    virtual void Execute(bool isUndo, DocumentBase* forDoc) override;
    virtual bool CanMergeWith(UndoRedo* rhs) const override;
    virtual void Merge(UndoRedo* rhs) override;

    void UpdateText();

    unsigned attributeIndex_;
    Urho3D::SharedPtr<Urho3D::Serializable> target_;
    Urho3D::Variant oldValue_;
    Urho3D::Variant newValue_;
    Urho3D::String text_;
};

struct UrhoCreateDeleteNodeUndoRedo : public UndoRedo
{
    UrhoCreateDeleteNodeUndoRedo(Urho3D::SharedPtr<Urho3D::Node> parent, Urho3D::SharedPtr<Urho3D::Node> target, bool isCreate);
    ~UrhoCreateDeleteNodeUndoRedo();

    virtual Urho3D::String GetText() override { return text_; }
    virtual void Execute(bool isUndo, DocumentBase* forDoc) override;

    Urho3D::SharedPtr<Urho3D::Node> parent_;
    Urho3D::SharedPtr<Urho3D::Node> target_;
    Urho3D::String text_;
    bool isCreate_;
    unsigned id_;
    unsigned oldIndex_;
};

struct UrhoCreateDeleteComponentUndoRedo : public UndoRedo
{
    UrhoCreateDeleteComponentUndoRedo(Urho3D::SharedPtr<Urho3D::Node> parent, Urho3D::SharedPtr<Urho3D::Component> target, bool isCreate);
    ~UrhoCreateDeleteComponentUndoRedo();

    virtual Urho3D::String GetText() override { return text_; }
    virtual void Execute(bool isUndo, DocumentBase* forDoc) override;

    Urho3D::SharedPtr<Urho3D::Node> parent_;
    Urho3D::SharedPtr<Urho3D::Component> target_;
    Urho3D::String text_;
    bool isCreate_;
};

struct UrhoMoveNodeUndoRedo : public UndoRedo
{
    UrhoMoveNodeUndoRedo(Urho3D::SharedPtr<Urho3D::Node> movedNode, Urho3D::SharedPtr<Urho3D::Node> oldParent, Urho3D::SharedPtr<Urho3D::Node> newParent);
    ~UrhoMoveNodeUndoRedo();

    virtual Urho3D::String GetText() override { return text_; }
    virtual void Execute(bool isUndo, DocumentBase* forDoc) override;
    virtual bool CanMergeWith(UndoRedo* rhs) const override;
    virtual void Merge(UndoRedo* rhs) override;

    void UpdateText();

    Urho3D::SharedPtr<Urho3D::Node> newParent_;
    Urho3D::SharedPtr<Urho3D::Node> oldParent_;
    Urho3D::SharedPtr<Urho3D::Node> target_;
    unsigned oldIndex_;
    Urho3D::String text_;
};

struct UrhoMoveComponentUndoRedo : public UndoRedo
{
    UrhoMoveComponentUndoRedo(Urho3D::SharedPtr<Urho3D::Component> movedComp, Urho3D::SharedPtr<Urho3D::Node> oldParent, Urho3D::SharedPtr<Urho3D::Node> newParent);
    ~UrhoMoveComponentUndoRedo();

    virtual Urho3D::String GetText() override { return text_; }
    virtual void Execute(bool isUndo, DocumentBase* forDoc) override;
    virtual bool CanMergeWith(UndoRedo*) const override;
    virtual void Merge(UndoRedo*) override;

private:
    Urho3D::SharedPtr<Urho3D::Node> newParent_;
    Urho3D::SharedPtr<Urho3D::Node> oldParent_;
    Urho3D::SharedPtr<Urho3D::Component> target_;

    void UpdateText();

    Urho3D::String text_;
};