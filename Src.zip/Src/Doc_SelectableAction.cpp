#include "Doc_SelectableAction.h"

#include <Urho3D/Core/Context.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>

#include "Block.h"
#include "UX.h"

using namespace Urho3D;

AppAction::AppAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip) : 
    Urho3D::InputBinding(grp, act, tip)
{

}

AppAction::AppAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call) : 
    Urho3D::InputBinding(grp, act, tip),
    callback_(call)
{

}

AppAction::AppAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call, TEST_DEF test) :
    Urho3D::InputBinding(grp, act, tip),
    callback_(call),
    callTest_(test)
{

}

AppAction::~AppAction()
{

}

bool AppAction::IsAvailable() const
{
    if (!InputBinding::IsAvailable())
        return false;
    if (callTest_)
        return callTest_();
    return true;
}

void AppAction::Activated()
{
    if (callback_)
        callback_();
}

void AppAction::ForceTrigger()
{
    auto block = BlockExe::GetInst();
    auto& eventData = block->GetEventDataMap();
    eventData[BindingTriggered::P_ACTION] = this->actionName_;
    eventData[BindingTriggered::P_GROUP] = this->groupName_;

    Activated();
    block->SendEvent(E_BINDINGTRIGGERED, eventData);
}

bool AppAction::DrawMenuItem()
{
    // does not care about hidden status
    if (!IsAvailable())
        return false;
    String bindText = ToString();
    if (ImGuiUX::AutoMenu(actionName_.CString(), bindText != "< no binding >" ? bindText.CString() : 0x0))
        ForceTrigger();
    return true;
}

bool AppAction::DrawItems(std::vector<Urho3D::SharedPtr<Urho3D::InputBinding> >& actions)
{
    bool anyEmitted = false;
    for (auto act : actions)
    {
        if (act->hidden_)
            continue;

        if (auto aa = dynamic_cast<AppAction*>(act.Get()))
            anyEmitted |= aa->DrawMenuItem();
        else
        {
            if (!act->IsAvailable())
                continue;

            anyEmitted = true;
            String bindText = act->ToString();
            if (ImGui::MenuItem(act->actionName_.CString(), bindText.CString()))
            {
                auto block = BlockExe::GetInst();
                auto& eventData = block->GetEventDataMap();
                eventData[BindingTriggered::P_ACTION] = act->actionName_;
                eventData[BindingTriggered::P_GROUP] = act->groupName_;

                act->Activated();
                block->SendEvent(E_BINDINGTRIGGERED, eventData);
            }
        }
    }
    return anyEmitted;
}
