#include "Clipboard.h"

#include <Urho3D/DebugNew.h>

namespace Clipboard
{

    static Urho3D::VectorBuffer g_ClipboardData_;
    static unsigned g_ClipboardType_ = 0;

    unsigned GetClipboardDataType()
    {
        return g_ClipboardType_;
    }

    Urho3D::VectorBuffer& GetClipboardData()
    {
        return g_ClipboardData_;
    }

    void SetClipboardDataType(unsigned type)
    {
        g_ClipboardType_ = type;
    }

    void SetClipboardData(unsigned type, const Urho3D::VectorBuffer& buffer)
    {
        g_ClipboardType_ = type;
        g_ClipboardData_ = buffer;
    }

    void ClearClipboard()
    {
        g_ClipboardType_ = 0;
        g_ClipboardData_.Clear();
    }

}