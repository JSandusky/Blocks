#include "DocType_UI.h"

#include <Urho3D/Audio/Audio.h>
#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Core/Context.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Audio/SoundListener.h>
#include <Urho3D/UI/UI.h>
#include <Urho3D/UI/UIElement.h>

#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>
#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/imgui_internal.h>

#include "Block.h"
#include "GUI_Pane3D.h"

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

#define EDITOR_CAMERA_NAME "Editor Camera"

extern void SetupTestScene(Urho3D::SharedPtr<Urho3D::Scene> scene, Urho3D::SharedPtr<Urho3D::Node> camNode);

UIDocumentType::UIDocumentType() : DocumentType("User Interface (EXPERIMENTAL)", "User Interface (*.xml)|*.xml")
{

}

std::shared_ptr<DocumentBase> UIDocumentType::NewDocument()
{
    return std::make_shared<UIDocument>(BlockExe::GetInst()->GetContext());
}

std::shared_ptr<DocumentBase> UIDocumentType::OpenPath(const Urho3D::String& path)
{
    return std::make_shared<UIDocument>(BlockExe::GetInst()->GetContext(), path);
}

UIDocument::UIDocument(Urho3D::Context* ctx) :
    Document3D(ctx, SharedPtr<Scene>(new Scene(ctx)))
{
    CommonConstruct();
}

UIDocument::UIDocument(Urho3D::Context* ctx, const Urho3D::String& path) :
    Document3D(ctx, SharedPtr<Scene>(new Scene(ctx)))
{

    filePath_ = path.CString();
    name_ = Urho3D::GetFileNameAndExtension(path.CString(), true).CString();

    CommonConstruct();
    
    if (auto xmlFile = GetSubsystem<ResourceCache>()->GetResource<XMLFile>(path))
        root_->LoadXML(xmlFile->GetRoot());
}

UIDocument::~UIDocument()
{
    secretRoot_->SetVisible(false);

}

void UIDocument::CommonConstruct()
{
    SharedPtr<Node> cameraNode = SharedPtr<Node>(scene_->CreateChild(EDITOR_CAMERA_NAME));
    cameraNode->SetTemporary(true);
    auto camera = cameraNode->CreateComponent<Camera>();
    cameraNode->GetSubsystem<Audio>()->SetListener(cameraNode->CreateComponent<SoundListener>());

    SetupTestScene(scene_, cameraNode);

    secretRoot_ = new UIElement(GetContext());

    root_ = new UIElement(GetContext());
    ResourceCache* cache = GetSubsystem<ResourceCache>();
    XMLFile* xmlFile = cache->GetResource<XMLFile>("UI/DefaultStyle.xml");

    secretRoot_->SetDefaultStyle(xmlFile);
    root_->SetDefaultStyle(xmlFile);

    GetSubsystem<UI>()->GetRoot()->AddChild(secretRoot_);
    secretRoot_->AddChild(root_);
    secretRoot_->SetPriority(0);
    guiViews_->topViews_.push_back(new GUI_View3D(new View(this, cameraNode)));

    secretRoot_->SetEnabled(false);
}

void UIDocument::PreDraw()
{
    if (!scene_)
        return;
    auto lastDrawRect = guiViews_->topViews_[0]->lastDraw_;
    secretRoot_->SetPosition(lastDrawRect.left_, lastDrawRect.top_);
    secretRoot_->SetSize(lastDrawRect.Width(), lastDrawRect.Height());
    secretRoot_->SetClipChildren(true);
    root_->SetSize(secretRoot_->GetSize());
}

bool UIDocument::Save()
{
    if (filePath_.empty())
    {
        auto fileName = GetSaveFile_PairName("Save Material", "*.xml", "Material (*.xml)|*.xml");

        if (!fileName.first.empty())
        {
            filePath_ = fileName.first;
            name_ = fileName.second;
        }
        else
            return false;
    }

    XMLFile xmlFile(GetContext());
    root_->SaveXML(xmlFile.CreateRoot("element"));
    xmlFile.SaveFile(filePath_.c_str());
    ClearDirty();
    return true;
}

void UIDocument::SaveAs()
{
    auto oldFilePath = filePath_;
    filePath_.clear();
    if (Save())
    {

    }
    else
        filePath_ = oldFilePath; // if save fails then revert path
}

bool UIDocument::Close()
{
    Document3D::Close();
    scene_.Reset();
    return true;
}

void UIDocument::DrawDocumentTree(ImGuiTextFilter* filter)
{
    if (root_)
        ShowTree(root_.Get());
}

void UIDocument::ShowTree(Urho3D::UIElement* elem)
{
    if (!elem)
        return;

    const bool hasChildren = elem->GetNumChildren();
    
    int flags = 0;
    if (elem == root_)
        flags |= ImGuiTreeNodeFlags_DefaultOpen;
    if (!hasChildren)
        flags |= ImGuiTreeNodeFlags_Leaf;

    const bool isSelected = GetSelection().IsSelected(elem);
    if (isSelected)
        flags |= ImGuiTreeNodeFlags_Selected;

    String lbl = elem->GetName().Length() ? elem->GetName() : "< unnamed >";
    lbl += " : " + elem->GetTypeName();

    ImGui::PushID(elem);
    bool open = ImGui::TreeNodeEx("", flags);

    static UIElement* lastElem = nullptr;

    ImGui::SameLine();
    auto texSize = GetEditorIconUV(elem->GetTypeName());
    ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(20, 20), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w));
    ImGui::SameLine();
    ImGui::Selectable(lbl.CString());
    extern bool ImGui_MouseTrulyClicked(int);

    if (ImGui_MouseTrulyClicked(0))
    {
        if (!isSelected)
        {
            if (ImGui::GetIO().KeyCtrl)
                GetSelection().AddSelection(std::make_shared<UrhoUISelectable>(SharedPtr<UIElement>(elem)));
            else
                GetSelection().Select(std::make_shared<UrhoUISelectable>(SharedPtr<UIElement>(elem)));
        }
        else if (ImGui::GetIO().KeyCtrl && isSelected)
        {
            GetSelection().Deselect(elem);
        }
    }
    else if (ImGui::IsItemClicked(1))
    {
        ImGui::OpenPopup("ui_node_ctx");
        lastElem = elem;
    }

    if (open)
    {
        for (auto child : elem->GetChildren())
            ShowTree(child.Get());
        
        ImGui::TreePop();
    }

    if (lastElem == elem && ImGui::BeginPopup("ui_node_ctx"))
    {
        if (ImGui::MenuItem(ICON_FA_PLUS " Load UI Child"))
        {
            auto path = OSOpenFile("Load UI", "*.xml", "User Interface XML|*.xml");
            if (!path.empty())
            {
                if (auto xmlFile = GetSubsystem<ResourceCache>()->GetResource<XMLFile>(path.c_str()))
                    root_->LoadChildXML(xmlFile->GetRoot(), 0x0);
            }
        }
        if (ImGui::MenuItem(ICON_FA_PAINT_BRUSH " Load Style"))
        {
            auto path = OSOpenFile("Load Style", "*.xml", "Style XML|*.xml");
            if (!path.empty())
            {
                if (auto xmlFile = GetSubsystem<ResourceCache>()->GetResource<XMLFile>(path.c_str()))
                    root_->SetStyle(xmlFile->GetRoot());
            }
        }
        if (ImGui::MenuItem(ICON_FA_SAVE " Save Subtree"))
        {
            auto path = GetSaveFile("Save UI Layout", "*.xml", "User Interface XML|*.xml");
            if (!path.empty())
            {
                XMLFile xmlFile(GetContext());
                lastElem->SaveXML(xmlFile.CreateRoot("element"));
                xmlFile.SaveFile(path.c_str());
            }
        }
        ImGui::Separator();
        DoCreateElement(elem);
        ImGui::Separator();
        if (ImGui::MenuItem(ICON_FA_TRASH " Delete"))
            lastElem->Remove();
        ImGui::EndPopup();
    }

    ImGui::PopID();
}

Urho3D::UIElement* UIDocument::DoCreateElement(Urho3D::UIElement* node)
{
    auto doc = DocumentManager::Get()->GetActiveDocument();

    Urho3D::UIElement* newComp = 0x0;
    auto ctx = node->GetContext();
    auto categories = ctx->GetObjectCategories();
    ImGuiUX::CheckAutoSeparator();
    for (auto cat : categories)
    {
        if (cat.first_ != "UI")
            continue;

        auto cont = cat.second_;
        for (auto ci : cont)
        {
            auto factory = ctx->GetObjectFactories()[ci]->Get();
            if (factory)
            {
                auto name = factory->GetTypeName();

                auto texSize = GetEditorIconUV(name);
                ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(20, 20), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w));
                ImGui::SameLine();
                if (ImGui::MenuItem(name.CString()))
                {
                    newComp = node->CreateChild(factory->GetType());
                    //??if (doc)
                    //??    doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteComponentUndoRedo>(SharedPtr<Node>(node), SharedPtr<Component>(newComp), true));
                }
            }
        }

    }
    return newComp;
}

void UIDocument::DrawMasterButtons()
{
    ImGuiUX::MenuButton(ICON_FA_SLIDERS_H, "#ui_load_save_manage", "Management");
    //ImGui::SameLine();

    if (ImGui::BeginPopup("#ui_load_save_manage"))
    {
        if (ImGui::MenuItem(ICON_FA_PLUS " Load UI Child"))
        {
            auto path = OSOpenFile("Load UI", "*.xml", "User Interface XML|*.xml");
            if (!path.empty())
            {
                if (auto xmlFile = GetSubsystem<ResourceCache>()->GetResource<XMLFile>(path.c_str()))
                    root_->LoadChildXML(xmlFile->GetRoot(), 0x0);
            }
        }
        if (ImGui::MenuItem(ICON_FA_PAINT_BRUSH " Load Style"))
        {
            auto path = OSOpenFile("Load Style", "*.xml", "Style XML|*.xml");
            if (!path.empty())
            {
                if (auto xmlFile = GetSubsystem<ResourceCache>()->GetResource<XMLFile>(path.c_str()))
                    root_->SetStyle(xmlFile->GetRoot());
            }
        }
        ImGui::Separator();
        if (ImGui::MenuItem(ICON_FA_ERASER " Clear"))
            root_->RemoveAllChildren();
        ImGui::EndPopup();
    }
}

void UIDocument::Activated()
{
    secretRoot_->SetEnabled(false);
    secretRoot_->SetVisible(true);
}

void UIDocument::Deactivated()
{
    secretRoot_->SetVisible(false);
}
