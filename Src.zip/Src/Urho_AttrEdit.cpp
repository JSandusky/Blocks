#include "Urho_AttrEdit.h"

#include <Urho3D/Scene/Component.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Scene/Node.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Scene/Serializable.h>
#include <Urho3D/Scene/Scene.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/imgui_ext.h>
#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include <windows.h>

#include "BitNames.h"
#include "Block.h"
#include "DataObject.h"
#include "Urho_Undo.h"
#include "UX.h"

//#include <Urho3D/DebugNew.h>

using namespace Urho3D;

HashMap<StringHash, const char*> FileTypeExtensions = {
    Pair<StringHash,const char*>(StringHash("Scene"), "Prefab (*.xml)|*.xml"),
    Pair<StringHash,const char*>(StringHash("Material"), "Material (*.xml)|*.xml"),
    Pair<StringHash,const char*>(StringHash("Model"), "Model (*.mdl)|*.mdl"),
    Pair<StringHash,const char*>(StringHash("Texture"), "Texture|*.dds;*.jpg;*.png;*.bmp;*.tga"),
    Pair<StringHash,const char*>(StringHash("Texture2D"), "2D Texture|*.dds;*.jpg;*.png;*.bmp;*.tga"),
    Pair<StringHash,const char*>(StringHash("Texture3D"), "3D Texture|*.dds;*.xml"),
    Pair<StringHash,const char*>(StringHash("TextureCube"), "Cubemap Texture|*.xml"),
    Pair<StringHash,const char*>(StringHash("Texture2DArray"), "Texture2D Array|*.xml"),
    Pair<StringHash,const char*>(StringHash("Sound"), "Sound|*.wav"),
    Pair<StringHash,const char*>(StringHash("Music"), "Music|*.ogg"),
    Pair<StringHash,const char*>(StringHash("LuaScript"), "Lua Scripts (*.lua)|*.lua"),
    Pair<StringHash,const char*>(StringHash("ScriptFile"), "Angelscript Scripts (*.as)|*.as"),
    Pair<StringHash,const char*>(StringHash("ParticleEffect"), "Particle Effect (*.xml)|*.xml"),
    Pair<StringHash,const char*>(StringHash("XMLFile"), "XML File (*.xml)|*.xml"),
    Pair<StringHash,const char*>(StringHash("Prefab"), "Prefab File (*.xml, *.bin)|*.xml;*.bin"),
    Pair<StringHash,const char*>(StringHash("Technique"), "Shading Technique (.xml)|*.xml"),
    Pair<StringHash,const char*>(StringHash("Font"), "Truetype Font (.ttf)|*.ttf")
};

String GetOpenFile(String title, const char* filter)
{
    OPENFILENAMEA saveFileStruct;
    memset(&saveFileStruct, 0, sizeof(OPENFILENAMEA));
    static char sz[MAX_PATH];
    memset(sz, 0, MAX_PATH);

    saveFileStruct.lStructSize = sizeof(saveFileStruct);
    saveFileStruct.lpstrDefExt = "*.xml";
    saveFileStruct.lpstrFile = sz;
    saveFileStruct.lpstrFile[0] = '\0';
    saveFileStruct.nMaxFile = MAX_PATH;
    saveFileStruct.lpstrTitle = title.CString();
    saveFileStruct.lpstrFilter = filter;

    auto result = GetOpenFileName(&saveFileStruct);
    if (saveFileStruct.lpstrFile[0] != '\0' && result == 1)
        return String(saveFileStruct.lpstrFile);

    return String();
}
static bool attr_ShowReset = true;
void ShowSerializableEditor(Urho3D::Serializable* who, UndoStack* undoStack, ImGuiTextFilter* filter)
{
    extern std::unique_ptr<DataObject> editorSettings_;
    attr_ShowReset = editorSettings_->GetField("Hide Property Reset Button").GetBool();
    if (who == nullptr)
    {
        ImGui::Text("< nothing selected >");
        return;
    }

    Scene* scene = dynamic_cast<Node*>(who) ? ((Node*)who)->GetScene() : 0x0;
    if (scene == nullptr)
        scene = dynamic_cast<Component*>(who) ? ((Component*)who)->GetScene() : 0x0;
    auto attributes = who->GetAttributes();

    ImGui::PushID(who);

    PODVector<StringHash> ignoreAttributes;
    PODVector<StringHash> lateAttributes;
    if (auto nd = dynamic_cast<Node*>(who))
    {
        lateAttributes.Push(StringHash("Tags"));
        lateAttributes.Push(StringHash("Variables"));

#if 0
        ignoreAttributes.Push(StringHash("Position"));
        ignoreAttributes.Push(StringHash("Rotation"));
        ignoreAttributes.Push(StringHash("Scale"));
        ignoreAttributes.Push(StringHash("Is Enabled"));
        ignoreAttributes.Push(StringHash("Name"));

        String name = nd->GetName();
        auto p = nd->GetWorldPosition();
        auto rot = nd->GetWorldRotation().EulerAngles();
        auto s = nd->GetWorldScale();
        bool enabled = nd->IsEnabled();

        ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());

        ImGui::Text("Name");
        if (ImGuiElement::EditString("##name", name))
            nd->SetName(name);

        if (ImGui::Checkbox("Enabled", &enabled))
            nd->SetEnabled(enabled);

        if (ImGuiUX::ButtonedText("Position", ICON_FA_SYNC))
            nd->SetWorldPosition(Vector3(0, 0, 0));
        if (ImGui::DragFloatN_Colored("##position", &p.x_, 3))
            nd->SetWorldPosition(p);

        ImGui::Text("Rotation");
        if (ImGui::DragFloatN_Colored("##rotation", &rot.x_, 3, 0.1f, -90.0f, 90.0f))
        {
            Quaternion q; q.FromEulerAngles(rot.x_, rot.y_, rot.z_);
            nd->SetWorldRotation(q);
        }

        ImGui::Text("Scale");
        if (ImGui::DragFloatN_Colored("##scale", &s.x_, 3))
            nd->SetWorldScale(p);

        ImGui::PopItemWidth();
#endif
    }

    for (int ii = 0; ii < 2; ++ii)
        for (unsigned attrIndex = 0; attrIndex < attributes->Size(); ++attrIndex)
        {
            auto& attr = (*attributes)[attrIndex];

            const StringHash nameHash = attr.name_;
            if (ii == 1 && !lateAttributes.Contains(nameHash))
                continue;
            else if (ii == 0 && lateAttributes.Contains(nameHash))
                continue;
            else if (ignoreAttributes.Contains(nameHash))
                continue;

            if (attr.mode_ & AM_NOEDIT)
                continue;

            if (filter->IsActive() && !filter->PassFilter(attr.name_.CString()))
                continue;

            EditAttribute(scene, who, &attr, attrIndex, undoStack);

            ImGui::PopID();
        }
    ImGui::PopID();
    return;
}

void EditAttribute(Urho3D::Scene* scene, Urho3D::Serializable* target, const StringHash& attrName, UndoStack* undoStack, bool noLabel)
{
    auto attrs = target->GetAttributes();
    unsigned idx = 0;
    for (auto& attr : *attrs)
    {
        if (StringHash(attr.name_) == attrName)
        {
            EditAttribute(scene, target, &attr, idx, undoStack, noLabel);
            return;
        }
        ++idx;
    }
}

void EditAttribute(Urho3D::Scene* scene, Urho3D::Serializable* who, const Urho3D::AttributeInfo* attrInfo, unsigned attrIndex, UndoStack* undoStack, bool noLabel)
{
    DocumentBase* doc = DocumentManager::Get()->GetActiveDocument().get();

    const Urho3D::AttributeInfo& attr = *attrInfo;

    Variant defVal = who->GetAttributeDefault(attrIndex);
    Variant value = who->GetAttribute(attrIndex);

    if (value.IsEmpty())
        return;

    Variant oldValue = value;
    ImGui::PushID(attrIndex);

    ImGui::PushItemWidth(-1);

    ImVec4 lblColor;
    if (value == defVal)
        lblColor = { 1,1,1,1 };
    else
        lblColor = { 0.39f, 1.0f, 0.39f, 1.0f };

    const String withoutLabel = String("##") + attr.name_;
    const char* labelLessName = withoutLabel.CString();

#define COMMON_LABEL()  if (!noLabel) { \
    float lblY = ImGui::GetCursorPosY(); \
if (attr.type_ != VAR_BOOL) ImGui::SetCursorPosY(lblY + 8); \
    ImGui::TextColored(lblColor, attr.name_.CString()); \
if (!attr_ShowReset) { \
    ImGui::SameLine(ImGui::GetWindowContentRegionWidth() - 16); \
    ImGui::PushID(&attr); \
    ImGui::SetCursorPosY(lblY); \
    if (ImGui::Button(ICON_FA_SYNC_ALT)) { undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, defVal))->RecordStandardSelectables(doc); } \
    ImGui::PopID(); } }

    if (attr.type_ == VAR_BOOL)
    {
        bool val = value.GetBool();
        if (ImGui::Checkbox(labelLessName, &val))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
        ImGui::SameLine();
        COMMON_LABEL();
    }
    else if (attr.type_ == VAR_INT)
    {
        if (attr.name_.EndsWith("Mask") || attr.name_.EndsWith("Flags"))
        {
            unsigned val = value.GetUInt();
            COMMON_LABEL();
            unsigned hoverIndex = -1;
            if (ImGui::BitField(labelLessName, &val, &hoverIndex))
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
            if (hoverIndex != -1) // todo: check for bitnames
            {
                auto bs = BlockExe::GetInst()->GetBitNames()->GetBitNames(attr.name_.CString());
                ImGui::SetTooltip(bs->bits_[hoverIndex].c_str());
                //ImGui::SetTooltip("Bit %i", (int)(hoverIndex + 1));
            }
        }
        else if (attr.enumNames_)
        {
            int ct = 0;
            for (; attr.enumNames_[ct] != 0x0; ++ct);

            COMMON_LABEL();
            int val = value.GetInt();
            if (ImGui::Combo(labelLessName, &val, attr.enumNames_, ct, -1))
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
        }
        else if (attr.mode_ & AM_NODEID || attr.mode_ & AM_COMPONENTID)
        {
            COMMON_LABEL();
            unsigned val = value.GetUInt();
            ImGui::BeginGroup();
            float w = ImGui::GetContentRegionAvailWidth();
            ImGui::PushItemWidth(w - 30);
            if (val == 0 || val == -1)
                ImGui::Text("< none >");
            else
            {
                if (Node* nd = dynamic_cast<Node*>(who))
                {
                    String txt = String(nd->GetID()) + " : " + nd->GetName();
                    ImGui::Text(txt.CString());
                }
                else if (Component* c = dynamic_cast<Component*>(who))
                {
                    auto nd = c->GetNode();
                    String txt = String(nd->GetID()) + " -> " + String(c->GetID()) + " : " + nd->GetName();
                    ImGui::Text(txt.CString());
                }
            }
            ImGui::PopItemWidth();
            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_ELLIPSIS_V))
            {
                //???
            }
            ImGui::EndGroup();
            if (ImGui::BeginDragDropTarget())
            {
                if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload(attr.mode_ & AM_NODEID ? "U_NODEID" : "U_COMPID"))
                {
                    unsigned nodeID = *((unsigned*)payload->Data);
                    undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, nodeID))->RecordStandardSelectables(doc);
                }
                ImGui::EndDragDropTarget();
            }
        }
        else
        {
            COMMON_LABEL();
            int val = value.GetInt();
            if (ImGui::DragInt(labelLessName, &val))
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
        }
    }
    else if (attr.type_ == VAR_FLOAT)
    {
        COMMON_LABEL();
        float val = value.GetFloat();
        if (ImGui::DragFloat(labelLessName, &val))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_DOUBLE)
    {
        COMMON_LABEL();
        float val = (float)value.GetDouble();
        if (ImGui::DragFloat(labelLessName, &val))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, (double)val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_STRING)
    {
        COMMON_LABEL();
        static char strSpace[4096];
        memset(strSpace, 0, 4096);
        auto str = value.GetString();
        strcpy(strSpace, str.CString());

        if (ImGui::InputText(labelLessName, strSpace, 4096))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, String(strSpace, strlen(strSpace))))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_STRINGVECTOR)
    {
        if (ImGui::TreeNode(attr.name_.CString()))
        {
            auto vec = value.GetStringVector();
            ImGui::BeginChild(ImGui::GetID(&attr), { ImGui::GetContentRegionAvailWidth() - 32, ImGui::GetFontSize() * 8 }, true, ImGuiWindowFlags_HorizontalScrollbar);
            for (unsigned i = 0; i < vec.Size(); ++i)
            {
                ImGui::PushID(i);
                auto text = vec[i];
                if (ImGuiElement::EditString("##v", text))
                {
                    vec[i] = text;
                    undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, vec))->RecordStandardSelectables(doc);
                }
                ImGui::SameLine();
                if (ImGui::Button(ICON_FA_TRASH))
                {
                    vec.Erase(i);
                    undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, vec))->RecordStandardSelectables(doc);
                }
                ImGui::PopID();
            }
            ImGui::EndChild();

            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_PLUS))
            {
                vec.Push("<new string>");
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, vec))->RecordStandardSelectables(doc);
            }

            ImGui::TreePop();
        }
    }
    else if (attr.type_ == VAR_INTVECTOR2)
    {
        COMMON_LABEL();
        auto val = value.GetIntVector2();
        if (ImGui::DragInt2(labelLessName, &val.x_))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_INTVECTOR3)
    {
        COMMON_LABEL();
        auto val = value.GetIntVector3();
        if (ImGui::DragInt3(labelLessName, &val.x_))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_INTRECT)
    {
        COMMON_LABEL();
        auto val = value.GetIntRect();
        if (ImGui::DragInt4(labelLessName, &val.left_))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_VECTOR2)
    {
        COMMON_LABEL();
        auto val = value.GetVector2();
        if (ImGui::DragFloat2(labelLessName, &val.x_))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_VECTOR3)
    {
        COMMON_LABEL();
        auto val = value.GetVector3();
        if (ImGui::DragFloatN_Colored(labelLessName, &val.x_, 3))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_VECTOR4)
    {
        COMMON_LABEL();
        auto val = value.GetVector4();
        if (ImGui::DragFloat4(labelLessName, &val.x_))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_QUATERNION)
    {
        COMMON_LABEL();
        auto val = value.GetQuaternion();
        auto euler = val.EulerAngles();
        if (ImGui::DragFloatN_Colored(labelLessName, &euler.x_, 3))
        {
            val.FromEulerAngles(euler.x_, euler.y_, euler.z_);
            if (val.IsNaN())
                val = Quaternion::IDENTITY;
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
        }
    }
    else if (attr.type_ == VAR_MATRIX3)
    {
        COMMON_LABEL();
        auto val = value.GetMatrix3();
        bool anyChanged = ImGui::DragFloat3("##a", &val.m00_);
        anyChanged |= ImGui::DragFloat3("##b", &val.m10_);
        anyChanged |= ImGui::DragFloat3("##c", &val.m20_);
        if (anyChanged)
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_MATRIX3X4)
    {
        COMMON_LABEL();
        auto val = value.GetMatrix3x4();
        bool anyChanged = ImGui::DragFloat4("##a", &val.m00_);
        anyChanged |= ImGui::DragFloat4("##b", &val.m10_);
        anyChanged |= ImGui::DragFloat4("##c", &val.m20_);
        if (anyChanged)
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_MATRIX4)
    {
        COMMON_LABEL();
        auto val = value.GetMatrix4();
        bool anyChanged = ImGui::DragFloat4("##a", &val.m00_);
        anyChanged |= ImGui::DragFloat4("##b", &val.m10_);
        anyChanged |= ImGui::DragFloat4("##c", &val.m20_);
        anyChanged |= ImGui::DragFloat4("##d", &val.m30_);
        if (anyChanged)
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_COLOR)
    {
        COMMON_LABEL();
        auto val = value.GetColor();
        if (ImGui::ColorEdit4(labelLessName, &val.r_, ImGuiColorEditFlags_AlphaBar))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, val))->RecordStandardSelectables(doc);
    }
    else if (attr.type_ == VAR_VARIANTVECTOR)
    {
        COMMON_LABEL();
        if (attr.mode_ & AM_NODEIDVECTOR)
        {
            VariantVector v = value.GetVariantVector();

            int ct = v[0].GetUInt();
            if (ImGui::InputInt("Count", &ct, 1, 1))
            {
                v[0] = Variant((unsigned)ct);
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, v))->RecordStandardSelectables(doc);
                who->ApplyAttributes();
            }

            ImGui::Indent();
            for (unsigned i = 1; i < v.Size(); ++i)
            {
                ImGui::PushID(i);
                {
                    unsigned id = v[i].GetUInt();
                    auto found = ((Component*)who)->GetScene()->GetNode(id);
                    String nodeText = found == 0x0 ? "< unspecified > " : found->GetName() + " [" + String(found->GetID()) + "]";
                    ImGui::Text(nodeText.CString());
                    if (ImGui::BeginDragDropTarget())
                    {
                        if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("U_NODEID"))
                        {
                            unsigned nodeID = *((unsigned*)payload->Data);
                            v[i] = Variant(nodeID);
                            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, v))->RecordStandardSelectables(doc);
                            who->ApplyAttributes();
                        }
                        ImGui::EndDragDropTarget();
                    }
                    ImGui::SameLine();
                    if (ImGui::Button(ICON_FA_TRASH))
                    {
                        v[i] = 0;
                        undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, v))->RecordStandardSelectables(doc);
                        who->ApplyAttributes();
                    }
                }
                ImGui::PopID();
            }
            ImGui::Unindent();
        }
        else
        {
            VariantVector v = value.GetVariantVector();
            static int varTypeIdx = 0;
            bool changed = false;
            ImGui::Combo("##type", &varTypeIdx, "Bool\0Int\0Float\0Vector2\0Vector3\0Color\0String\0");
            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_PLUS))
            {
                switch (varTypeIdx) {
                case 0: v.Push((bool)false); break;
                case 1: v.Push((int)0); break;
                case 2: v.Push((float)0.0f); break;
                case 3: v.Push(Vector2(0, 0)); break;
                case 4: v.Push(Vector3(0, 0, 0)); break;
                case 5: v.Push(Color(1, 1, 1, 1)); break;
                case 6: v.Push(String()); break;
                }
                changed = true;
            }

            for (size_t i = 0; i < v.Size(); ++i)
            {
                ImGui::PushID(i);
                auto var = v[i];
                if (ImGuiElement::EditVariant(var))
                    changed = true;
                ImGui::SameLine();
                if (ImGui::Button(ICON_FA_TRASH))
                {
                    v.Erase(i);
                    --i;
                }
                ImGui::PopID();
            }
            if (changed)
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, v))->RecordStandardSelectables(doc);
        }
    }
    else if (attr.type_ == VAR_VARIANTMAP)
    {
        if (ImGui::TreeNode(attr.name_.CString()))
        {
            auto varMap = value.GetVariantMap();
            auto targetMap = varMap;
            ImGui::Indent();
            float w = ImGui::GetContentRegionAvailWidth();
            bool changed = false;
            static int varTypeIndex = 0;
            static String newVarName;
            ImGui::PushItemWidth((w - 50) / 2);
            ImGui::Combo("##type", &varTypeIndex, "Bool\0Int\0Float\0Vector2\0Vector3\0Color\0String\0");
            ImGui::SameLine();
            ImGuiElement::EditString("##new_var_name", newVarName);
            ImGui::PopItemWidth();
            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_PLUS))
            {
                if (!newVarName.Empty())
                {
                    switch (varTypeIndex) {
                    case 0: targetMap[newVarName] = (bool)false; break;
                    case 1: targetMap[newVarName] = (int)0; break;
                    case 2: targetMap[newVarName] = (float)0.0f; break;
                    case 3: targetMap[newVarName] = Vector2(0, 0); break;
                    case 4: targetMap[newVarName] = Vector3(0, 0, 0); break;
                    case 5: targetMap[newVarName] = Color(1, 1, 1, 1); break;
                    case 6: targetMap[newVarName] = String(); break;
                    }
                    changed = true;
                    scene->SetVarName(newVarName, newVarName);
                }
            }

            int i = 0;
            ImGui::BeginChild("##variant_map_values", { w - 8, ImGui::GetFontSize() * 8 }, true, ImGuiWindowFlags_HorizontalScrollbar);
            for (auto kvp : varMap)
            {
                ++i;
                ImGui::PushID(i);
                String name = scene->GetVarName(kvp.first_);
                if (ImGui::Button(ICON_FA_TRASH))
                {
                    targetMap.Erase(kvp.first_);
                    changed = true;
                }
                ImGui::SameLine();
                ImGui::PushItemWidth((w - 50) * 0.3f);
                if (ImGuiElement::EditString("##name", name))
                {
                    changed = true;
                    targetMap.Erase(kvp.first_);
                    targetMap[StringHash(name)] = kvp.second_;
                    scene->SetVarName(name, name);
                }
                ImGui::PopItemWidth();
                ImGui::SameLine();
                auto var = kvp.second_;
                ImGui::PushItemWidth((w - 50) * 0.6f);
                if (ImGuiElement::EditVariant(var))
                {
                    changed = true;
                    targetMap[kvp.first_] = var;
                }
                ImGui::PopItemWidth();
                ImGui::PopID();
            }
            if (changed)
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, targetMap))->RecordStandardSelectables(doc);
            ImGui::EndChild();
            ImGui::Unindent();

            ImGui::TreePop();
        }
    }
    else if (attr.type_ == VAR_BUFFER)
    {
        //TODO
    }
    else if (attr.type_ == VAR_RESOURCEREF)
    {
        COMMON_LABEL();
        ResourceRef ref = value.GetResourceRef();
        static char strData[4096];
        memset(strData, 0, sizeof(char) * 4096);
        strcpy(strData, ref.name_.CString());
        float w = ImGui::GetContentRegionAvailWidth();
        ImGui::PushItemWidth(w - 90);
        ImGui::BeginGroup();
        if (ImGui::InputText(labelLessName, strData, 4096))
        {
            ref.name_ = String(strData);
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, ref))->RecordStandardSelectables(doc);
        };
        ImGui::PopItemWidth();
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_ELLIPSIS_V))
        {
            auto foundRec = FileTypeExtensions.Find(ref.type_);
            if (foundRec != FileTypeExtensions.End())
            {
                String newFile = GetOpenFile("Open File", foundRec->second_);
                if (!newFile.Empty())
                {
                    ref.name_ = newFile;
                    undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, ref))->RecordStandardSelectables(doc);
                }
            }
        }
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_TRASH))
            undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, defVal))->RecordStandardSelectables(doc);
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_EDIT))
        {
            if (!ref.name_.Empty())
            {
                auto cache = who->GetSubsystem<ResourceCache>();
                String absPath = cache->GetResourceFileName(ref.name_);
                if (absPath.Empty())
                    absPath = ref.name_;
                if (!DocumentManager::Get()->OpenPath(absPath))
                    who->GetSubsystem<FileSystem>()->SystemOpen(absPath);
            }
        }
        ImGui::EndGroup();
        if (ImGui::BeginDragDropTarget())
        {
            if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("U_RES"))
            {
                String resPath((const char*)payload->Data, payload->DataSize);
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, ResourceRef(ref.type_, resPath)))->RecordStandardSelectables(doc);
            }
            ImGui::EndDragDropTarget();
        }
    }
    else if (attr.type_ == VAR_RESOURCEREFLIST)
    {
        COMMON_LABEL();
        ResourceRefList ref = value.GetResourceRefList();
        for (size_t i = 0; i < ref.names_.Size(); ++i)
        {
            auto r = ref.names_[i];
            static char strData[4096];
            memset(strData, 0, sizeof(char) * 4096);
            strcpy(strData, r.CString());
            ImGui::PushID(i);
            float w = ImGui::GetContentRegionAvailWidth();
            ImGui::PushItemWidth(w - 90);
            ImGui::BeginGroup();
            if (ImGui::InputText(labelLessName, strData, 4096))
            {
                ref.names_[i] = String(strData);
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, ref))->RecordStandardSelectables(doc);
            }
            ImGui::PopItemWidth();
            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_ELLIPSIS_V))
            {
                auto foundRec = FileTypeExtensions.Find(ref.type_);
                if (foundRec != FileTypeExtensions.End())
                {
                    String newFile = GetOpenFile("Open File", foundRec->second_);
                    if (!newFile.Empty())
                    {
                        ref.names_[i] = newFile;
                        undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, ref))->RecordStandardSelectables(doc);
                    }
                }
            }
            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_TRASH))
            {
                ref.names_[i] = String();
                undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, ref))->RecordStandardSelectables(doc);
            }
            ImGui::SameLine();
            if (ImGui::Button(ICON_FA_EDIT))
            {
                if (!ref.names_[i].Empty())
                {
                    auto cache = who->GetSubsystem<ResourceCache>();
                    String absPath = cache->GetResourceFileName(ref.names_[i]);
                    if (absPath.Empty())
                        absPath = ref.names_[i];
                    if (!DocumentManager::Get()->OpenPath(absPath))
                        who->GetSubsystem<FileSystem>()->SystemOpen(absPath);
                }
            }
            ImGui::EndGroup();
            if (ImGui::BeginDragDropTarget())
            {
                if (const ImGuiPayload* payload = ImGui::AcceptDragDropPayload("U_RES"))
                {
                    ref.names_[i] = String((const char*)payload->Data, payload->DataSize);
                    undoStack->PushNew(std::make_shared<UrhoAttributeUndoRedo>(SharedPtr<Serializable>(who), attrIndex, oldValue, ref))->RecordStandardSelectables(doc);
                }
                ImGui::EndDragDropTarget();
            }
            ImGui::PopID();
        }
    }
}
