#pragma once

#include "Doc_Document3D.h"

#include <Urho3D/ThirdParty/ImGui/imgui.h>

namespace Urho3D
{
    class Node;
    class ParticleEffect;
    class ParticleEmitter;
}

class ParticleDocumentType : public DocumentType
{
public:
    ParticleDocumentType();

    virtual std::shared_ptr<DocumentBase> NewDocument() override;
    virtual std::shared_ptr<DocumentBase> OpenPath(const Urho3D::String& path) override;
    virtual bool OpensXML(const Urho3D::String& xmlRootName) { return xmlRootName == "particleeffect" || xmlRootName == "particleemitter"; }
};

class ParticleDocument : public Document3D, public IPropertyDocument
{
    friend class GUI_ParticleView;
public:
    ParticleDocument(Urho3D::Context*);
    ParticleDocument(Urho3D::Context*, const Urho3D::String& path);
    virtual ~ParticleDocument();

    virtual unsigned GetTabColor() const override { return ImColor(30, 120, 120, 255); }
    virtual bool Save() override;
    virtual void SaveAs() override;
    virtual bool Close() override;

    virtual void PreDraw() override;
    virtual void DrawProperties(ImGuiTextFilter*) override;
    virtual void DrawMasterButtons() override;

protected:
    void CommonConstruct();

    bool showSubstrate_ = true;
    Urho3D::Quaternion camRefRot_;
    Urho3D::SharedPtr<Urho3D::ParticleEffect> effect_;
    Urho3D::SharedPtr<Urho3D::Node> emitterNode_;
    Urho3D::SharedPtr<Urho3D::ParticleEmitter> emitter_;
};