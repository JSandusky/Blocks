#pragma once

#include "Doc_SelectableAction.h"

struct StandardActions
{
    static AppAction* ClearSelection;
    static AppAction* CutScene;
    static AppAction* CopyScene;
    static AppAction* PasteScene;
    static AppAction* ResetToDefault;
    static AppAction* ResetPosition;
    static AppAction* ResetRotation;
    static AppAction* ResetScale;
    static AppAction* ResetTransform;

    static AppAction* ToggleSceneUpdate;
    static AppAction* ViewCloser;
    static AppAction* MatchToCamera;
    
    static AppAction* CloneScene;
    static AppAction* DeleteScene;
    static AppAction* NewLocalChild;
    static AppAction* NewReplicatedChild;
    static AppAction* SaveAsPrefab;
    static AppAction* ReloadPrefab;
    static AppAction* BreakPrefab;
    
    static AppAction* SetSceneToLocal;
    static AppAction* SetSceneToReplicated;
    static AppAction* SetToTemporary;
    static AppAction* SetToPersistent;

    static AppAction* GizmoSelect;
    static AppAction* GizmoMove;
    static AppAction* GizmoRotate;
    static AppAction* GizmoScale;
    static AppAction* GizmoBox;
    static AppAction* GizmoToggleLocal;

    static AppAction* UndoAction;
    static AppAction* RedoAction;

    static void InitializeSceneStandardActions();
};
