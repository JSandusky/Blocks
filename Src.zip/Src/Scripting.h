#pragma once

#include <Urho3D/Container/HashMap.h>
#include <Urho3D/Container/Str.h>
#include <Urho3D/Math/StringHash.h>
#include <Urho3D/AngelScript/ScriptFile.h>

#include <string>
#include <vector>

namespace Urho3D
{
    class Context;
    class Scene;
}

class asIScriptFunction;

struct ScriptPluginMenuRecord
{
    Urho3D::SharedPtr<Urho3D::ScriptFile> file_;
    Urho3D::String title_;
    Urho3D::StringHash eventID_;
    std::vector<ScriptPluginMenuRecord*> children_;

    ~ScriptPluginMenuRecord();

    static ScriptPluginMenuRecord* FindOrCreateScriptPluginMenuGroup(const Urho3D::String& str, std::vector<ScriptPluginMenuRecord*>* holder);
    static void DrawScriptingPluginMenu(ScriptPluginMenuRecord* rec);
    static void DrawScriptingPluginsMenu();
};

struct ScriptPropertyPage
{
    Urho3D::SharedPtr<Urho3D::ScriptFile> scriptFile_;
    Urho3D::StringHash typeHash_;
    Urho3D::String functionCall_;
    asIScriptFunction* asFunction_;
    bool isExtension_ = false;

    ScriptPropertyPage() { }
    ScriptPropertyPage(Urho3D::SharedPtr<Urho3D::ScriptFile> scriptFile, Urho3D::StringHash typeHash, const Urho3D::String& functionCall, bool isExt);
    ~ScriptPropertyPage();

    bool Satisfies(const Urho3D::StringHash& type) const { return typeHash_ == type; }
    void DrawPropertyPage(Urho3D::Object* object, struct ImGuiTextFilter*);

    static Urho3D::HashMap<Urho3D::StringHash, ScriptPropertyPage> propertyPages_;

    static bool CanHandle(Urho3D::Object*);
    static bool HasExtension(Urho3D::Object*);
    static bool CheckAndDrawPropertyPage(Urho3D::Object*, struct ImGuiTextFilter*);
};

void CheckScriptAction(const Urho3D::String& grp, const Urho3D::String& name);

void ClearScriptRegistration();

void RegisterAngelscript(class asIScriptEngine*);

/// Loads a script and executes the 'main' function, then unloads it.
void ExecuteScriptFile(Urho3D::Context*, const std::string& scriptFile);

/// Executes void main(Scene@)
void ExecuteScriptOnScene(Urho3D::Context*, Urho3D::Scene* target, const std::string& scriptFile);