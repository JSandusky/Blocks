#pragma once

#include <Urho3D/Scene/Node.h>
#include <Urho3D/Math/Vector3.h>
#include <Urho3D/Container/Ptr.h>

#include <functional>
#include <memory>
#include <vector>

namespace Urho3D
{
    class DebugRenderer;
    class Scene;
}

class UrhoNodeSelectable;
class Document3D;

Urho3D::SharedPtr<Urho3D::Node> GetNodeByID(Urho3D::SharedPtr<Urho3D::Node> cur, unsigned id);
Urho3D::SharedPtr<Urho3D::Component> GetComponentByID(Urho3D::SharedPtr<Urho3D::Node> cur, unsigned id);

void DrawGrid_3D(Urho3D::DebugRenderer*, const Urho3D::Vector3& origin);
void DrawGrid_2D(Urho3D::DebugRenderer*, const Urho3D::Vector3& origin);

void Focus(const Urho3D::BoundingBox&, const Urho3D::Vector3& offsetDir, Urho3D::Vector3* outPos, Urho3D::Vector3* outDir);
Urho3D::Vector3 GetSelectionCentroid();

Urho3D::String GetResourceNameFromFullName(const Urho3D::String& resourceName);

bool EditorSettingsDialog();
bool ViewportSettingsDialog();
bool LightingSettingsDialog();
bool ManipulatorSettingsDialog();

void FillNodeContextMenu(Urho3D::Node*, Urho3D::Node* camera = 0x0, Urho3D::Vector3* rayHit = 0x0);

/// Loads the given scene with the target file and returns true if it was done.
/// This is used for allowing to override the scene for any given mini-tool.
bool LoadEditorScene(Urho3D::Scene* target, const Urho3D::String& scenePath);
Urho3D::SharedPtr<Urho3D::Node> CreateNodeFromFile(Urho3D::Scene* target, const Urho3D::String& resPath);
void ReloadNodePrefab(Urho3D::SharedPtr<Urho3D::Node>);

void Visit(Urho3D::SharedPtr<Urho3D::Node> node, std::function<void(Urho3D::SharedPtr<Urho3D::Node>)>);
std::vector< Urho3D::SharedPtr<Urho3D::Node> > ToNodeVector(const std::vector<std::shared_ptr<UrhoNodeSelectable>>& sel);
Urho3D::Vector3 Centroid(const std::vector<std::shared_ptr<UrhoNodeSelectable>>& sel);

void ShowComponentCreate();

template<typename T>
Urho3D::String ToCSV(const std::vector<T>& vec, std::function<Urho3D::String(T)> f)
{
    Urho3D::String ret;
    for (size_t i = 0; i < vec.size(); ++i)
    {
        if (i > 0)
            ret += ", ";
        ret += f(vec[i]);
    }
    return ret;
}