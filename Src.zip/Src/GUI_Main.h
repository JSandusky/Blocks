#pragma once

#include <Urho3D/Math/Rect.h>
#include <Urho3D/Scene/Node.h>
#include <Urho3D/ThirdParty/MathGeoLib/MathGeoLib.h>
#include <Urho3D/ThirdParty/ImGui/ImSequencer.h>

#include <string>
#include <vector>

namespace Urho3D
{
    class Node;
    class RefCounted;
    class Texture2D;
}

bool DrawSplitter(const char* id, int split_vertically, float thickness, float* size0, float* size1, float min_size0, float min_size1);

class GUI_DockView abstract
{
public:
    GUI_DockView(const std::string& title) : title_(title) { }
    virtual ~GUI_DockView() { }
    virtual void Draw() = 0;
    virtual void SaveData() { }

    bool visible_ = true;
    std::string title_;
};

class GUI_PaneView abstract
{
public:
    virtual ~GUI_PaneView() { }
    virtual void Draw(const Urho3D::IntRect&) = 0;

    bool IsActive() const { return activeView_ == this; }
    virtual void Activate() { activeView_ = this; }

    virtual void ActivateDraw() { }
    virtual void DeactivateDraw() { }

    /// All panes intended for use in dividable views must be cloneable.
    virtual GUI_PaneView* Clone() = 0;

    Urho3D::IntRect lastDraw_;

private:
    static GUI_PaneView* activeView_;
};

/// Each document gets it's own view manager
class GUI_ViewManager
{
public:
    ~GUI_ViewManager();

    void Draw(const Urho3D::IntRect& viewRect);

    void Activate();
    void Deactivate();

    unsigned GetTotalViewCount() const { return topViews_.size() + bottomViews_.size(); }

    GUI_PaneView* GetFirstView();

    GUI_PaneView* leftView_ = nullptr;
    GUI_PaneView* rightView_ = nullptr;
    std::vector<GUI_PaneView*> topViews_;
    std::vector<GUI_PaneView*> bottomViews_;
    bool verticalOrientation_ = false;

    GUI_PaneView* GetActiveView() const;
};

class GUI_MainHub
{
public:
    ~GUI_MainHub();

    void Draw(const Urho3D::IntRect& guiRect);
    void InitializeDockActions();

    std::vector<GUI_DockView*> docks_;

    void SaveXML();
    void LoadXML();

private:
    /// Returns height of the tab widget
    float DrawDocumentTabs();
    /// Returns width of the master bar
    float DrawMasterBar();
};

class GUI_ProfilerView : public GUI_DockView
{
public:
    GUI_ProfilerView();
    virtual void Draw() override;
};

class GUI_ResourceView : public GUI_DockView
{
public:
    GUI_ResourceView();
    virtual void Draw() override;
};

class GUI_PropertiesView : public GUI_DockView
{
public:
    GUI_PropertiesView();
    ~GUI_PropertiesView();
    virtual void Draw() override;

    static void ShowCreateComponentButton(Urho3D::SharedPtr<Urho3D::Node> node);
    static Urho3D::Component* DoCreateComponentMenu(Urho3D::SharedPtr<Urho3D::Node> node);
};

class GUI_SceneTreeView : public GUI_DockView
{
public:
    GUI_SceneTreeView();
    virtual void Draw() override;

private:
    float treeW = -1.0f;
    std::pair<Urho3D::RefCounted*, int> ShowTree(Urho3D::Node* root, std::vector<Urho3D::RefCounted*>& currentSelection, bool disabled, bool showTemporaries, struct ImGuiTextFilter*);
    unsigned CountNonTempChildren(Urho3D::Node* node, bool tempsIn) const;
};

class GUI_ShadersView : public GUI_DockView
{
public:
    GUI_ShadersView();
    virtual void Draw() override;
};

struct ImGuiTextFilter;
class GUI_AssetBrowserView : public GUI_DockView
{
public:
    GUI_AssetBrowserView();
    ~GUI_AssetBrowserView();

    virtual void Draw() override;
    virtual void SaveData() override;
private:
    struct DirectoryTreeData
    {
        Urho3D::String displayName_;
        Urho3D::String fullPath_;

        std::vector<DirectoryTreeData*> children_;

        DirectoryTreeData(const Urho3D::String& path);
        ~DirectoryTreeData();
    };

    void ShowDirectory(const Urho3D::String& path, const Urho3D::StringVector& contents, ImGuiTextFilter*, bool asDetail);
    void ShowTree(const DirectoryTreeData* node);

    Urho3D::SharedPtr<Urho3D::Texture2D> GetImage(const Urho3D::String& imagePath);

    Urho3D::SharedPtr<Urho3D::Texture2D> GetOrCreateThumbnail(const Urho3D::String& path);
    Urho3D::String directory_;
    Urho3D::String lastDirectory_;
    Urho3D::String rootDirectory_;
    Urho3D::HashMap< Urho3D::String, std::function<void(const Urho3D::String&)> > fileHandlers_;

    std::vector<Urho3D::String> favorites_;
    std::vector<Urho3D::String> recentDirectories_;

    // Caching thumbnails in a table, ResourceCache lookups are expensive to do every frame (SanitateResourceName)
    Urho3D::HashMap< Urho3D::StringHash, Urho3D::SharedPtr<Urho3D::Texture2D> > thumbCache_;
    // Cache active directory contents to avoid repeatedly scanning folder contents
    Urho3D::StringVector currentDirCache_;
    // Cached filesystem hierarchy from the target root.
    DirectoryTreeData* directoryData_;
    // Whether to show a details list or not
    bool asDetails_ = false;
};

class GUI_TimelineView : public GUI_DockView
{
public:
    GUI_TimelineView();
    virtual void Draw() override;

    ImSequencer::SequenceInterface* interface_ = 0x0;
};

class GUI_ShaderGraph : public GUI_DockView
{
public:
    GUI_ShaderGraph();
    virtual void Draw() override;
};

class GUI_ScriptGraph : public GUI_DockView
{
public:
    GUI_ScriptGraph();
    virtual void Draw() override;
};

class GUI_LogView : public GUI_DockView
{
public:
    GUI_LogView();
    virtual void Draw() override;

    struct Msg
    {
        int level_;
        std::string text_;
    };
    std::vector<Msg> messages_;
};

class GUI_HistoryView : public GUI_DockView
{
public:
    GUI_HistoryView();

    virtual void Draw() override;
};

class GUI_DataGrid : public GUI_DockView
{
public:
    GUI_DataGrid();
    virtual void Draw() override;
};

void DrawInputBindings();