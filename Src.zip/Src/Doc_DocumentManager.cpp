#include "Doc_DocumentManager.h"

#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Graphics/Graphics.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Core/Context.h>
#include <Urho3D/Input/Input.h>

#include <Urho3D/Graphics/BillboardSet.h>
#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/Graphics/Zone.h>
#include <Urho3D/Graphics/Light.h>
#include <Urho3D/Graphics/Octree.h>
#include <Urho3D/Physics/RigidBody.h>
#include <Urho3D/Scene/SplinePath.h>
#include <Urho3D/Graphics/StaticModel.h>
#include <Urho3D/Graphics/Material.h>
#include <Urho3D/Graphics/Model.h>
#include <Urho3D/Resource/ResourceCache.h>

#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include "Block.h"
#include "DataObject.h"
#include "GUI_Main.h"
#include "GUI_Pane3D.h"
#include "Urho_Undo.h"
#include "Urho_Util.h"
#include "UX.h"

#include "Doc_SelectableAction.h"
#include "DocType_Scene.h"
#include "DocType_Material.h"
#include "DocType_ModelViewer.h"
#include "DocType_Particle.h"
#include "DocType_UI.h"

#ifdef WIN32
#include <Windows.h>
#include <Commdlg.h>
#include <tchar.h>
#endif

#include <Urho3D/ThirdParty/ImGui/ImGuizmo.h>

#include <Urho3D/DebugNew.h>

std::unique_ptr<DocumentManager> DocumentManager::inst_(new DocumentManager());

const int BaseGizmo::NONE = -1;
const int BaseGizmo::TRANSLATE = 0;
const int BaseGizmo::ROTATE = 1;
const int BaseGizmo::SCALE = 2;
const int BaseGizmo::BOX = 3;
int  BaseGizmo::mode_ = 0;
bool BaseGizmo::isLocal_ = true;

VectorBuffer MakeFileMask(const Urho3D::String& str)
{
    VectorBuffer vb;
    unsigned char zeroChar = 0;
    
    auto parts = str.Split('|');
    for (size_t i = 0; i < parts.Size(); i += 2)
    {
        vb.Write(parts[i].CString(), parts[i].Length());
        vb.Write(&zeroChar, 1);
        vb.Write(parts[i + 1].CString(), parts[i + 1].Length());
        vb.Write(&zeroChar, 1);
    }
    vb.Write(&zeroChar, 1);
    return vb;
}

std::string OSOpenFile(const std::string& title, const char* defExt, const char* filter)
{
    OPENFILENAMEA saveFileStruct;
    memset(&saveFileStruct, 0, sizeof(OPENFILENAMEA));
    static char sz[MAX_PATH];
    memset(sz, 0, MAX_PATH);

    auto procFilter = MakeFileMask(filter);

    saveFileStruct.lStructSize = sizeof(saveFileStruct);
    saveFileStruct.lpstrDefExt = defExt;
    saveFileStruct.lpstrFile = sz;
    saveFileStruct.lpstrFile[0] = '\0';
    saveFileStruct.nMaxFile = MAX_PATH;
    saveFileStruct.lpstrFilter = filter;
    saveFileStruct.lpstrTitle = (char*)procFilter.GetData();

    auto result = GetOpenFileName(&saveFileStruct);
    if (saveFileStruct.lpstrFile[0] != '\0')
        return std::string(saveFileStruct.lpstrFile);
    return std::string();
}

std::string GetSaveFile(const std::string& title, const char* defExt, const char* filter)
{
    OPENFILENAMEA saveFileStruct;
    memset(&saveFileStruct, 0, sizeof(OPENFILENAMEA));
    static char sz[MAX_PATH];
    memset(sz, 0, MAX_PATH);

    auto procFilter = MakeFileMask(filter);

    saveFileStruct.lStructSize = sizeof(saveFileStruct);
    saveFileStruct.lpstrDefExt = defExt;
    saveFileStruct.lpstrFile = sz;
    saveFileStruct.lpstrFile[0] = '\0';
    saveFileStruct.nMaxFile = MAX_PATH;
    saveFileStruct.lpstrFilter = (char*)procFilter.GetData();
    saveFileStruct.lpstrTitle = title.c_str();

    auto result = GetSaveFileName(&saveFileStruct);
    if (saveFileStruct.lpstrFile[0] != '\0')
        return std::string(saveFileStruct.lpstrFile);
    return std::string();
}

std::pair<std::string, std::string> GetSaveFile_PairName(const std::string& title, const char* defExt, const char* filter)
{
    auto filePath = GetSaveFile(title, defExt, filter);
    if (!filePath.empty())
    {
        size_t lastSlash = filePath.find_last_of('\\');
        size_t dot = filePath.find_last_of('.');

        if (dot == std::string::npos) // no matter what flags are specified it is ALWAYS possible to get a name without an extension if UAC is on max
        {
            filePath += ".xml";
            return std::make_pair(filePath, filePath.substr(lastSlash + 1));
        }
        else
            return std::make_pair(filePath, filePath.substr(lastSlash + 1, dot - lastSlash - 1));
    }
    return std::pair<std::string, std::string>();
}

DocumentManager* DocumentManager::Get()
{
    return inst_.get();
}

using namespace Urho3D;

DocumentBase::DocumentBase(Urho3D::Context* ctx) :
    Object(ctx), selectionContext_(ctx), undoRedo_(this)
{
    guiViews_ = new GUI_ViewManager();
}

DocumentBase::~DocumentBase()
{
    if (guiViews_)
        delete guiViews_;
    guiViews_ = nullptr;
    selectionContext_.clear();
    undoRedo_.Clear();
}

bool DocumentBase::IsActive() const
{
    return DocumentManager::Get()->GetActiveDocument().get() == this;
}

bool DocumentBase::Close()
{
    // dump as much data as possible so memory gets freed
    selectionContext_.clear();
    undoRedo_.Clear();
    delete guiViews_;
    guiViews_ = nullptr;
    return true;
}

void DocumentBase::ClearDirty()
{
    dirty_ = false;
    auto& eventData = GetEventDataMap();
    eventData["DocumentPath"] = filePath_.c_str();
    eventData["DocumentName"] = name_.c_str();
    eventData["Document"] = this;
    SendEvent("EDITOR_DOCUMENT_CHANGED_INTERNAL", eventData);
    SendEvent("EDITOR_DOCUMENT_CHANGED", eventData);
}

std::string DocumentBase::GetSavePath(const std::string& title, const std::string& filter, bool saveAs)
{
    if (!filePath_.empty() && !saveAs)
        return filePath_;

    static char sz[MAX_PATH];
    memset(sz, 0, MAX_PATH);

    OPENFILENAMEA sfn;
    memset(&sfn, 0, sizeof(OPENFILENAMEA));
    sfn.lStructSize = sizeof(sfn);
    sfn.lpstrDefExt = "*.xml";
    sfn.lpstrFile = sz;
    sfn.lpstrFile[0] = '\0';
    sfn.nMaxFile = MAX_PATH;
    sfn.lpstrFilter = filter.c_str();
    sfn.lpstrTitle = title.c_str();

    auto result = GetSaveFileNameA(&sfn);
    if (sfn.lpstrFile != 0x0)
        return std::string(sfn.lpstrFile);
    return std::string();
}

auto CommonDocPath = [](const Urho3D::String& path) -> std::shared_ptr<DocumentBase>
{
    auto ctx = BlockExe::GetInst()->GetContext();
    if (path.EndsWith(".xml"))
    {
        auto cache = BlockExe::GetInst()->GetSubsystem<ResourceCache>();
        auto xml = cache->GetResource<XMLFile>(path);
        if (xml->GetRoot().GetName().Compare("scene", false) == 0 || xml->GetRoot().GetName().Compare("node", false) == 0)
            return std::make_shared<SceneDocument>(ctx, path);
        else if (xml->GetRoot().GetName().Compare("material", false) == 0)
            return std::make_shared<MaterialDocument>(ctx, path);
        else if (xml->GetRoot().GetName().Compare("particleemitter", false) == 0 || xml->GetRoot().GetName().Compare("particleeffect", false) == 0)
            return std::make_shared<ParticleDocument>(ctx, path);
        else if (xml->GetRoot().GetName().Compare("element", false) == 0)
            return std::make_shared<UIDocument>(ctx, path);
    }
    else if (path.EndsWith(".mdl"))
    {
        return std::make_shared<ModelViewerDocument>(ctx, path);
    }
    else if (path.EndsWith("*.ani"))
    {

    }
    return std::shared_ptr<DocumentBase>();
};

DocumentType::DocumentType(const Urho3D::String& name, const Urho3D::String& openMask) :
    name_(name), openMask_(openMask)
{

}

std::shared_ptr<DocumentBase> DocumentType::DoXMLCheck(const Urho3D::String& path)
{
    if (path.EndsWith(".xml", false))
    {
        auto cache = BlockExe::GetInst()->GetSubsystem<ResourceCache>();
        auto xml = cache->GetResource<XMLFile>(path);
        if (xml)
        {
            if (auto xmlType = DocumentManager::Get()->GetTypeForXML(xml->GetRoot().GetName().ToLower()))
                return xmlType->OpenPath(path);
        }
    }
    return nullptr;
}

Urho3D::InputBinding* DocumentType::AddAction(Urho3D::SharedPtr<Urho3D::InputBinding> binding)
{
    BlockExe::GetInst()->GetSubsystem<Input>()->AddInputBinding(binding);
    actions_.push_back(binding);
    return binding.Get();
}

void DocumentType::CollectActions(ActionList& list)
{
    list.insert(list.end(), actions_.begin(), actions_.end());
}

DocumentManager::DocumentManager()
{
#define CTX_GET BlockExe::GetInst()->GetContext()
    //types_ = {
    //    {
    //        "Supported Files",
    //        "Supported Files (*.xml, *.mdl)|*.xml;*.mdl",
    //        nullptr,
    //        [](const Urho3D::String& path) -> std::shared_ptr<DocumentBase> { 
    //            if (auto ret = CommonDocPath(path))
    //                return ret;
    //            return nullptr; 
    //        },
    //        [](Input* input) {
    //            input->AddInputBinding(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", "Move Up", "Moves the current object upwards")));
    //            input->AddInputBinding(SharedPtr<InputBinding>(new DocumentAction<SceneDocument>("Scene Document", "Move Down", "Moves the current object downwards")));
    //        }
    //    },
    //    {
    //        "Scene",
    //        "Scene (*.xml, *.bin)|*.xml;*.bin",
    //        []() -> std::shared_ptr<DocumentBase> { 
    //            return std::make_shared<SceneDocument>(CTX_GET);
    //        },
    //        [](const Urho3D::String& path) -> std::shared_ptr<DocumentBase> {                
    //            if (auto ret = CommonDocPath(path))
    //                return ret;
    //            return std::make_shared<SceneDocument>(CTX_GET, path);
    //        },
    //        [](Input* input) {
    //
    //        }
    //    },
    //    {
    //        "Particle Effect",
    //        "Particle Effect (*.xml)|*.xml",
    //        []() -> std::shared_ptr<DocumentBase> {
    //            return std::make_shared<ParticleDocument>(CTX_GET);
    //        },
    //        [](const Urho3D::String& path) -> std::shared_ptr<DocumentBase> {
    //            if (auto ret = CommonDocPath(path))
    //                return ret;
    //            return std::make_shared<ParticleDocument>(CTX_GET, path);
    //        },
    //        [](Input* input) {
    //
    //        }
    //    },
    //    {
    //        "Material",
    //        "Material (*.xml)|*.xml",
    //        []() -> std::shared_ptr<DocumentBase> { 
    //            return std::make_shared<MaterialDocument>(CTX_GET);
    //        },
    //        [](const Urho3D::String& path) -> std::shared_ptr<DocumentBase> { 
    //            if (auto ret = CommonDocPath(path))
    //                return ret;
    //            return std::make_shared<MaterialDocument>(CTX_GET, path);
    //        },
    //        [](Input* input) {
    //
    //        }
    //    },
    //    {
    //        "Model",
    //        "Model (*.mdl)|*.mdl",
    //        nullptr,
    //        [](const Urho3D::String& path) -> std::shared_ptr<DocumentBase> {
    //            if (auto ret = CommonDocPath(path))
    //                return ret;
    //            return std::make_shared<ModelViewerDocument>(CTX_GET, path);
    //        },
    //        [](Input* input) {
    //
    //        }
    //    },
    //    {
    //        "User Interface (EXPERIMENTAL)",
    //        "User Interface (*.xml)|*.xml",
    //        []() -> std::shared_ptr<DocumentBase> {
    //            return std::make_shared<UIDocument>(CTX_GET);
    //        },
    //        [](const Urho3D::String& path) -> std::shared_ptr<DocumentBase> {
    //            return nullptr;
    //        },
    //        [](Input* input) -> void {
    //
    //        }
    //    }
    //};
}

DocumentManager::~DocumentManager()
{
    documents_.clear();
    activeDocument_.reset();
}

std::shared_ptr<DocumentBase> DocumentManager::AddDocument(std::shared_ptr<DocumentBase> data)
{
    data->ClearDirty();
    documents_.push_back(data);
    SetActiveDocument(data);

    auto& eventData = BlockExe::GetInst()->GetEventDataMap();
    eventData["DocumentPath"] = data->GetPath().c_str();
    eventData["DocumentName"] = data->GetName().c_str();
    eventData["Document"] = data.get();
    BlockExe::GetInst()->SendEvent("EDITOR_DOCUMENT_OPENED_INTERNAL", eventData);
    BlockExe::GetInst()->SendEvent("EDITOR_DOCUMENT_OPENED", eventData);

    return data;
}

void DocumentManager::SetActiveDocument(std::shared_ptr<DocumentBase> doc)
{
    if (activeDocument_ && activeDocument_ != doc)
    {
        activeDocument_->Deactivated();
        activeDocument_->GetViewManager()->Deactivate();
    }
    if (doc)
    {
        activeDocument_ = doc;
        doc->Activated();
        doc->GetViewManager()->Activate();
        BlockExe::GetInst()->SendEvent("EDITOR_DOCUMENT_ACTIVATED");
    }
    activeDocument_ = doc;
}

std::shared_ptr<DocumentBase> DocumentManager::GetActiveDocument()
{
    return activeDocument_;
}

bool DocumentManager::CloseDocument(std::shared_ptr<DocumentBase> doc)
{
#define SEND_CLOSE_EVENT auto& eventData = BlockExe::GetInst()->GetEventDataMap(); \
    eventData["Document"] = doc.get(); \
    eventData["DocumentName"] = doc->GetName().c_str(); \
    eventData["DocumentPath"] = doc->GetPath().c_str(); \
    BlockExe::GetInst()->SendEvent("EDITOR_DOCUMENT_CLOSED_INTERNAL", eventData); \
    BlockExe::GetInst()->SendEvent("EDITOR_DOCUMENT_CLOSED", eventData);

    if (doc->IsDirty())
    {
        ModalWindows::Get()->Push(
            ErrorMessage("Document has unsaved changes.\nDo you want to save?", "Close?", {
                {
                    "Save", [this, doc]() {
                        doc->Save();
                        SEND_CLOSE_EVENT
                        documents_.erase(std::find(documents_.begin(), documents_.end(), doc));
                        if (doc == activeDocument_ && !documents_.empty())
                            SetActiveDocument(doc);
                        else if (documents_.empty())
                            SetActiveDocument(nullptr);
                        //??doc->Close();
                    }
                },
                {
                    "Ignore", [this, doc]() {
                        SEND_CLOSE_EVENT
                        documents_.erase(std::find(documents_.begin(), documents_.end(), doc));
                        if (doc == activeDocument_ && !documents_.empty())
                            SetActiveDocument(doc);
                        else if (documents_.empty())
                            SetActiveDocument(nullptr);
                        //??doc->Close();
                    }
                },
                {
                    "Cancel", [this, doc]() {
                        // do nothing
                    }
                }
            })
        );
        return false;
    }
    else
    {
        SEND_CLOSE_EVENT
        documents_.erase(std::find(documents_.begin(), documents_.end(), doc));
        if (doc == activeDocument_ && !documents_.empty())
            SetActiveDocument(doc);
        else if (documents_.empty())
            SetActiveDocument(nullptr);
        //??doc->Close();
        return true;
    }
}

bool DocumentManager::OpenPath(const Urho3D::String& path)
{
    for (auto& docType : types_)
    {
        if (auto newDoc = CommonDocPath(path))
        {
            AddDocument(newDoc);
            return true;
        }
    }
    return false;
}

void DocumentManager::DrawNewDocumentMenu()
{
    for (auto& docType : types_)
    {
        if (docType->CanCreateNew())
        {
            if (ImGui::MenuItem(docType->name_.CString()))
            {
                if (auto newDoc = docType->NewDocument())
                    AddDocument(newDoc);
            }
        }
    }
}

std::shared_ptr<DocumentType> DocumentManager::GetTypeForXML(const Urho3D::String& xmlName)
{
    for (auto dt : types_)
        if (dt->OpensXML(xmlName))
            return dt;
    return nullptr;
}


void DocumentManager::DoOpenDocument()
{
    OPENFILENAMEA saveFileStruct;
    memset(&saveFileStruct, 0, sizeof(OPENFILENAMEA));
    static char sz[MAX_PATH];
    memset(sz, 0, MAX_PATH);

    VectorBuffer vb;
    unsigned char zeroChar = 0;
    for (auto t : types_)
    {
        auto parts = t->openMask_.Split('|');
        vb.Write(parts[0].CString(), parts[0].Length());
        vb.Write(&zeroChar, 1);
        vb.Write(parts[1].CString(), parts[1].Length());
        vb.Write(&zeroChar, 1);
    }
    vb.Write(&zeroChar, 1);

    saveFileStruct.lStructSize = sizeof(saveFileStruct);
    saveFileStruct.lpstrDefExt = "*.xml";
    saveFileStruct.lpstrFile = sz;
    saveFileStruct.lpstrFile[0] = '\0';
    saveFileStruct.nMaxFile = MAX_PATH;
    saveFileStruct.lpstrFilter = (char*)vb.GetModifiableData();
    saveFileStruct.lpstrTitle = "Open File";

    auto result = GetOpenFileNameA(&saveFileStruct);
    if (saveFileStruct.lpstrFile[0] != '\0')
    {
        Urho3D::String str(saveFileStruct.lpstrFile);
        if (str.EndsWith(".xml", false))
        {
            auto cache = BlockExe::GetInst()->GetSubsystem<ResourceCache>();
            auto xml = cache->GetResource<XMLFile>(str);
            if (xml)
            {
                auto lowerName = xml->GetRoot().GetName().ToLower();
                for (auto dt : types_)
                {
                    if (dt->OpensXML(lowerName))
                    {
                        if (auto newDoc = dt->OpenPath(str))
                        {
                            AddDocument(newDoc);
                            return;
                        }
                    }
                }
            }
        }
        if (auto newDoc = types_[saveFileStruct.nFilterIndex - 1]->OpenPath(str))
            AddDocument(newDoc);
    }
}

void BaseGizmo::DrawGrid(int moveType, Urho3D::Vector3 trans, Urho3D::DebugRenderer* render)
{
    extern std::unique_ptr<DataObject> gizmoSettings_;
    if (!gizmoSettings_->GetField("Show Gizmo Grid").GetBool())
        return;

    if (isLocal_)
        return;

    const int gridLen = (moveType >= 4 && moveType <= 7) ? 30 : 1;
    float alpha = gridLen > 1 ? 0.5f : 1.0f;
    Color red = Urho3D::Color(1, 0, 0);
    Color green = Urho3D::Color(0, 1, 0);
    Color blue = Urho3D::Color(0, 0, 1);
    Color gridRed = Urho3D::Color(1, 0, 0, alpha);
    Color gridGreen = Urho3D::Color(0, 1, 0, alpha);
    Color gridBlue = Urho3D::Color(0, 0, 1, alpha);

    if (moveType == 4 || moveType == 5 || moveType == 6 || moveType == 7)
        red = green = blue = gridRed = gridGreen = gridBlue = Urho3D::Color(1, 1, 1, 0.5f);

    if (moveType == 1)
    {
        render->AddLine(trans - Vector3(1000, 0, 0), trans + Vector3(1000, 0, 0), red, true);
        int iCoord = trans.x_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(i + iCoord, trans.y_ + 0, trans.z_ - gridLen), Vector3(i + iCoord, trans.y_ + 0, trans.z_ + gridLen), gridRed, true);
    }
    if (moveType == 2)
    {
        render->AddLine(trans - Vector3(0, 1000, 0), trans + Vector3(0, 1000, 0), green, true);
        int iCoord = trans.y_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(trans.x_ - gridLen, i + iCoord, trans.z_ + 0), Vector3(trans.x_ + gridLen, i + iCoord, trans.z_ + 0), gridGreen, true);
    }
    if (moveType == 3)
    {
        render->AddLine(trans - Vector3(0, 0, 1000), trans + Vector3(0, 0, 1000), blue, true);
        int iCoord = trans.z_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(trans.x_ - gridLen, trans.y_ + 0, i + iCoord), Vector3(trans.x_ + gridLen, trans.y_ + 0, i + iCoord), gridBlue, true);
    }

    if (moveType == 4)
    {
        render->AddLine(trans - Vector3(1000, 0, 0), trans + Vector3(1000, 0, 0), red, true);
        render->AddLine(trans - Vector3(0, 1000, 0), trans + Vector3(0, 1000, 0), green, true);
        int iCoord = trans.x_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(i + iCoord, trans.y_ - gridLen, trans.z_), Vector3(i + iCoord, trans.y_ + gridLen, trans.z_), gridRed, true);
        iCoord = trans.y_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(trans.x_ - gridLen, i + iCoord, trans.z_), Vector3(trans.x_ + gridLen, i + iCoord, trans.z_), gridGreen, true);
    }

    if (moveType == 5)
    {
        render->AddLine(trans - Vector3(0, 1000, 0), trans + Vector3(0, 1000, 0), green, true);
        render->AddLine(trans - Vector3(0, 0, 1000), trans + Vector3(0, 0, 1000), blue, true);
        int iCoord = trans.y_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(trans.x_, i + iCoord, trans.z_ - gridLen), Vector3(trans.x_, i + iCoord, trans.z_ + gridLen), gridBlue, true);
        iCoord = trans.z_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(trans.x_, trans.y_ - gridLen, i + iCoord), Vector3(trans.x_, trans.y_ + gridLen, i + iCoord), gridGreen, true);
    }

    if (moveType == 6)
    {
        render->AddLine(trans - Vector3(1000, 0, 0), trans + Vector3(1000, 0, 0), red, true);
        render->AddLine(trans - Vector3(0, 0, 1000), trans + Vector3(0, 0, 1000), blue, true);
        int iCoord = trans.x_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(i + iCoord, trans.y_ + 0, trans.z_ - gridLen), Vector3(i + iCoord, trans.y_ + 0, trans.z_ + gridLen), gridRed, true);
        iCoord = trans.z_;
        for (int i = -30; i < 30; ++i)
            render->AddLine(Vector3(trans.x_ - gridLen, trans.y_ + 0, i + iCoord), Vector3(trans.x_ + gridLen, trans.y_ + 0, i + iCoord), gridBlue, true);
    }

    if (moveType == 7)
    {
        render->AddLine(trans - Vector3(1000, 0, 0), trans + Vector3(1000, 0, 0), red, true);
        render->AddLine(trans - Vector3(0, 1000, 0), trans + Vector3(0, 1000, 0), green, true);
        render->AddLine(trans - Vector3(0, 0, 1000), trans + Vector3(0, 0, 1000), blue, true);
    }

    if (moveType == 8)
    {
        render->AddLine(trans - Vector3(1000, 0, 0), trans + Vector3(1000, 0, 0), red, true);
    }
    if (moveType == 9)
    {
        render->AddLine(trans - Vector3(0, 1000, 0), trans + Vector3(0, 1000, 0), green, true);
    }
    if (moveType == 10)
    {
        render->AddLine(trans - Vector3(0, 0, 1000), trans + Vector3(0, 0, 1000), blue, true);
    }
}

bool UrhoGizmo::Draw(Urho3D::Camera* camera, const Urho3D::IntRect& rect, Urho3D::DebugRenderer* render)
{
    if (mode_ == NONE)
        return false;

    Matrix4 mat, viewMat, projMat;

    mat = Matrix3x4(transformNode_->GetWorldPosition(), transformNode_->GetWorldRotation().Normalized(), transformNode_->GetScale()).ToMatrix4().Transpose();
    viewMat = camera->GetView().ToMatrix4().Transpose();
    projMat = camera->GetProjection().Transpose();

    ImGuiIO& io = ImGui::GetIO();
    ImGuizmo::SetDrawlist();
    ImGuizmo::Enable(true);
    ImGuizmo::SetRect(rect.left_, rect.top_, rect.Width(), rect.Height());

    Matrix4 deltaMat;
    auto mode = mode_ == TRANSLATE ? ImGuizmo::TRANSLATE : (mode_ == ROTATE) ? ImGuizmo::ROTATE : ImGuizmo::SCALE;
    Urho3D::Matrix4 bnds;
    Vector3 bbSize;
    if (mode_ == BOX)
    {
        mode = ImGuizmo::BOX_ONLY;
        PODVector<Drawable*> comps;
        transformNode_->GetDerivedComponents<Drawable>(comps, true);
        Urho3D::BoundingBox bb;
        for (auto c : comps)
            bb.Merge(c->GetBoundingBox());
        auto sz = bb.HalfSize();
        bnds = Urho3D::Matrix4(
            -sz.x_, -sz.y_, -sz.z_,
            sz.x_, sz.y_, sz.z_, 
            0, 0,
            0, 0, 0, 0, 
            0, 0, 0, 0
            );
        bbSize = bb.Size();
    }

    extern std::unique_ptr<DataObject> gizmoSettings_;
    Vector3 snap(0, 0, 0);
    Vector3 boundsSnap(0, 0, 0);
    extern bool IsShiftDown();
    if ((mode_ == TRANSLATE || mode_ == BOX) && (gizmoSettings_->GetField("Snap Position").GetBool() || IsShiftDown()))
    {
        float f = gizmoSettings_->GetField("Snap position spacing").GetFloat();
        snap = Vector3(f, f, f);
        boundsSnap = Vector3(f/bbSize.x_, f/bbSize.y_, f/bbSize.z_);
    }
    else if (mode_ == ROTATE && (gizmoSettings_->GetField("Snap Rotation").GetBool() || IsShiftDown()))
    {
        float f = gizmoSettings_->GetField("Snap rotation degrees").GetFloat();
        snap = Vector3(f, f, f);
    }
    else
        boundsSnap = Vector3(0, 0, 0);

    extern std::unique_ptr<DataObject> gizmoSettings_;
    ImGui::PushClipRect(ImVec2(rect.left_, rect.top_), ImVec2(rect.right_, rect.bottom_), true);
    ImGuizmo::Manipulate(viewMat.Data(), projMat.Data(), mode, isLocal_ ? ImGuizmo::LOCAL : ImGuizmo::WORLD, (float*)mat.Data(), (float*)deltaMat.Data(), &snap.x_, mode_ == BOX ? (float*)bnds.Data() : 0x0, 0x0);
    ImGui::PopClipRect();
    if (ImGuizmo::IsUsing())
    {
        Matrix4 editMat = mat.Transpose();
        Matrix4 deltaMat = deltaMat.Transpose();

        // Fucking ImGuizmo. Guil libraries need to go away, they're complete garbage.
        extern bool IsCtrlDown();
        if (IsCtrlDown() && !ImGuizmo::GetMarkerBit(1))//!didClone_)
        {
            ImGuizmo::SetMarkerBit(1, true);
            //didClone_ = true;
            auto oldSel = std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(transformNode_));
            auto oldTrans = transformNode_;
            transformNode_ = transformNode_->Clone();
            auto newTrans = transformNode_;
            auto newSel = std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(transformNode_));

            std::vector<std::shared_ptr<UndoRedo> > actions = {
                std::make_shared<UrhoCreateDeleteNodeUndoRedo>(SharedPtr<Node>(transformNode_->GetParent()), transformNode_, true),
                //??std::make_shared<FunctionalUndoRedo>("", [=]() { this->transformNode_ = newTrans; }, [=]() { this->transformNode_ = oldTrans; })
            };


            DocumentManager::Get()->GetActiveDocument()->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(transformNode_));
            DocumentManager::Get()->GetActiveDocument()->GetUndoStack().PushNew(
                std::make_shared<MultiUndoRedo>((ICON_FA_CLONE " ^3Clone " + newTrans->GetName() + " : " + String(newTrans->GetID())), actions))->AttachSelectables({ oldSel }, { newSel });
            return true;
        }
        else if (!IsCtrlDown())
            ImGuizmo::SetMarkerBit(1, false);//didClone_ = false;

        auto oldP = transformNode_->GetWorldPosition();
        auto oldQ = transformNode_->GetWorldRotation();
        auto oldS = transformNode_->GetWorldScale();

        if (mode_ == ImGuizmo::TRANSLATE || mode_ == BOX)
            transformNode_->SetWorldPosition(editMat.Translation());
        if (mode_ == ImGuizmo::ROTATE)
            transformNode_->SetWorldRotation(editMat.Rotation().Normalized());
        if (mode_ == ImGuizmo::SCALE || mode_ == BOX)
            transformNode_->SetWorldScale(editMat.Scale());

        auto newP = transformNode_->GetWorldPosition();
        auto newQ = transformNode_->GetWorldRotation();
        auto newS = transformNode_->GetWorldScale();

        DocumentManager::Get()->GetActiveDocument()->GetUndoStack().PushNew(
            std::make_shared<UrhoTransformUndoRedo>(transformNode_,
                oldP, oldQ, oldS,
                newP, newQ.Normalized(), newS)
        );

        Vector3 trans, scl;
        Quaternion rot;
        editMat.Decompose(trans, rot, scl);
        int moveType = ImGuizmo::GetAxis();
        DrawGrid(moveType, trans, render);

        if (isLocal_)
        {
            render->AddLine(transformNode_->GetWorldPosition(), transformNode_->GetWorldPosition() + transformNode_->GetWorldRight() * 1000, Color::RED);
            render->AddLine(transformNode_->GetWorldPosition(), transformNode_->GetWorldPosition() + transformNode_->GetWorldUp() * 1000, Color::GREEN);
            render->AddLine(transformNode_->GetWorldPosition(), transformNode_->GetWorldPosition() + transformNode_->GetWorldDirection() * 1000, Color::BLUE);
        }

        return true;
    }
    else
        ImGuizmo::SetMarkerBit(1, false);//didClone_ = false;
    return false;
}

UrhoTransformUndoRedo::UrhoTransformUndoRedo(Urho3D::SharedPtr<Urho3D::Node> target, Urho3D::Vector3 oldTrans,
    Urho3D::Quaternion oldQuat,
    Urho3D::Vector3 oldScale,
    Urho3D::Vector3 newTrans,
    Urho3D::Quaternion newQuat,
    Urho3D::Vector3 newScale) :

    target_(target),
    oldTrans_(oldTrans),
    oldQuat_(oldQuat),
    oldScale_(oldScale),
    newTrans_(newTrans),
    newQuat_(newQuat),
    newScale_(newScale)
{
    Urho3D::String txt;
    txt = ICON_FA_ARROWS_ALT " ^3Transform " + (target_->GetName().Empty() ? target_->GetName() : "node") + " : [" + Urho3D::String(target->GetID()) + "] to ";
    txt += newTrans_.ToString();
    text_ = txt.CString();
}

void UrhoTransformUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    Urho3D::Vector3 pos, scl;
    Urho3D::Quaternion rot;

    if (oldTrans_ != newTrans_)
        target_->SetWorldPosition(isUndo ? oldTrans_ : newTrans_);
    if (oldQuat_ != newQuat_)
        target_->SetWorldRotation(isUndo ? oldQuat_ : newQuat_);
    if (oldScale_ != newScale_)
        target_->SetWorldScale(isUndo ? oldScale_ : newScale_);
}

bool UrhoTransformUndoRedo::CanMergeWith(UndoRedo* act) const
{
    if (auto other = dynamic_cast<UrhoTransformUndoRedo*>(act))
        return other->target_ == target_;
    return false;
}

void UrhoTransformUndoRedo::Merge(UndoRedo* act)
{
    if (auto other = dynamic_cast<UrhoTransformUndoRedo*>(act))
    {
        newTrans_ = other->newTrans_;
        newQuat_ = other->newQuat_;
        newScale_ = other->newScale_;
        text_ = other->text_;
    }
}
    