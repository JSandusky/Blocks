#pragma once

#include <Urho3D/Core/Object.h>
#include <Urho3D/Graphics/TextureCube.h>
#include <Urho3D/Container/Vector.h>

namespace Urho3D
{
    class Node;
    class RenderSurface;
    class Scene;
    class Texture2D;
    class Viewport;
    class Zone;
}

struct CapturingData;

/// TODO: ditch the frame cycle and do it all immediately, can be done from C++
class CubeCapture : public Urho3D::Object
{
    URHO3D_OBJECT(CubeCapture, Object);
public:
    CubeCapture(CapturingData* capture, Urho3D::Zone* zone, const Urho3D::String& baseName, const Urho3D::String& targetName, int targetID, unsigned cubeSize);
    ~CubeCapture();

    void Start();
    void Stop();

protected:
    void HandlePreRender(Urho3D::StringHash eventType, Urho3D::VariantMap& eventData);
    void HandlePostRender(Urho3D::StringHash eventType, Urho3D::VariantMap& eventData);

    Urho3D::String GetName(const Urho3D::String& path, const Urho3D::String& sceneName, const Urho3D::String& targetName, int targetID) const;
    Urho3D::CubeMapFace GetFaceForCycle(int cycle) const;
    Urho3D::String GetFaceName(Urho3D::CubeMapFace face) const;
    Urho3D::Quaternion RotationOf(Urho3D::CubeMapFace face) const;
    Urho3D::ResourceRef WriteXML(const Urho3D::String& path, const Urho3D::String& sceneName, const Urho3D::String& targetName, int targetID) const;

private:
    Urho3D::SharedPtr<Urho3D::Zone> zone_;
    Urho3D::SharedPtr<Urho3D::Node> cameraNode_;
    Urho3D::SharedPtr<Urho3D::Texture2D> targetTexture_;
    Urho3D::SharedPtr<Urho3D::RenderSurface> surface_;
    Urho3D::SharedPtr<Urho3D::Viewport> viewport_;

    Urho3D::String baseName_;
    Urho3D::String targetName_;
    int targetID_;
    int updateCycle_;
    unsigned cubeSize_;
    CapturingData* captureData_;
};

struct CapturingData
{
    ~CapturingData();

    void PrepareZonesForCubeRendering(Urho3D::SharedPtr<Urho3D::Scene> scene);
    void UnprepareZonesForCubeRendering();

    Urho3D::SharedPtr<Urho3D::Scene> scene_;
    Urho3D::Vector<Urho3D::SharedPtr<CubeCapture> > activeCapture_;
    Urho3D::Vector<Urho3D::SharedPtr<Urho3D::Zone> > cloneZones_;
    Urho3D::Vector<Urho3D::SharedPtr<Urho3D::Zone> > disabledZones_;
};