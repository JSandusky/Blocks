#include "DataObject.h"

#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Resource/XMLElement.h>

#include <algorithm>

#include <Urho3D/DebugNew.h>

std::unique_ptr<DataObjectDatabase> DataObjectDatabase::inst_;

DataObjectDefinition::DataObjectDefinition(const std::string& typeName, const std::vector<DataObjectField>& fields, const DataObjectCmds& cmds) :
    commands_(cmds)
{
    objectTypeName_ = typeName;
    insert(end(), fields.begin(), fields.end());
    unsigned fldIdx = 0;
    for (auto fld : fields)
        fieldIndices_[fld.fieldName_] = fldIdx++;
}

DataObject::DataObject(const DataObjectDefinition* definition) :
    definition_(definition)
{
    // may construct with null if intending to deserialize immediately
    if (definition_)
    {
        for (auto field : *definition_)
            push_back(field.defaultValue_);
    }
}

void DataObject::DispatchChange(const std::string& str, const Urho3D::Variant& var)
{
    if (onChange_)
        onChange_(str, var);
}

size_t DataObject::IndexOf(const std::string& name) const
{
    auto found = definition_->fieldIndices_.find(name);
    if (found != definition_->fieldIndices_.end())
        return (size_t)found->second;
    return -1;
}

Urho3D::Variant DataObject::GetField(const std::string& name) const
{
    size_t idx = IndexOf(name);
    if (idx != -1)
        return (*this)[idx];
    return Urho3D::Variant();
}

void DataObject::SetField(const std::string& name, const Urho3D::Variant& value)
{
    size_t idx = IndexOf(name);
    if (idx != -1)
    {
        (*this)[idx] = value;
        DispatchChange(name, value);
    }
}

void DataObject::SaveXML(Urho3D::XMLElement& intoElem)
{
    const auto& def = *definition_;
    intoElem.SetAttribute("typename", definition_->objectTypeName_.c_str());
    for (size_t i = 0; i < size(); ++i)
    {
        Urho3D::String fldName = def[i].fieldName_.c_str();
        if (isdigit(fldName[0]))
            fldName = "_" + fldName;
        fldName.Replace(" ", "");
        fldName.Replace("-", "_");
        intoElem.CreateChild(fldName).SetVariant((*this)[i]);
    }
}

void DataObject::LoadXML(Urho3D::XMLElement& fromElem)
{
    if (fromElem.IsNull())
        return;

    auto typeName = fromElem.GetAttribute("typename");
    if (auto typeDef = DataObjectDatabase::GetInst()->GetType(typeName.CString()))
    {
        definition_ = typeDef;
        const auto& def = *definition_;
        clear();
        for (auto field : def)
            push_back(field.defaultValue_);
        
        for (size_t i = 0; i < def.size(); ++i)
        {
            Urho3D::String fldName = def[i].fieldName_.c_str();
            if (isdigit(fldName[0]))
                fldName = "_" + fldName;
            fldName.Replace(" ", "");
            fldName.Replace("-", "_");
            if (auto found = fromElem.GetChild(fldName))
            {
                if (!found.IsNull())
                    (*this)[i] = found.GetVariant();
            }
        }
    }
}

DataObjectDatabase::DataObjectDatabase() 
{

}
DataObjectDatabase::~DataObjectDatabase()
{
    for (auto def : definitions_)
        delete def;
    definitions_.clear();
}

void DataObjectDatabase::Register(DataObjectDefinition* definition)
{
    definitions_.push_back(definition);
}

DataObjectDefinition* DataObjectDatabase::GetType(const std::string& typeDef)
{
    for (auto def : definitions_)
    {
        if (def->objectTypeName_.compare(typeDef) == 0)
            return def;
    }
    return nullptr;
}

DataObjectDatabase* DataObjectDatabase::GetInst()
{
    if (!inst_)
        inst_.reset(new DataObjectDatabase());
    return inst_.get();
}

DataObjectSelectable::DataObjectSelectable(DataObject* dataObject) :
    dataObject_(dataObject)
{
    
}

bool DataObjectSelectable::Is(void* t) const
{
    return dataObject_ == t;
}

bool DataObjectSelectable::Is(std::shared_ptr<Selectable> t) const
{
    if (auto rhs = std::dynamic_pointer_cast<DataObjectSelectable>(t))
        return rhs->dataObject_ == dataObject_;
    return false;
}

void DataObject::DrawEditor(DataObject* editObject)
{
    if (editObject->GetDefinition())
    {
        const auto& def = *editObject->GetDefinition();
        auto& dataObject = *editObject;
        ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());
        for (size_t i = 0; i < def.size(); ++i)
        {
            auto& fieldDef = def[i];
            auto& value = dataObject[i];

            if (fieldDef.dataFieldSettings_ & DF_SPLITTER)
                ImGui::Separator();

            ImGui::PushID(i + 1);
            if (value.GetType() != Urho3D::VAR_BOOL)
                ImGui::TextWrapped(fieldDef.fieldName_.c_str());

            if (fieldDef.dataFieldSettings_ & DF_POSITIVE)
            {
                switch (value.GetType())
                {
                case Urho3D::VAR_INTVECTOR2: {
                    Urho3D::IntVector2 v = value.GetIntVector2();
                    if (ImGui::DragInt2("##a", &v.x_, 1.0f, 0, 4096))
                        value = v;
                } break;
                case Urho3D::VAR_VECTOR2: {
                    Urho3D::Vector2 v = value.GetVector2();
                    if (ImGui::DragFloat2("##a", &v.x_, 1.0f, 0, 4096.0f))
                        value = v;
                } break;
                case Urho3D::VAR_FLOAT: {
                    float v = value.GetFloat();
                    if (ImGui::DragFloat("##a", &v, 1.0f, 0, 4096.0f))
                        value = v;
                } break;
                case Urho3D::VAR_INT: {
                    int v = value.GetInt();
                    if (ImGui::DragInt("##a", &v, 1.0f, 0, 4096))
                        value = v;
                } break;
                }
            }
            else if (value.GetType() == Urho3D::VAR_BOOL)
            {
                bool v = value.GetBool();
                if (ImGui::Checkbox(fieldDef.fieldName_.c_str(), &v))
                    value = v;
            }
            else if (Urho3D::ImGuiElement::EditVariant(value))
            {
                editObject->SetField(fieldDef.fieldName_, value);
            }
            ImGui::PopID();
        }

        for (auto cmd : def.commands_)
        {
            if (ImGui::Button(cmd.first.c_str()))
                cmd.second(editObject);
        }

        ImGui::PopItemWidth();
    }
}

void DataObjectSelectable::DrawProperties(const ImGuiTextFilter* filter)
{
    if (dataObject_->GetDefinition())
    {
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[3]);
        ImGui::Text(dataObject_->GetDefinition()->objectTypeName_.c_str());
        ImGui::PopFont();

        DataObject::DrawEditor(dataObject_);
    }
}