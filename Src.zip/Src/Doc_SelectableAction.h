#pragma once

#include <Urho3D/Input/Input.h>

#include "Doc_Actions.h"
#include "Doc_DocumentManager.h"

#include <functional>

/// General purpose application action, is almost always available
class AppAction : public Urho3D::InputBinding
{
public:
    typedef std::function<void()> CALL_DEF;
    typedef std::function<bool()> TEST_DEF;

    AppAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip);
    AppAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call);
    AppAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call, TEST_DEF test);
    virtual ~AppAction();

    virtual void Activated() override;
    virtual void ForceTrigger();
    virtual bool IsAvailable() const override;

    /// Returns true if anything was drawn.
    virtual bool DrawMenuItem();

    // Returns true if any were drawn
    static bool DrawItems(std::vector<Urho3D::SharedPtr<Urho3D::InputBinding> >& actions);

    CALL_DEF callback_;
    TEST_DEF callTest_;
};

/// Bindable action that is only available if a document of type T is active.
template<typename T>
class DocumentAction : public AppAction
{
public:
    typedef std::function<void(T*)> CALL_DEF;
    DocumentAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip) : AppAction(grp, act, tip)
    {

    }
    DocumentAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call) : AppAction(grp, act, tip),
         callback_(call)
    {

    }

    DocumentAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call, TEST_DEF test) : AppAction(grp, act, tip, nullptr, test),
        callback_(call)
    {

    }

    virtual ~DocumentAction() { }

    virtual void Activated() override
    {
        if (auto doc = DocumentManager::Get()->GetActiveDoc<T>())
        {
            if (callback_)
                callback_(doc.get());
        }
    }

    virtual bool IsAvailable() const override
    {
        if (!AppAction::IsAvailable())
            return false;

        if (auto doc = DocumentManager::Get()->GetActiveDoc<T>())
            return true;

        return false;
    }

    CALL_DEF callback_;
};

/// Input binding that requires a specific type of Selectable to be selected in the current document.
template<typename T>
class SelectableAction : public AppAction
{
public:
    typedef std::function<void(DocumentBase*, std::vector<std::shared_ptr<T>>)> CALL_DEF;

    SelectableAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip) : AppAction(grp, act, tip)
    {

    }
    SelectableAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call) : AppAction(grp, act, tip),
        callback_(call)
    {

    }
    SelectableAction(const Urho3D::String& grp, const Urho3D::String& act, const Urho3D::String& tip, CALL_DEF call, TEST_DEF test) : AppAction(grp, act, tip, nullptr, test),
        callback_(call)
    {

    }
    virtual ~SelectableAction() { }

    virtual bool IsAvailable() const override
    {
        if (!AppAction::IsAvailable())
            return false;

        if (auto doc = DocumentManager::Get()->GetActiveDocument())
        {
            if (doc->GetSelection().GetFirstOf<T>())
                return true;
        }
        return false;
    }

    virtual void Activated() override
    {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
        {
            if (callback_)
                callback_(doc.get(), doc->GetSelection().GetAll<T>());
        }
    }

    CALL_DEF callback_;
};