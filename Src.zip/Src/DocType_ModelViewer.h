#pragma once

#include <Urho3D/Core/Context.h>
#include <Urho3D/Container/Ptr.h>
#include <Urho3D/Container/Str.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>

#include "Doc_Document3D.h"

namespace Urho3D
{
    class AnimatedModel;
    class Material;
    class Model;
    class Node;
    class StaticModel;
}

class ModelViewerDocumentType : public DocumentType
{
public:
    ModelViewerDocumentType();

    virtual bool CanCreateNew() const { return false; }
    virtual std::shared_ptr<DocumentBase> NewDocument() { return nullptr; }
    virtual std::shared_ptr<DocumentBase> OpenPath(const Urho3D::String& path) override;
};

/// Views an Urho3D model file. Can be used to edit bone collision radii/bounds
class ModelViewerDocument : public Document3D, public IPropertyDocument
{
    friend class GUI_ModelViewerView;
public:
    ModelViewerDocument(Urho3D::Context* ctx, const Urho3D::String& path);
    virtual ~ModelViewerDocument();

    virtual unsigned GetTabColor() const override { return ImColor(120, 120, 30, 255); }
    virtual bool Save() override;
    virtual void SaveAs() override;
    virtual bool Close() override;

    virtual void PreDraw() override;
    virtual void DrawProperties(ImGuiTextFilter*) override;
    virtual void DrawMasterButtons() override;

protected:
    Urho3D::SharedPtr<Urho3D::Model> modelData_;
    Urho3D::SharedPtr<Urho3D::Node> modelNode_;
    Urho3D::SharedPtr<Urho3D::AnimatedModel> modelComp_;
    Urho3D::SharedPtr<Urho3D::Material> material_;

    unsigned selectedBoneIndex_ = -1;
    bool drawSkeleton_ = true;
    bool drawBoneSphere_ = false;
    bool drawBoneBox_ = false;
    bool depthTestVolume_ = false;
};
