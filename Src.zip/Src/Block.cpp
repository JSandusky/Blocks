//
// Copyright (c) 2008-2018 the Urho3D project.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#ifdef URHO3D_ANGELSCRIPT
#include <Urho3D/AngelScript/ScriptFile.h>
#include <Urho3D/AngelScript/Script.h>
#endif

#include <Urho3D/Audio/Audio.h>
#include <Urho3D/Core/Main.h>
#include <URho3D/Engine/DebugHud.h>
#include <Urho3D/Engine/Engine.h>
#include <Urho3D/Engine/EngineDefs.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/Graphics/Graphics.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Input/Input.h>
#include <Urho3D/IO/Log.h>
#include <Urho3D/Graphics/Renderer.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Resource/ResourceEvents.h>
#include <Urho3D/UI/UI.h>
#include <Urho3D/Graphics/Zone.h>

#include <Urho3D/ThirdParty/SDL/SDL.h>
#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/imgui_dock.h>
#include <Urho3D/ThirdParty/ImGui/imgui_tabs.h>
#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include "ActionNames.h"
#include "BitNames.h"
#include "Block.h"
#include "DataObject.h"
#include "DocType_CommonActions.h"
#include "Doc_DocumentManager.h"
#include "Doc_SelectableAction.h"
#include "GUI_Main.h"
#include "GUI_Pane3D.h"
#include "Scripting.h"
#include "UX.h"

// Document types
#include "DocType_Scene.h"
#include "DocType_Particle.h"
#include "DocType_Material.h"
#include "DocType_ModelViewer.h"
#include "DocType_UI.h"

#include <Urho3D/ThirdParty/SDL/SDL.h>

#include <memory>

#include <windows.h>

#include <Urho3D/DebugNew.h>

bool IsShiftDown()
{
    return ImGui::GetIO().KeyShift;
    //return GetAsyncKeyState(VK_SHIFT);
}

bool IsCtrlDown()
{
    return ImGui::GetIO().KeyCtrl;
    //return GetAsyncKeyState(VK_CONTROL);
}

bool IsAltDown()
{
    return ImGui::GetIO().KeyAlt;
    //return GetAsyncKeyState(18);
}

URHO3D_DEFINE_APPLICATION_MAIN(BlockExe);

ImGuiElement* GetImGuiElement()
{
    return BlockExe::GetInst()->GetImGuiElem();
}

BlockExe* BlockExe::inst_ = nullptr;

BlockExe::BlockExe(Context* context) :
    Application(context),
    commandLineRead_(false)
{
    inst_ = this;
    hub_ = new GUI_MainHub();
    MouseCapture::Get()->SetContext(context_);

    hub_->docks_.push_back(new GUI_LogView());
    hub_->docks_.push_back(new GUI_ProfilerView());
    hub_->docks_.push_back(new GUI_ResourceView());
    hub_->docks_.push_back(new GUI_PropertiesView());
    hub_->docks_.push_back(new GUI_SceneTreeView());
    hub_->docks_.push_back(new GUI_ShadersView());
    hub_->docks_.push_back(new GUI_AssetBrowserView());
    hub_->docks_.push_back(new GUI_TimelineView());
    hub_->docks_.push_back(new GUI_HistoryView());
    hub_->docks_.push_back(new GUI_DataGrid());

    hub_->LoadXML();

    CoInitializeEx(0, COINIT_APARTMENTTHREADED | COINIT_DISABLE_OLE1DDE);

    InitializeDataObjects();
}

BlockExe::~BlockExe()
{
    delete bitNames_;
    delete hub_;
    DocumentManager::Release();
    inst_ = nullptr;
}

void BlockExe::Setup()
{
    // Read command line from a file if no arguments given. This is primarily intended for mobile platforms.
    // Note that the command file name uses a hardcoded path that does not utilize the resource system
    // properly (including resource path prefix), as the resource system is not yet initialized at this point
    //auto* filesystem = GetSubsystem<FileSystem>();
    //const String commandFileName = filesystem->GetProgramDir() + "Data/CommandLine.txt";
    //if (GetArguments().Empty() && filesystem->FileExists(commandFileName))
    //{
    //    SharedPtr<File> commandFile(new File(context_, commandFileName));
    //    if (commandFile->IsOpen())
    //    {
    //        commandLineRead_ = true;
    //        String commandLine = commandFile->ReadLine();
    //        commandFile->Close();
    //        ParseArguments(commandLine, false);
    //        // Reparse engine startup parameters now
    //        engineParameters_ = Engine::ParseParameters(GetArguments());
    //    }
    //}

#if 0
    // Show usage if not found
    if ((GetArguments().Size() || commandLineRead_))
    {
        ErrorExit("Usage: Urho3DPlayer <scriptfile> [options]\n\n"
            "The script file should implement the function void Start() for initializing the "
            "application and subscribing to all necessary events, such as the frame update.\n"
            #ifndef _WIN32
            "\nCommand line options:\n"
            "-x <res>     Horizontal resolution\n"
            "-y <res>     Vertical resolution\n"
            "-m <level>   Enable hardware multisampling\n"
            "-v           Enable vertical sync\n"
            "-t           Enable triple buffering\n"
            "-w           Start in windowed mode\n"
            "-s           Enable resizing when in windowed mode\n"
            "-q           Enable quiet mode which does not log to standard output stream\n"
            "-b <length>  Sound buffer length in milliseconds\n"
            "-r <freq>    Sound mixing frequency in Hz\n"
            "-pp <paths>  Resource prefix path(s), separated by semicolons, default to executable path\n"
            "The resource prefix paths can also be defined using URHO3D_PREFIX_PATH env - var\n"
            "When both are defined, the paths set by -pp takes higher precedence\n"
            "-p <paths>   Resource path(s) to use, separated by semicolons, default to 'Data;CoreData'\n"
            "-pf <files>  Resource package file to use, separated by semicolons, default to none\n"
            "-ap <paths>  Resource autoload path(s), separated by semicolons, default to 'AutoLoad'\n"
            "-log <level> Change the log level, valid 'level' values: 'debug', 'info', 'warning', 'error'\n"
            "-ds <file>   Dump used shader variations to a file for precaching\n"
            "-mq <level>  Material quality level, default 2 (high)\n"
            "-tq <level>  Texture quality level, default 2 (high)\n"
            "-tf <level>  Texture filter mode, default 2 (trilinear)\n"
            "-af <level>  Texture anisotropy level, default 4. Also sets anisotropic filter mode\n"
            "-gl2         Force OpenGL 2 use even if OpenGL 3 is available\n"
            "-flushgpu    Flush GPU command queue each frame. Effective only on Direct3D\n"
            "-borderless  Borderless window mode\n"
            "-lowdpi      Force low DPI mode on Retina display\n"
            "-headless    Headless mode. No application window will be created\n"
            "-landscape   Use landscape orientations (iOS only, default)\n"
            "-portrait    Use portrait orientations (iOS only)\n"
            "-monitor <num> Monitor number to use\n"
            "-hz <freq>   Monitor refresh rate to use\n"
            "-prepass     Use light pre-pass rendering\n"
            "-deferred    Use deferred rendering\n"
            "-renderpath <name> Use the named renderpath (must enter full resource name)\n"
            "-lqshadows   Use low-quality (1-sample) shadow filtering\n"
            "-noshadows   Disable shadow rendering\n"
            "-nolimit     Disable frame limiter\n"
            "-nothreads   Disable worker threads\n"
            "-nosound     Disable sound output\n"
            "-noip        Disable sound mixing interpolation\n"
            "-touch       Touch emulation on desktop platform\n"
            #endif
        );
    }
    else
    {
        // Use the script file name as the base name for the log file
        engineParameters_[EP_LOG_NAME] = filesystem->GetAppPreferencesDir("urho3d", "logs") + "Block.log";
    }
#endif
    auto filesystem = GetSubsystem<FileSystem>();
    engineParameters_[EP_LOG_NAME] = filesystem->GetAppPreferencesDir("urho3d", "logs") + "Block.log";
    engineParameters_[EP_FULL_SCREEN] = false;
    engineParameters_[EP_VSYNC] = false;

    LoadDataObjects();
    extern std::unique_ptr<DataObject> secretApplicationSettings_;
    if (!secretApplicationSettings_->GetField("Maximized").GetBool())
    {
        engineParameters_[EP_WINDOW_POSITION_X] = secretApplicationSettings_->GetField("PosX").GetInt();
        engineParameters_[EP_WINDOW_POSITION_Y] = secretApplicationSettings_->GetField("PosY").GetInt();
    }    

    engineParameters_[EP_WINDOW_WIDTH] = secretApplicationSettings_->GetField("Width").GetInt();
    engineParameters_[EP_WINDOW_HEIGHT] = secretApplicationSettings_->GetField("Height").GetInt();
    engineParameters_[EP_WINDOW_TITLE] = "Blocks";

    // Construct a search path to find the resource prefix with two entries:
    // The first entry is an empty path which will be substituted with program/bin directory -- this entry is for binary when it is still in build tree
    // The second and third entries are possible relative paths from the installed program/bin directory to the asset directory -- these entries are for binary when it is in the Urho3D SDK installation location
    if (!engineParameters_.Contains(EP_RESOURCE_PREFIX_PATHS))
        engineParameters_[EP_RESOURCE_PREFIX_PATHS] = ";../share/Resources;../share/Urho3D/Resources";
}

void BlockExe::Start()
{
    this->GetSubsystem<Graphics>()->SetWindowTitle("Blocks");
    // Reattempt reading the command line from the resource system now if not read before
    // Note that the engine can not be reconfigured at this point; only the script name can be specified
    if (GetArguments().Empty() && !commandLineRead_)
    {
        SharedPtr<File> commandFile = GetSubsystem<ResourceCache>()->GetFile("CommandLine.txt", false);
        if (commandFile)
        {
            String commandLine = commandFile->ReadLine();
            commandFile->Close();
            ParseArguments(commandLine, false);
        }    
    }

#ifdef URHO3D_ANGELSCRIPT
    // Instantiate and register the AngelScript subsystem
    context_->RegisterSubsystem(new Script(context_));

    auto script = context_->GetSubsystem<Script>();
    RegisterAngelscript(script->GetScriptEngine());
#endif
    
    //masterScene_ = new Scene(engine_->GetContext());

    ResourceCache* cache = GetSubsystem<ResourceCache>();
    cache->SetAutoReloadResources(true);

    bitNames_ = new BitNamesTable();

    FileSystem* fs = GetSubsystem<FileSystem>();
    fs->SetCurrentDir(fs->GetProgramDir());
    extern std::unique_ptr<DataObject> editorSettings_;
    auto paths = editorSettings_->GetField("Data Paths").GetStringVector();
    for (int i = 0; i < paths.Size(); ++i)
    {
        cache->AddResourceDir(paths[i]);
    }

    Graphics* graphics = GetSubsystem<Graphics>();

#ifdef URHO3D_ANGELSCRIPT
    //DEV script->DumpAPI(C_HEADER);

    if (auto scriptFile = cache->GetResource<ScriptFile>("Data/EditorInit.as", false))
    {
        scriptFile->Execute("void Start()");
        SubscribeToEvent(scriptFile, Urho3D::E_RELOADFINISHED, URHO3D_HANDLER(BlockExe, MainScriptReloaded));
    }
#endif

    extern std::unique_ptr<DataObject> secretApplicationSettings_;

    graphics->SetWindowTitle("Blocks");
    GetSubsystem<Input>()->SetMouseMode(MM_FREE);
    graphics->SetMode(
        secretApplicationSettings_->GetField("Width").GetInt(), secretApplicationSettings_->GetField("Height").GetInt(), 
        false /*fullscreen*/, 
        false, /*borderless*/ 
        true /*resizable*/, 
        true /* high DPI */, 
        true /* VSync */, 
        false /* triple buffer */, 
        0 /* MSAA */,
        0 /* Monitor */, 
        45 /* target FPS */);

    GetSubsystem<Input>()->SetMouseMode(Urho3D::MM_FREE);
    GetSubsystem<Input>()->SetMouseVisible(true);
    imguiElem_ = new ImGuiElement(GetContext());
    GetSubsystem<UI>()->GetRoot()->AddChild(imguiElem_);
    SubscribeToEvent(imguiElem_, E_IMGUI_DRAW, URHO3D_HANDLER(BlockExe, RenderImGui));
    SubscribeToEvent(E_MOUSEMOVE, URHO3D_HANDLER(BlockExe, MouseMove));
    SubscribeToEvent(E_MOUSEBUTTONUP, URHO3D_HANDLER(BlockExe, MouseUp));
    SubscribeToEvent(StringHash("ExitRequested"), URHO3D_HANDLER(BlockExe, HandleExit));
    SubscribeToEvent(Urho3D::E_INPUTFOCUS, URHO3D_HANDLER(BlockExe, FocusLost));

    SDL_SetWindowResizable(graphics->GetWindow(), SDL_TRUE);
    if (secretApplicationSettings_->GetField("Maximized").GetBool())
        graphics->Maximize();
    else
        graphics->SetWindowPosition(secretApplicationSettings_->GetField("PosX").GetInt(), secretApplicationSettings_->GetField("PosY").GetInt());

    engine_->SetAutoExit(false);
    engine_->SetMaxFps(60);
    engine_->SetMaxInactiveFps(10);

    auto debugHud = engine_->CreateDebugHud();
    debugHud->SetMode(DEBUGHUD_SHOW_STATS);

    //DocumentManager::Get()->AddDocument(std::make_shared<SceneDocument>(GetContext()));

    InitializeBindings();
    hub_->InitializeDockActions();
    SubscribeToEvent(E_BINDINGTRIGGERED, URHO3D_HANDLER(BlockExe, OnBindingTrigger));
    SetupDocumentTypes();
    LoadBindings();

    ImGui::LoadDock();

    // Initialize ImGUI style

    ImGuiStyle& style = ImGui::GetStyle();

    float fontSize = 15.0f;
    float roundness = 2.0f;
    ImVec4 white = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
    ImVec4 text = ImVec4(0.76f, 0.77f, 0.8f, 1.0f);
    ImVec4 black = ImVec4(0.0f, 0.0f, 0.0f, 1.0f);
    ImVec4 backgroundVeryDark = ImVec4(0.08f, 0.086f, 0.094f, 1.00f);
    ImVec4 backgroundDark = ImVec4(0.117f, 0.121f, 0.145f, 1.00f);
    ImVec4 backgroundMedium = ImVec4(0.26f, 0.26f, 0.27f, 1.0f);
    ImVec4 backgroundLight = ImVec4(0.37f, 0.38f, 0.39f, 1.0f);
    ImVec4 highlightBlue = ImVec4(0.172f, 0.239f, 0.341f, 1.0f);
    ImVec4 highlightBlueActive = ImVec4(0.182f, 0.249f, 0.361f, 1.0f);
    ImVec4 highlightBlueHovered = ImVec4(0.202f, 0.269f, 0.391f, 1.0f);
    ImVec4 barBackground = ImVec4(0.078f, 0.082f, 0.09f, 1.0f);
    ImVec4 bar = ImVec4(0.164f, 0.180f, 0.231f, 1.0f);
    ImVec4 barHovered = ImVec4(0.411f, 0.411f, 0.411f, 1.0f);
    ImVec4 barActive = ImVec4(0.337f, 0.337f, 0.368f, 1.0f);

    ImVec4 cornFlowerBlue = ImVec4(100 / 255.0f, 149 / 255.0f, 237 / 255.0f, 1);
    highlightBlueHovered = cornFlowerBlue;
    text = ImVec4(1, 1, 1, 1);

    // Spatial
    style.WindowBorderSize = 1.0f;
    style.FrameBorderSize = 1.0f;
    //style.WindowMinSize		= ImVec2(160, 20);
    style.FramePadding = ImVec2(5, 5);
    style.ItemSpacing = ImVec2(6, 5);
    //style.ItemInnerSpacing	= ImVec2(6, 4);
    style.Alpha = 1.0f;
    style.WindowRounding = roundness;
    style.FrameRounding = roundness;
    style.PopupRounding = 0;
    style.PopupBorderSize = 2;
    //style.IndentSpacing		= 6.0f;
    //style.ItemInnerSpacing	= ImVec2(2, 4);
    //style.ColumnsMinSpacing	= 50.0f;
    //style.GrabMinSize			= 14.0f;
    style.GrabRounding = roundness;
    //style.ScrollbarSize		= 12.0f;
    style.ScrollbarRounding = roundness;

    // Colors
    style.Colors[ImGuiCol_Text] = text;
    //style.Colors[ImGuiCol_TextDisabled]			= ImVec4(0.86f, 0.93f, 0.89f, 0.28f);
    style.Colors[ImGuiCol_WindowBg] = backgroundDark;
    //style.Colors[ImGuiCol_ChildBg]				= ImVec4(0.20f, 0.22f, 0.27f, 0.58f);
    style.Colors[ImGuiCol_Border] = black;
    //style.Colors[ImGuiCol_BorderShadow]			= ImVec4(0.00f, 0.00f, 0.00f, 0.00f);
    style.Colors[ImGuiCol_FrameBg] = bar;
    style.Colors[ImGuiCol_FrameBgHovered] = highlightBlue;
    style.Colors[ImGuiCol_FrameBgActive] = highlightBlueHovered;
    style.Colors[ImGuiCol_TitleBg] = backgroundVeryDark;
    //style.Colors[ImGuiCol_TitleBgCollapsed]		= ImVec4(0.20f, 0.22f, 0.27f, 0.75f);
    style.Colors[ImGuiCol_TitleBgActive] = bar;
    style.Colors[ImGuiCol_MenuBarBg] = backgroundVeryDark;
    style.Colors[ImGuiCol_ScrollbarBg] = barBackground;
    style.Colors[ImGuiCol_ScrollbarGrab] = bar;
    style.Colors[ImGuiCol_ScrollbarGrabHovered] = barHovered;
    style.Colors[ImGuiCol_ScrollbarGrabActive] = barActive;
    style.Colors[ImGuiCol_CheckMark] = white;
    style.Colors[ImGuiCol_SliderGrab] = bar;
    style.Colors[ImGuiCol_SliderGrabActive] = barActive;
    style.Colors[ImGuiCol_Button] = barActive;
    style.Colors[ImGuiCol_ButtonHovered] = highlightBlue;
    style.Colors[ImGuiCol_ButtonActive] = highlightBlueHovered;
    style.Colors[ImGuiCol_Header] = highlightBlue; // selected items (tree, menu bar etc.)
    style.Colors[ImGuiCol_HeaderHovered] = highlightBlueHovered; // hovered items (tree, menu bar etc.)
    style.Colors[ImGuiCol_HeaderActive] = highlightBlueActive;
    style.Colors[ImGuiCol_Separator] = backgroundLight;
    //style.Colors[ImGuiCol_SeparatorHovered]		= ImVec4(0.92f, 0.18f, 0.29f, 0.78f);
    //style.Colors[ImGuiCol_SeparatorActive]		= ImVec4(0.92f, 0.18f, 0.29f, 1.00f);
    style.Colors[ImGuiCol_ResizeGrip] = backgroundMedium;
    style.Colors[ImGuiCol_ResizeGripHovered] = highlightBlue;
    style.Colors[ImGuiCol_ResizeGripActive] = highlightBlueHovered;
    style.Colors[ImGuiCol_CloseButton] = backgroundLight;
    style.Colors[ImGuiCol_CloseButtonHovered] = backgroundLight;
    style.Colors[ImGuiCol_CloseButtonActive] = backgroundLight;
    //style.Colors[ImGuiCol_PlotLines]				= ImVec4(0.86f, 0.93f, 0.89f, 0.63f);
    //style.Colors[ImGuiCol_PlotLinesHovered]		= ImVec4(0.92f, 0.18f, 0.29f, 1.00f);
    style.Colors[ImGuiCol_PlotHistogram] = highlightBlue; // Also used for progress bar
    style.Colors[ImGuiCol_PlotHistogramHovered] = highlightBlueHovered;
    style.Colors[ImGuiCol_TextSelectedBg] = highlightBlue;
    style.Colors[ImGuiCol_PopupBg] = backgroundVeryDark;
    style.Colors[ImGuiCol_DragDropTarget] = backgroundLight;
    //style.Colors[ImGuiCol_ModalWindowDarkening]	= ImVec4(0.20f, 0.22f, 0.27f, 0.73f);
}

void BlockExe::Stop()
{

}

void BlockExe::MainScriptReloaded(StringHash event, VariantMap& data)
{
    ClearScriptRegistration();
    if (auto scriptFile = GetSubsystem<ResourceCache>()->GetResource<ScriptFile>("Data/EditorInit.as", false))
        scriptFile->Execute("void Start()");
}

void BlockExe::RenderImGui(StringHash event, VariantMap& data)
{
    static StringHash beginEventID("EDITOR_BEGIN_GUI");
    SendEvent("EDITOR_BEGIN_GUI");

    auto graphics = GetSubsystem<Graphics>();
    IntRect r(0, 0, graphics->GetWidth(), graphics->GetHeight());
    if (DocumentManager::Get()->GetActiveDocument())
        hub_->Draw(r);
    else
        hub_->Draw(r);

    static StringHash endEventID("EDITOR_END_GUI");
    SendEvent("EDITOR_END_GUI");

    MouseCapture::ProcessKeys();
    auto input = GetSubsystem<Input>();
    ShowQuickAction(input->GetKeyPress(KEY_SPACE) && ImGui::GetIO().KeyCtrl);
    ModalWindows::Get()->Run();
}

void BlockExe::MouseMove(StringHash event, VariantMap& data)
{
    auto input = GetSubsystem<Input>();
    auto pos = input->GetMousePosition();
    auto delta = input->GetMouseMove();

    if (!MouseCapture::Process(pos, delta))
    {
        input->SetMouseMode(MM_FREE);
        input->SetMouseVisible(true);
    }
}

void BlockExe::MouseUp(StringHash event, VariantMap& data)
{
    int btn = data[Urho3D::MouseButtonUp::P_BUTTON].GetInt();
    if (MouseCapture::Get()->CheckDeactivation(btn))
        MouseCapture::Get()->Deactivate();
}

void BlockExe::FocusLost(StringHash event, VariantMap& data)
{
    if (!data[Urho3D::InputFocus::P_FOCUS].GetBool())
        MouseCapture::Get()->Deactivate();
}

void BlockExe::HandleExit(StringHash event, VariantMap& data)
{
    extern std::unique_ptr<DataObject> secretApplicationSettings_;
    if (auto win = GetSubsystem<Graphics>()->GetWindow())
    {
        int x, y, sx, sy;
        SDL_GetWindowPosition(win, &x, &y);
        SDL_GetWindowSize(win, &sx, &sy);
        secretApplicationSettings_->SetField("Width", sx);
        secretApplicationSettings_->SetField("Height", sy);
        secretApplicationSettings_->SetField("PosX", x);
        secretApplicationSettings_->SetField("PosY", y);
        secretApplicationSettings_->SetField("Maximized", (bool)(SDL_GetWindowFlags(win) & SDL_WINDOW_MAXIMIZED));
    }

    SaveDataObjects();
    SaveBindings();

    ModalWindows::Get()->Push({
        "Are you sure you want to exit?",
        "Close Program",
        { 
            { "Close",
                [this]() {
                    auto fs = GetContext()->GetSubsystem<FileSystem>();
                    fs->SetCurrentDir(fs->GetProgramDir());
                    ClearScriptRegistration();
                    ImGui::ShutdownTabs();
                    ImGui::SaveDock();
                    ImGui::ShutdownDock();
                    DocumentManager::Release();
                    BlockExe::GetInst()->GetImGuiElem().Reset();
                    engine_->Exit();
                    CoUninitialize();
                },
            }
        }
    });
}

std::unique_ptr<DataObject> secretApplicationSettings_;
std::unique_ptr<DataObject> viewportSettings_;
std::unique_ptr<DataObject> editorSettings_;
std::unique_ptr<DataObject> lightmapSettings_;
std::unique_ptr<DataObject> batchOptimizerSettings_;
std::unique_ptr<DataObject> imposterBakeSettings_;
std::unique_ptr<DataObject> particlePointExportSettings_;
std::unique_ptr<DataObject> gizmoSettings_;

void BlockExe::InitializeDataObjects()
{
    DataObjectDefinition* secretAppDef = new DataObjectDefinition("Secret Application Settings", {
        { "Width", Variant((int)1024) },
        { "Height", Variant((int)768) },
        { "PosX", Variant((int)0) },
        { "PosY", Variant((int)0) },
        { "Maximized", Variant(false) },

        // OBJ export
        { "OBJ Selected Drawables Only", Variant(true) },
        { "OBJ Z Up", Variant(false) },
        { "OBJ Right Handed", Variant(false) },
    });
    DataObjectDatabase::GetInst()->Register(secretAppDef);
    secretApplicationSettings_.reset(new DataObject(secretAppDef));

    DataObjectDefinition* viewportDef = new DataObjectDefinition(ICON_FA_COGS " Viewport Settings", {
        //{ "Fog Color", Variant(Color::BLACK) },
        { "Draw Cursor Target", Variant(true) },
        { "Draw Scene Icons", Variant(true) },
        { "Invert Orbit Y Axis", Variant(false) },
        { "Default Mouse Orbit", Variant(false) },
        { "Show Grid", Variant(true), DF_SPLITTER },
        { "2D Grid Mode", Variant(false) },
        { "Grid Size", Variant(30.0f), DF_POSITIVE },
        { "Grid Subdivisions", Variant(1.0f), DF_POSITIVE },
        { "Grid Scale", Variant(1.0f), DF_POSITIVE },
        { "Render Path", Variant(ResourceRef(StringHash("RenderPath"))) }
    });
    DataObjectDatabase::GetInst()->Register(viewportDef);
    viewportSettings_.reset(new DataObject(viewportDef));
    //viewportSettings_->SetOnChange([](const std::string& name, const Urho3D::Variant& val) {
    //    if (name.compare("Fog Color") == 0)
    //        BlockExe::GetInst()->GetSubsystem<Renderer>()->GetDefaultZone()->SetFogColor(val.GetColor());
    //});

    DataObjectDefinition* lightmapDef = new DataObjectDefinition(ICON_FA_LIGHTBULB " Lightmap Settings", {
        { "Max Resolution", Variant(IntVector2(1024, 1024)), DF_POSITIVE },
        { "Desired Lumel Density", Variant(8), DF_POSITIVE },
        { "Environment Cube Face Resolution", Variant(128), DF_POSITIVE },
        { "Cubemap Filter Tool", Variant(""), DF_PATH_EXE },
        { "Cubemap Filter Params", Variant("") },
    });
    DataObjectDatabase::GetInst()->Register(lightmapDef);
    lightmapSettings_.reset(new DataObject(lightmapDef));

    DataObjectDefinition* batchOptDef = new DataObjectDefinition(ICON_FA_TACHOMETER_ALT " Static Batching Wizard", {
        { "Cluster Dimension", Variant((int)64), DF_POSITIVE },
        { "Compile Shadow Geometry", Variant(true) },
        { "Shadow Geom Cluster Dimension", Variant((int)64), DF_POSITIVE }
    });
    DataObjectDatabase::GetInst()->Register(batchOptDef);
    batchOptimizerSettings_.reset(new DataObject(batchOptDef));

    DataObjectDefinition* editorDef = new DataObjectDefinition(ICON_FA_COGS " Editor Settings", {
        { "Default Components Open", Variant(false) },
        { "Hide Property Reset Button", Variant(false) },
        { "Auto-reload Prefabs", Variant(true) },
        { "Show Temporary Objects", Variant(true) },
        { "Highlight Prefab Instances", Variant(true) },
        { "Data Paths", Variant(StringVector({"CoreData", "Data"})), DF_FOLDER_PATH },
    });
    DataObjectDatabase::GetInst()->Register(editorDef);
    editorSettings_.reset(new DataObject(editorDef));

    DataObjectDefinition* imposterBakeDef = new DataObjectDefinition(ICON_FA_CAMERA " Imposter Bake", {
        { "Render Normals", Variant(true) },
        { "Render Depth", Variant(true) },
    });
    DataObjectDatabase::GetInst()->Register(imposterBakeDef);
    imposterBakeSettings_.reset(new DataObject(imposterBakeDef));

    DataObjectDefinition* particleExportDef = new DataObjectDefinition(ICON_FA_DOWNLOAD " Export Points", {
        { "Export Direction", Variant(false) },
        { "Export Size", Variant(false) },
        { "Export Rotation", Variant(false) }
    });
    DataObjectDatabase::GetInst()->Register(particleExportDef);
    particlePointExportSettings_.reset(new DataObject(particleExportDef));

    DataObjectDefinition* gizmoSettingsDef = new DataObjectDefinition(ICON_FA_ARROWS_ALT " Manipulator Settings", {
        { "Snap Position", Variant(false) },
        { "Snap position spacing", Variant(1.0f) },
        { "Snap Rotation", Variant(false) },
        { "Snap rotation degrees", Variant(45.0f) },
        { "Show Gizmo Delta Metrics", Variant(true) },
        { "Show Gizmo Grid", Variant(true) },
    });
    DataObjectDatabase::GetInst()->Register(gizmoSettingsDef);
    gizmoSettings_.reset(new DataObject(gizmoSettingsDef));
}

void BlockExe::SaveDataObjects()
{
    hub_->SaveXML();

    bitNames_->Save();
    for (auto d : hub_->docks_)
        d->SaveData();

    auto fs = GetSubsystem<FileSystem>();
    auto dir = fs->GetAppPreferencesDir("Urho3D", "Blocks");
    dir += "Config.xml";

    SharedPtr<XMLFile> file(new XMLFile(GetContext()));
    auto root = file->CreateRoot("dataobjectlist");

    secretApplicationSettings_->SaveXML(root.CreateChild("secret_app_settings"));
    viewportSettings_->SaveXML(root.CreateChild("viewport_settings"));
    editorSettings_->SaveXML(root.CreateChild("editor_settings"));
    lightmapSettings_->SaveXML(root.CreateChild("lightmap"));
    imposterBakeSettings_->SaveXML(root.CreateChild("imposter_bake"));
    particlePointExportSettings_->SaveXML(root.CreateChild("particle_export"));
    gizmoSettings_->SaveXML(root.CreateChild("gizmo"));

    file->SaveFile(dir);
}

void BlockExe::LoadDataObjects()
{
    auto fs = GetSubsystem<FileSystem>();
    auto dir = fs->GetAppPreferencesDir("Urho3D", "Blocks");
    dir += "Config.xml";

    if (!fs->FileExists(dir))
        return;

    SharedPtr<File> fl(new File(GetContext(), dir));
    SharedPtr<XMLFile> file(new XMLFile(GetContext()));
    if (!file->Load(*fl))
        return;
    
    auto root = file->GetRoot();
    secretApplicationSettings_->LoadXML(root.GetChild("secret_app_settings"));
    viewportSettings_->LoadXML(root.GetChild("viewport_settings"));
    editorSettings_->LoadXML(root.GetChild("editor_settings"));
    lightmapSettings_->LoadXML(root.GetChild("lightmap"));
    imposterBakeSettings_->LoadXML(root.GetChild("imposter_bake"));
    particlePointExportSettings_->LoadXML(root.GetChild("particle_export"));
    gizmoSettings_->LoadXML(root.GetChild("gizmo"));
}

void BlockExe::InitializeBindings()
{
    auto& docTypes = DocumentManager::Get()->GetDocumentTypes();
    auto input = GetSubsystem<Input>();

    SharedPtr<InputBinding> binding;

    binding = new AppAction("Application Core", ACTION_SAVE, "Save open document");
    binding->FromString("CTRL + S");
    input->AddInputBinding(binding);

    binding = new AppAction("Application Core", ACTION_SAVE_AS, "Save open document as");
    binding->FromString("CTRL + SHIFT + S");
    input->AddInputBinding(binding);
    
    binding = new AppAction("Application Core", ACTION_OPEN, "Open a document");
    binding->FromString("CTRL + O");
    input->AddInputBinding(binding);

    binding = new AppAction("Application Core", ACTION_CLOSE, "Close current document");
    binding->FromString("CTRL + W");
    input->AddInputBinding(binding);

    binding = new AppAction("Application Core", ACTION_HELP, "View documentation");
    binding->FromString("CTRL + H");
    input->AddInputBinding(binding);

    StandardActions::InitializeSceneStandardActions();
}

void BlockExe::LoadBindings()
{
    auto fs = GetSubsystem<FileSystem>();
    auto dir = fs->GetAppPreferencesDir("Urho3D", "Blocks");
    dir += "bindings.xml";

    if (!fs->FileExists(dir))
        return;

    SharedPtr<File> fl(new File(GetContext(), dir));
    SharedPtr<XMLFile> file(new XMLFile(GetContext()));
    if (!file->Load(*fl))
        return;

    XMLElement root = file->GetRoot("bindings");

    auto bindings = GetSubsystem<Input>()->GetInputBindings();
    auto getBinding = [](Vector<SharedPtr<InputBinding>>& bindings, String name, String grp) -> SharedPtr<InputBinding>
    {
        for (auto bind : bindings)
            if (bind->actionName_.Compare(name, false) == 0 && bind->groupName_.Compare(grp) == 0)
                return bind;
        return nullptr;
    };

    if (root.NotNull())
    {
        XMLElement child = root.GetChild("binding");
        while (child.NotNull())
        {
            auto found = getBinding(bindings, child.GetAttribute("action"), child.GetAttribute("group"));
            if (found != nullptr)
            {
                String val = child.GetValue();
                if (val != "< no binding >")
                    found->FromString(child.GetValue());
            }
            child = child.GetNext("binding");
        }
    }
}

void BlockExe::SaveBindings()
{
    auto fs = GetSubsystem<FileSystem>();
    auto dir = fs->GetAppPreferencesDir("Urho3D", "Blocks");
    dir += "bindings.xml";

    SharedPtr<XMLFile> file(new XMLFile(GetContext()));
    auto root = file->CreateRoot("bindings");

    auto bindings = GetSubsystem<Input>()->GetInputBindings();
    for (auto bind : bindings)
    {
        auto bindElem = root.CreateChild("binding");
        bindElem.SetAttribute("action", bind->actionName_);
        bindElem.SetAttribute("group", bind->groupName_);
        bindElem.SetValue(bind->ToString());
    }

    file->SaveFile(dir);
}

void BlockExe::SetupDocumentTypes()
{
    DocumentManager::Get()->GetDocumentTypes().push_back(std::make_shared<SceneDocumentType>());
    DocumentManager::Get()->GetDocumentTypes().push_back(std::make_shared<MaterialDocumentType>());
    DocumentManager::Get()->GetDocumentTypes().push_back(std::make_shared<ModelViewerDocumentType>());
    DocumentManager::Get()->GetDocumentTypes().push_back(std::make_shared<ParticleDocumentType>());
    DocumentManager::Get()->GetDocumentTypes().push_back(std::make_shared<UIDocumentType>());
}

void BlockExe::OnBindingTrigger(StringHash event, VariantMap& data)
{
    String action = data[BindingTriggered::P_ACTION].GetString();
    String grp = data[BindingTriggered::P_GROUP].GetString();
    if (action == ACTION_SAVE)
    {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
            doc->Save();
    }
    else if (action == ACTION_SAVE_AS)
    {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
            doc->SaveAs();
    }
    else if (action == ACTION_OPEN)
    {
        DocumentManager::Get()->DoOpenDocument();
    }
    else if (action == ACTION_CLOSE)
    {
        if (auto doc = DocumentManager::Get()->GetActiveDocument())
            DocumentManager::Get()->CloseDocument(doc);
    }
    else if (action == ACTION_HELP)
    {
        //TODO:
    }
    else
        CheckScriptAction(grp, action);
}