#include "DocType_Particle.h"

#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/Graphics/GraphicsDefs.h>
#include <Urho3D/Graphics/Material.h>
#include <Urho3D/Graphics/Model.h>
#include <Urho3D/Graphics/ParticleEffect.h>
#include <Urho3D/Graphics/ParticleEmitter.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Audio/SoundListener.h>
#include <Urho3D/Graphics/StaticModel.h>
#include <Urho3D/Scene/ValueAnimation.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/imgui_ext.h>
#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include "Block.h"
#include "DataObject.h"
#include "DocType_CommonActions.h"
#include "GUI_Pane3D.h"
#include "Urho_Util.h"
#include "UX.h"

#include <fstream>

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

extern void SetupTestScene(Urho3D::SharedPtr<Urho3D::Scene> scene, Urho3D::SharedPtr<Urho3D::Node> camNode);

ParticleDocumentType::ParticleDocumentType() : DocumentType("Particle Effect", "Particle Effect (*.xml)|*.xml")
{

}

std::shared_ptr<DocumentBase> ParticleDocumentType::NewDocument()
{
    return std::make_shared<ParticleDocument>(BlockExe::GetInst()->GetContext());
}

std::shared_ptr<DocumentBase> ParticleDocumentType::OpenPath(const Urho3D::String& path)
{
    return std::make_shared<ParticleDocument>(BlockExe::GetInst()->GetContext(), path);
}

class GUI_ParticleView : public GUI_View3D
{
public:
    ParticleDocument* doc_;

    GUI_ParticleView(Document3D::View* v) :
        GUI_View3D(v)
    {
        doc_ = dynamic_cast<ParticleDocument*>(v->doc_);
    }

    ~GUI_ParticleView()
    {
        doc_ = 0x0;
    }

    GUI_PaneView* Clone()
    {
        auto camClone = view_->cameraNode_->Clone();
        camClone->SetTemporary(true);
        auto v = new Document3D::View(view_->doc_, SharedPtr<Node>(camClone));
        return new GUI_ParticleView(v);
    }

    virtual void Draw(const Urho3D::IntRect& r) override {
        ImGui::PushID(doc_);

        auto winPos = ImGui::GetWindowPos();
        auto winSize = ImGui::GetWindowSize();
        const bool isActive = IsActive();

        GUI_View3D::Draw(r);

        auto boldFont = ImGui::GetIO().Fonts->Fonts[3];
        ImGui::PushFont(boldFont);

        ImGui::SetCursorPos(ImVec2(20, 20));
        ImGui::BeginGroup();
        if (ImGui::Button(ICON_FA_PLAY))
        {
            doc_->scene_->SetUpdateEnabled(true);
            doc_->emitter_->SetEmitting(true);
        }
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_PAUSE))
        {
            doc_->scene_->SetUpdateEnabled(false);
        }
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_SYNC_ALT))
        {
            doc_->emitter_->Reset();
        }
        ImGui::SameLine();
        if (doc_->scene_->IsUpdateEnabled())
            ImGui::Text(" Playing");
        else
            ImGui::Text(" Paused");
        
        if (ImGui::Checkbox("Draw Substrate", &doc_->showSubstrate_))
        {
            if (auto substrate = doc_->GetScene()->GetChild("Substrate"))
                substrate->SetEnabledRecursive(doc_->showSubstrate_);
        }

        ImGui::Text("Emission: %.3f", doc_->emitter_->GetEmissionTimer());
        ImGui::Text("Period: %.3f", doc_->emitter_->GetPeriodTimer());
        int ct = 0;
        for (auto& bb : doc_->emitter_->GetBillboards())
            if (bb.enabled_) ++ct;
        ImGui::Text("Particles: %u", ct);
        ImGui::EndGroup();

        ImGui::PopFont();

        ImGui::PopID();
    }
};



void ParticleDocument::CommonConstruct()
{
    wantNodeIcons_ = false;
    scene_ = SharedPtr<Scene>(new Scene(GetContext()));
    auto cache = GetContext()->GetSubsystem<ResourceCache>();
    SharedPtr<Node> cameraNode = SharedPtr<Node>(scene_->CreateChild("##camera"));

    auto camera = cameraNode->CreateComponent<Camera>();
    cameraNode->CreateComponent<SoundListener>();
    camera->SetTemporary(true);
    cameraNode->SetPosition(Vector3(5, 3, 5));
    cameraNode->LookAt(Vector3(0, 0, 0));
    camRefRot_ = cameraNode->GetRotation();

    if (!LoadEditorScene(scene_.Get(), "ParticleEditor.xml"))
    {
        SetupTestScene(scene_, cameraNode);

        // Create a "substrate floor" consisting of several tiles
        // Useful for effects that require the depth buffer
        Node* substrate = scene_->CreateChild("Substrate");
        for (int y = -1; y <= 1; ++y)
        {
            for (int x = -1; x <= 1; ++x)
            {
                Node* floorNode = substrate->CreateChild("FloorTile");
                floorNode->SetPosition(Vector3(x * 20.5f, -0.5f, y * 20.5f));
                floorNode->SetScale(Vector3(20.0f, 1.0f, 20.f));
                auto* floorObject = floorNode->CreateComponent<StaticModel>();
                floorObject->SetModel(cache->GetResource<Model>("Models/Box.mdl"));
                floorObject->SetMaterial(cache->GetResource<Material>("Materials/Stone.xml"));
            }
        }
    }
    
    emitterNode_ = scene_->CreateChild("Emitter");
    emitterNode_->SetTemporary(true);
    emitterNode_->SetPosition(Vector3(0, 0, 0));

    guiViews_->topViews_.push_back(new GUI_ParticleView(new View(this, cameraNode)));
}

ParticleDocument::ParticleDocument(Context* ctx) :
    Document3D(ctx, SharedPtr<Scene>())
{
    CommonConstruct();
    auto cache = scene_->GetSubsystem<ResourceCache>();
    effect_ = cache->GetResource<ParticleEffect>("Data/Particle/Burst.xml")->Clone();

    emitter_ = emitterNode_->CreateComponent<ParticleEmitter>();
    emitter_->SetEffect(effect_);
}

ParticleDocument::ParticleDocument(Context* ctx, const Urho3D::String& path) :
    Document3D(ctx, 0x0)
{
    name_ = Urho3D::GetFileNameAndExtension(path).CString();
    filePath_ = path.CString();
    CommonConstruct();

    auto cache = scene_->GetSubsystem<ResourceCache>();
    effect_ = cache->GetResource<ParticleEffect>(path);
    
    emitter_ = emitterNode_->CreateComponent<ParticleEmitter>();
    emitter_->SetEffect(effect_);
}

ParticleDocument::~ParticleDocument()
{

}

bool ParticleDocument::Save()
{
    if (filePath_.empty())
    {
        auto fileName = GetSaveFile_PairName("Save Particle Effect", "*.xml", "Particle Effect (*.xml)|*.xml");

        if (!fileName.first.empty())
        {
            filePath_ = fileName.first;
            name_ = fileName.second;
        }
        else
            return false;
    }

    effect_->SaveFile(filePath_.c_str());
    ClearDirty();
    return true;
}

void ParticleDocument::SaveAs()
{
    auto oldFilePath = filePath_;
    filePath_.clear();
    if (Save())
    {

    }
    else
        filePath_ = oldFilePath; // if save fails then revert path
}

bool ParticleDocument::Close()
{
    Document3D::Close();
    return true;
}

void ParticleDocument::PreDraw()
{
    if (!scene_)
        return;
    UpdateNodeIcons();
    auto debugRen = scene_->GetOrCreateComponent<DebugRenderer>();
    //DrawGrid_3D(debugRen, Vector3(0, 0, 0));
    debugRen->AddLine(Vector3(0, 0.01f, 0), Vector3(5, 0.01f, 0), Color::RED);
    debugRen->AddLine(Vector3(0, 0.01f, 0), Vector3(0, 0.01f, 5), Color::BLUE);
    
    const float LineHalfWidth = 0.2f;

    // X Ticks
    debugRen->AddLine(Vector3(1, 0.01f, -LineHalfWidth), Vector3(1, 0.01f, LineHalfWidth), Color::WHITE);
    debugRen->AddLine(Vector3(2, 0.01f, -LineHalfWidth), Vector3(2, 0.01f, LineHalfWidth), Color::WHITE);
    debugRen->AddLine(Vector3(3, 0.01f, -LineHalfWidth), Vector3(3, 0.01f, LineHalfWidth), Color::WHITE);
    debugRen->AddLine(Vector3(4, 0.01f, -LineHalfWidth), Vector3(4, 0.01f, LineHalfWidth), Color::WHITE);
    debugRen->AddLine(Vector3(5, 0.01f, -LineHalfWidth), Vector3(5, 0.01f, LineHalfWidth), Color::WHITE);

    // Z Ticks
    debugRen->AddLine(Vector3(-LineHalfWidth, 0.01f, 1), Vector3(LineHalfWidth, 0.01f, 1), Color::WHITE);
    debugRen->AddLine(Vector3(-LineHalfWidth, 0.01f, 2), Vector3(LineHalfWidth, 0.01f, 2), Color::WHITE);
    debugRen->AddLine(Vector3(-LineHalfWidth, 0.01f, 3), Vector3(LineHalfWidth, 0.01f, 3), Color::WHITE);
    debugRen->AddLine(Vector3(-LineHalfWidth, 0.01f, 4), Vector3(LineHalfWidth, 0.01f, 4), Color::WHITE);
    debugRen->AddLine(Vector3(-LineHalfWidth, 0.01f, 5), Vector3(LineHalfWidth, 0.01f, 5), Color::WHITE);
}

void ParticleDocument::DrawProperties(ImGuiTextFilter* filter)
{
    bool changed = false;

    float w = ImGui::GetContentRegionAvailWidth();
    ImGui::PushItemWidth(w / 3);
    if (ImGui::Button(ICON_FA_PLAY))
    {
        scene_->SetUpdateEnabled(true);
        emitter_->SetEmitting(true);
    }
    ImGui::SameLine();
    if (ImGui::Button(ICON_FA_PAUSE))
    {
        scene_->SetUpdateEnabled(false);
    }
    ImGui::SameLine();
    if (ImGui::Button(ICON_FA_UNDO))
        emitter_->Reset();
    ImGui::PopItemWidth();

    auto constForce = effect_->GetConstantForce();
    ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());

    auto numParticles = effect_->GetNumParticles();
    ImGui::Text("Particle Count");
    if (changed |= ImGui::DragInt("##particlecount", (int*)&numParticles, 1.0f, 0, 32000))
        effect_->SetNumParticles(numParticles);

    int emitterFacing = effect_->GetFaceCameraMode();
    ImGui::Text("Face Camera Mode");
    if (changed |= ImGui::Combo("##facecammode", &emitterFacing, "None\0Rotate XYZ\0Rotate Y\0Look At XYZ\0Look At Y\0Look At Mixed\0Direction\0\0"))
        effect_->SetFaceCameraMode((FaceCameraMode)emitterFacing);

    auto emitRateMin = effect_->GetMinEmissionRate();
    auto emitRateMax = effect_->GetMaxEmissionRate();
    Vector2 emitRateVec(emitRateMin, emitRateMax);
    ImGui::Text("Emission Rate Range");
    if (changed |= ImGui::DragFloat2("##emitraterange", (float*)emitRateVec.Data(), 0.01f))
    {
        effect_->SetMinEmissionRate(emitRateVec.x_);
        effect_->SetMaxEmissionRate(emitRateVec.y_);
    }

    int emitterType = effect_->GetEmitterType();
    ImGui::Text("Emitter Shape");
    if (changed |= ImGui::Combo("##emittershape", &emitterType, "Sphere\0Box\0\0"))
        effect_->SetEmitterType((Urho3D::EmitterType)emitterType);

    bool relative = effect_->IsRelative();
    if (ImGui::Checkbox("Relative", &relative))
        effect_->SetRelative(relative);

    bool fixedSize = effect_->IsFixedScreenSize();
    if (ImGui::Checkbox("Fixed Size", &fixedSize))
        effect_->SetFixedScreenSize(fixedSize);

    if (ImGui::CollapsingHeader("Sizing"))
    {
        IndentScope indent;
        auto emitterSize = effect_->GetEmitterSize();
        ImGui::Text("Emitter Size");
        if (changed |= ImGui::DragFloatN_Colored("##emittersize", (float*)emitterSize.Data(), 3, 0.01f))
            effect_->SetEmitterSize(emitterSize);

        auto sizeMin = effect_->GetMinParticleSize();
        ImGui::Text("Min Particle Size");
        if (changed |= ImGui::DragFloatN_Colored("##sizemin", (float*)sizeMin.Data(), 2, 0.01f))
            effect_->SetMinParticleSize(sizeMin);

        auto sizeMax = effect_->GetMaxParticleSize();
        ImGui::Text("Max Particle Size");
        if (changed |= ImGui::DragFloatN_Colored("##sizemax", (float*)sizeMax.Data(), 2, 0.01f))
            effect_->SetMaxParticleSize(sizeMax);

        auto sizeAdd = effect_->GetSizeAdd();
        ImGui::Text("Size Add");
        if (changed |= ImGui::DragFloat("##sizeadd", &sizeAdd, 0.01f))
            effect_->SetSizeAdd(sizeAdd);

        auto sizeMul = effect_->GetSizeMul();
        ImGui::Text("Size Mul");
        if (changed |= ImGui::DragFloat("##sizemul", &sizeMul, 0.01f, 0.1f, 2.0f))
            effect_->SetSizeMul(sizeMul);
    }

    if (ImGui::CollapsingHeader("Forces"))
    {
        IndentScope indent;
        ImGui::Text("Constant Force");
        if (changed |= ImGui::DragFloatN_Colored("##conforce", (float*)constForce.Data(), 3, 0.01f))
            effect_->SetConstantForce(constForce);

        auto minDir = effect_->GetMinDirection();
        ImGui::Text("Min Direction");
        if (changed |= ImGui::DragFloatN_Colored("##mindir", (float*)minDir.Data(), 3, 0.01f))
            effect_->SetMinDirection(minDir);

        auto maxDir = effect_->GetMaxDirection();
        ImGui::Text("Max Direction");
        if (changed |= ImGui::DragFloatN_Colored("##maxdir", (float*)maxDir.Data(), 3, 0.01f))
            effect_->SetMaxDirection(maxDir);

        auto dampingForce = effect_->GetDampingForce();
        ImGui::Text("Damping Force");
        if (changed |= ImGui::DragFloat("##dampforce", &dampingForce, 0.01f))
            effect_->SetDampingForce(dampingForce);
    }

    if (ImGui::CollapsingHeader("Timing"))
    {
        IndentScope indent;
        auto activeTime = effect_->GetActiveTime();
        ImGui::Text("Active Time");
        if (changed |= ImGui::DragFloat("##activetime", &activeTime, 0.01f))
            effect_->SetActiveTime(activeTime);

        auto inactiveTime = effect_->GetInactiveTime();
        ImGui::Text("Inactive Time");
        if (changed |= ImGui::DragFloat("##inactivetime", &inactiveTime, 0.01f))
            effect_->SetInactiveTime(inactiveTime);

        auto ttlMin = effect_->GetMinTimeToLive();
        auto ttlMax = effect_->GetMaxTimeToLive();

        ImGui::Text("Min Time to Live");
        if (changed |= ImGui::DragFloat("##minttl", &ttlMin, 0.01f))
            effect_->SetMinTimeToLive(ttlMin);

        ImGui::Text("Max Time to Live");
        if (changed |= ImGui::DragFloat("##maxttl", &ttlMax, 0.01f))
            effect_->SetMaxTimeToLive(ttlMax);
    }
    
    if (ImGui::CollapsingHeader("Velocity and Rotation"))
    {
        IndentScope indent;
        auto velMin = effect_->GetMinVelocity();
        auto velMax = effect_->GetMaxVelocity();
        Vector2 velVec(velMin, velMax);
        ImGui::Text("Velocity Range");
        if (changed |= ImGui::DragFloat2("##minvel", (float*)velVec.Data(), 0.01f))
        {
            effect_->SetMinVelocity(velVec.x_);
            effect_->SetMaxVelocity(velVec.y_);
        }

        auto rotMin = effect_->GetMinRotation();
        auto rotMax = effect_->GetMaxRotation();
        Vector2 rotVec(rotMin, rotMax);

        ImGui::Text("Rotation Range");
        if (changed |= ImGui::DragFloat2("##rotrange", (float*)rotVec.Data(), 0.01f))
        {
            effect_->SetMinRotation(rotVec.x_);
            effect_->SetMaxRotation(rotVec.y_);
        }

        auto rotMinSpeed = effect_->GetMinRotationSpeed();
        auto rotMaxSpeed = effect_->GetMaxRotationSpeed();
        Vector2 rotSpeedVec(rotMinSpeed, rotMaxSpeed);

        ImGui::Text("Rotation Speed Range");
        if (changed |= ImGui::DragFloat2("##rotspdrange", (float*)rotSpeedVec.Data(), 0.01f))
        {
            effect_->SetMinRotationSpeed(rotSpeedVec.x_);
            effect_->SetMaxRotationSpeed(rotSpeedVec.y_);
        }
    }

    if (ImGui::CollapsingHeader("Color Key Frames"))
    {
        ImGui::PushID("COLOR_KEYS");
        IndentScope indent;
        auto colorFrames = effect_->GetColorFrames();

        float w = ImGui::GetContentRegionAvailWidth() / 2 - 30;

        ImGui::PushItemWidth(w);
        for (size_t i = 0; i < colorFrames.Size(); ++i)
        {
            ImGui::PushID(i + 1);

            float t = colorFrames[i].time_;
            auto col = colorFrames[i].color_;
            bool frameChanged = ImGui::InputFloat("##time", &t, 0.01f, 0.1f, 3);
            ImGui::SameLine();
            frameChanged |= ImGui::ColorEdit4("##color", &col.r_, ImGuiColorEditFlags_AlphaBar);
            ImGui::SameLine();
            if (frameChanged)
            {
                changed = true;
                effect_->SetColorFrame(i, ColorFrame(col, t));
                effect_->SortColorFrames();
            }
            if (ImGui::Button(ICON_FA_MINUS))
            {
                effect_->RemoveColorFrame(i);
                changed = true;
                --i;
            }

            ImGui::PopID();
        }
        if (ImGui::Button(ICON_FA_PLUS " Add Color Frame"))
        {
            if (effect_->GetNumColorFrames())
                effect_->AddColorFrame(ColorFrame(Color::WHITE, effect_->GetColorFrames().Back().time_ + 0.1f));
            else
                effect_->AddColorFrame(ColorFrame(Color::WHITE, 0.0f));
            changed = true;
        }
        ImGui::PopItemWidth();

        ImGui::PopID();
    }

    if (ImGui::CollapsingHeader("Texture Key Frames"))
    {
        ImGui::PushID("TEXTURE_KEYS");
        IndentScope indent;

        float w = ImGui::GetContentRegionAvailWidth() / 2 - 30;

        auto textureKeys = effect_->GetTextureFrames();

        ImGui::PushItemWidth(w);
        for (size_t i = 0; i < textureKeys.Size(); ++i)
        {
            ImGui::PushID(i + 1);

            float t = textureKeys[i].time_;
            auto rect = textureKeys[i].uv_;
            bool frameChanged = ImGui::InputFloat("##time", &t, 0.01f, 0.1f, 3);
            ImGui::SameLine();
            frameChanged |= ImGui::DragFloat4("##rect", &rect.min_.x_, 0.01f, 0.0f, 1.0f);
            ImGui::SameLine();
            if (frameChanged)
            {
                changed = true;
                TextureFrame tf;
                tf.time_ = t;
                tf.uv_ = rect;
                effect_->SetTextureFrame(i, tf);
                effect_->SortTextureFrames();
            }
            if (ImGui::Button(ICON_FA_MINUS))
            {
                effect_->RemoveTextureFrame(i);
                changed = true;
                --i;
            }

            ImGui::PopID();
        }
        if (ImGui::Button(ICON_FA_PLUS " Add Texture Frame"))
        {
            TextureFrame tf;
            tf.uv_ = Urho3D::Rect(0, 0, 1, 1);
            if (effect_->GetNumTextureFrames())
                tf.time_ = effect_->GetTextureFrames().Back().time_ + 0.1f;
            else
                tf.time_ = 0.0f;
            effect_->AddTextureFrame(tf);
            changed = true;
        }
        ImGui::PopItemWidth();

        ImGui::PopID();
    }

    if (changed)
    {
        emitter_->ApplyEffect();
        MarkDirty();
    }
    
    ImGui::PopItemWidth();
}

void ParticleDocument::DrawMasterButtons()
{
    ImGuiUX::MenuButton(ICON_FA_EDIT, "#particle_edit", "Edit");
    ImGuiUX::MenuButton(ICON_FA_SLIDERS_H, "#particle_tasks", "Tasks");
    DrawViewManagementWidgets();

    if (ImGui::BeginPopup("#particle_edit", ImGuiWindowFlags_ChildMenu))
    {
        ImGuiUX::StandardPopupChecks();

        StandardActions::ClearSelection->DrawMenuItem();
        ImGuiUX::AutoSeparator();
        StandardActions::CutScene->DrawMenuItem();
        StandardActions::CopyScene->DrawMenuItem();
        StandardActions::PasteScene->DrawMenuItem();
        ImGuiUX::AutoSeparator();
        StandardActions::ResetToDefault->DrawMenuItem();
        StandardActions::ResetPosition->DrawMenuItem();
        StandardActions::ResetRotation->DrawMenuItem();
        StandardActions::ResetScale->DrawMenuItem();
        ImGuiUX::AutoSeparator();
        StandardActions::DeleteScene->DrawMenuItem();
        ImGuiUX::EndAutoMenu();
        ImGui::EndPopup();
    }

    if (ImGui::BeginPopup("#particle_tasks", ImGuiWindowFlags_ChildMenu))
    {
        if (ImGui::MenuItem(ICON_FA_DOWNLOAD " Export Points"))
        {
            ModalWindows::Get()->PushModal(ModalWindow(ICON_FA_DOWNLOAD " Export Points", [=]() -> bool {

                ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth());

                ImGui::TextWrapped("Outputs current particle data into a point list XML file.");
                extern std::unique_ptr<DataObject> particlePointExportSettings_;

                DataObject::DrawEditor(particlePointExportSettings_.get());

                ImGui::PopItemWidth();

                ImGui::Separator();
                if (ImGui::Button("Save"))
                {
                    const bool exportDir = particlePointExportSettings_->GetField("Export Direction").GetBool();
                    const bool exportSize = particlePointExportSettings_->GetField("Export Size").GetBool();
                    const bool exportRot = particlePointExportSettings_->GetField("Export Rotation").GetBool();

                    auto filePath = GetSaveFile("Save Particle Points", "*.txt", "Point List (*.txt)|*.txt");
                    if (!filePath.empty())
                    {
                        auto file = SharedPtr<XMLFile>(new XMLFile(scene_->GetContext()));
                        auto root = file->CreateRoot("pointlist");

                        auto billboards = emitter_->GetBillboards();
                        for (auto bb : billboards)
                        {
                            if (!bb.enabled_)
                                continue;
                            auto child = root.CreateChild("point");
                            child.SetVector3("pos", bb.position_);
                            if (exportDir)
                                child.SetVector3("dir", bb.direction_);
                            if (exportSize)
                                child.SetVector2("size", bb.size_);
                            if (exportRot)
                                child.SetFloat("rotation", bb.rotation_);
                        }
                        file->SaveFile(filePath.c_str());
                    }
                    return false;
                }
                return true;
            }));

            
        }

        if (ImGui::MenuItem(ICON_FA_SYNC " Reset Camera Position"))
        {
            if (auto camNode = scene_->GetChild("##camera"))
            {
                const float CAM_ANIM_TIME = 0.3f;

                auto valAnim = new Urho3D::ValueAnimation(GetContext());
                valAnim->SetKeyFrame(0.0f, camNode->GetPosition());
                valAnim->SetKeyFrame(CAM_ANIM_TIME, Vector3(5, 3, 5));
                camNode->SetAttributeAnimation("Position", valAnim, Urho3D::WM_ONCE);

                valAnim = new Urho3D::ValueAnimation(GetContext());
                valAnim->SetKeyFrame(0.0f, camNode->GetRotation());
                valAnim->SetKeyFrame(CAM_ANIM_TIME, camRefRot_);
                camNode->SetAttributeAnimation("Rotation", valAnim, Urho3D::WM_ONCE);
            }
        }

        ImGui::EndPopup();
    }
}
