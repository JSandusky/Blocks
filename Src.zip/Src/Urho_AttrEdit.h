#pragma once

#include <Urho3D/Container/Ptr.h>
#include <Urho3D/Math/StringHash.h>

#include "Doc_DocumentManager.h"

#include <vector>

namespace Urho3D
{
    class AttributeInfo;
    class Node;
    class Scene;
    class Serializable;
}

void ShowSerializableEditor(Urho3D::Serializable* target, UndoStack* undoStack, struct ImGuiTextFilter* filter);
/// This utility function is not recommended to be called often. Use for one-off cases.
void EditAttribute(Urho3D::Scene* scene, Urho3D::Serializable* target, const Urho3D::StringHash& attrName, UndoStack* undoStack, bool noLabel = false);

void EditAttribute(Urho3D::Scene* scene, Urho3D::Serializable* target, const Urho3D::AttributeInfo* attr, unsigned attrIndex, UndoStack* undoStack, bool noLabel = false);