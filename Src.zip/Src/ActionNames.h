#pragma once

#define ACTION_SAVE "Save"
#define ACTION_SAVE_AS "Save As..."
#define ACTION_OPEN "Open"
#define ACTION_CLOSE "Close"
#define ACTION_HELP "Help"
