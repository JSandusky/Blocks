#include "BitNames.h"

#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Resource/XMLElement.h>
#include <Urho3D/Resource/XMLFile.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>

#include "Block.h"
#include "UX.h"

// False reports
#include <Urho3D/DebugNew.h>

using namespace Urho3D;

BitNamesTable::BitNamesTable()
{
    auto fs = BlockExe::GetInst()->GetSubsystem<FileSystem>();
    auto dir = fs->GetAppPreferencesDir("urho3d", "Blocks");

    XMLFile file(BlockExe::GetInst()->GetContext());
    if (file.LoadFile(Urho3D::AddTrailingSlash(dir) + "BitNames.xml"))
    {
        auto cur = file.GetRoot().GetChild("set");
        while (cur.NotNull())
        {
            BitNames* n = new BitNames;
            n->setName_ = cur.GetAttribute("name").CString();
            names_[n->setName_] = n;
            auto flagElem = cur.GetChild("flag");
            size_t i = 0;
            while (flagElem.NotNull() && i < 32)
            {
                n->bits_[i] = flagElem.GetValue().CString();
                flagElem = flagElem.GetNext("flag");
                ++i;
            }
            cur = cur.GetNext("set");
        }
    }
    else
    {
        //init new
        static std::vector<std::string> nameList = {
            "View Mask",
            "Light Mask",
            "Shadow Mask",
            "Zone Mask",
            "View Override Flags",
            "Mask Bits",
            "Flags Mask",
            "Collision Mask",
            "Collision Layer"
        };
        for (auto n : nameList)
            GetBitNames(n);
    }
}

BitNamesTable::~BitNamesTable()
{
    for (auto kvp : names_)
        delete kvp.second;
}

void BitNamesTable::Save()
{
    auto fs = BlockExe::GetInst()->GetSubsystem<FileSystem>();
    auto dir = fs->GetAppPreferencesDir("urho3d", "Blocks");
    XMLFile file(BlockExe::GetInst()->GetContext());

    auto root = file.CreateRoot("bitnames");
    for (auto kvp : names_)
    {
        auto nameSet = root.CreateChild("set");
        nameSet.SetAttribute("name", kvp.first.c_str());
        for (size_t i = 0; i < 32; ++i)
        {
            auto bitElem = nameSet.CreateChild("flag");
            bitElem.SetValue(kvp.second->bits_[i].c_str());
        }
    }

    file.SaveFile(Urho3D::AddTrailingSlash(dir) + "BitNames.xml");
}

BitNames* BitNamesTable::GetBitNames(const std::string& name)
{
    auto found = names_.find(name);
    if (found != names_.end())
        return found->second;

    auto newSet = new BitNames;
    newSet->setName_ = name;
    for (size_t i = 0; i < 32; ++i)
        newSet->bits_[i] = "Bit " + std::to_string(i + 1);
    names_[name] = newSet;
}

void BitNamesTable::DrawEditor()
{
    static int selectedBit = 0;
    ImGui::BeginChild("items_list", ImVec2(300, 400));
    int i = 0;
    for (auto kvp : names_)
    {
        bool sel = i == selectedBit;
        bool wasSel = sel;
        if (sel)
            ImGuiUX::PushBold();
        ImGui::Selectable(kvp.first.c_str(), &sel);
        if (sel)
            selectedBit = i;
        if (wasSel)
            ImGui::PopFont();
        ++i;
    }
    ImGui::EndChild();
    ImGui::SameLine();
    ImGui::BeginChild(selectedBit, ImVec2(400, 400));
    i = 0;
    for (auto kvp : names_)
    {
        if (i == selectedBit)
        {
            ImGui::Indent();
            ImGuiUX::PushLargeBold();
            ImGui::Text(kvp.first.c_str());
            ImGui::PopFont();
            for (size_t i = 0; i < 32; ++i)
            {
                ImGui::Text(("Bit " + std::to_string(i + 1)).c_str());
                Urho3D::String str = kvp.second->bits_[i].c_str();
                Urho3D::String name = ("##bit_" + Urho3D::String(i));
                if (ImGuiElement::EditString(name, str))
                    kvp.second->bits_[i] = str.CString();
            }
            ImGui::Unindent();
        }
        ++i;
    }
    ImGui::EndChild();
    //for (auto kvp : names_)
    //{
    //    if (ImGui::CollapsingHeader(kvp.first.c_str()))
    //    {
    //        ImGui::Indent();
    //        for (size_t i = 0; i < 32; ++i)
    //        {
    //            ImGui::Text(("Bit " + std::to_string(i + 1)).c_str());
    //            Urho3D::String str = kvp.second->bits_[i].c_str();
    //            Urho3D::String name = ("##bit_" + Urho3D::String(i));
    //            if (ImGuiElement::EditString(name, str))
    //                kvp.second->bits_[i] = str.CString();
    //        }
    //        ImGui::Unindent();
    //    }
    //}
}