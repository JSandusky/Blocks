#include "CubeCapture.h"

#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Core/Context.h>
#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/IO/File.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/Graphics/Graphics.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Scene/Node.h>
#include <Urho3D/Graphics/RenderSurface.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Scene/Scene.h>
#include <Urho3D/Graphics/Texture2D.h>
#include <Urho3D/Graphics/Viewport.h>
#include <Urho3D/Resource/XMLElement.h>
#include <Urho3D/Resource/XMLFile.h>
#include <Urho3D/Graphics/Zone.h>

#include <Urho3D/Container/Ptr.h>
#include <Urho3D/Container/VectorBase.h>
#include <Urho3D/Container/Vector.h>

#include "Urho_Util.h"

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

static Vector<SharedPtr<CubeCapture> > activeCubeCapture_;

CapturingData::~CapturingData()
{

}

void CapturingData::PrepareZonesForCubeRendering(Urho3D::SharedPtr<Scene> scene)
{
    scene_ = scene;

    // Only clone zones when we aren't actively processing
    if (cloneZones_.Size() > 0)
        return;

    PODVector<Zone*> zones;
    scene_->GetComponents<Zone>(zones, true);
    for (unsigned i = 0; i < zones.Size(); ++i)
    {
        Zone* srcZone = zones[i];
        if (zones[i]->IsEnabledEffective())
        {
            Zone* cloneZone = srcZone->GetNode()->CreateComponent<Zone>();
            cloneZone->SetZoneMask(srcZone->GetZoneMask());
            cloneZone->SetPriority(srcZone->GetPriority());
            cloneZone->SetBoundingBox(srcZone->GetBoundingBox());

            cloneZone->SetAmbientColor(srcZone->GetAmbientColor());
            cloneZone->SetAmbientGradient(srcZone->GetAmbientGradient());

            cloneZone->SetFogColor(srcZone->GetFogColor());
            cloneZone->SetFogStart(srcZone->GetFogStart());
            cloneZone->SetFogEnd(srcZone->GetFogEnd());
            cloneZone->SetFogHeight(srcZone->GetFogHeight());
            cloneZone->SetFogHeightScale(srcZone->GetFogHeightScale());
            cloneZone->SetHeightFog(srcZone->GetHeightFog());

            srcZone->SetEnabled(false);

            // Add the zones to our temporary lists
            cloneZones_.Push(SharedPtr<Zone>(cloneZone));
            disabledZones_.Push(SharedPtr<Zone>(srcZone));
        }
    }
    scene_->GetOrCreateComponent<DebugRenderer>()->SetEnabled(false);
}

void CapturingData::UnprepareZonesForCubeRendering()
{
    // Clean up the clones
    for (unsigned i = 0; i < cloneZones_.Size(); ++i)
        cloneZones_[i]->Remove();
    cloneZones_.Clear();

    // Reenable anyone we disabled
    for (unsigned i = 0; i < disabledZones_.Size(); ++i)
        disabledZones_[i]->SetEnabled(true);
    disabledZones_.Clear();

    scene_->GetOrCreateComponent<DebugRenderer>()->SetEnabled(true);
}

CubeCapture::CubeCapture(CapturingData* data, Urho3D::Zone* zone, const Urho3D::String& baseName, const Urho3D::String& targetName, int targetID, unsigned cubeSize) :
    Urho3D::Object(zone->GetContext()),
    captureData_(data),
    baseName_(baseName),
    targetName_(targetName),
    targetID_(targetID),
    cubeSize_(cubeSize),
    updateCycle_(0)
{
    Zone* forZone = zone;
    Scene* scene = forZone->GetScene();

    cameraNode_ = scene->CreateChild("RenderCamera");
    Camera* camera = cameraNode_->GetOrCreateComponent<Camera>();
    camera->SetFov(90.0f);
    camera->SetNearClip(0.0001f);
    camera->SetAspectRatio(1.0f);
    cameraNode_->SetWorldPosition(forZone->GetNode()->GetWorldPosition());

    viewport_ = new Urho3D::Viewport(GetContext(), scene, camera);
    //viewport_->SetRenderPath(renderer->viewports[0].renderPath;
}

CubeCapture::~CubeCapture()
{

}

void CubeCapture::Start()
{
    // Construct render surface 
    targetTexture_ = new Texture2D(GetContext());
    targetTexture_->SetSize(cubeSize_, cubeSize_, Graphics::GetRGBAFormat(), TEXTURE_RENDERTARGET);

    surface_ = targetTexture_->GetRenderSurface();
    surface_->SetNumViewports(1);
    surface_->SetViewport(0, viewport_);
    surface_->SetUpdateMode(SURFACE_UPDATEALWAYS);

    SubscribeToEvent(StringHash("BeginFrame"), URHO3D_HANDLER(CubeCapture, HandlePreRender));
    SubscribeToEvent(StringHash("EndFrame"), URHO3D_HANDLER(CubeCapture, HandlePostRender));
}

void CubeCapture::Stop()
{
    cameraNode_->Remove();
    cameraNode_.Reset();
    viewport_.Reset();
    surface_.Reset();

    UnsubscribeFromEvent("BeginFrame");
    UnsubscribeFromEvent("EndFrame");

    WriteXML("Data/Textures/Cubemaps", baseName_, targetName_, targetID_);

    // Remove ourselves from the processing list and if necessary clean things up
    // If others are pending in the queue then start the next one
    auto self = SharedPtr<CubeCapture>(this);
    captureData_->activeCapture_.Erase(captureData_->activeCapture_.Find(self));
    if (captureData_->activeCapture_.Size() == 0)
        captureData_->UnprepareZonesForCubeRendering();
    else
        captureData_->activeCapture_[0]->Start();
}

void CubeCapture::HandlePreRender(Urho3D::StringHash eventType, Urho3D::VariantMap& eventData)
{
    if (cameraNode_)
    {
        ++updateCycle_;

        if (updateCycle_ < 7)
            cameraNode_->SetWorldRotation(RotationOf(GetFaceForCycle(updateCycle_)));
        else
            Stop();
    }
}

void CubeCapture::HandlePostRender(Urho3D::StringHash eventType, Urho3D::VariantMap& eventData)
{
    auto fileSystem = GetSubsystem<FileSystem>();

    SharedPtr<Image> img = targetTexture_->GetImage();
    String path = "Data/Textures/Cubemaps";
    fileSystem->CreateDir(path);

    String imgPath = GetName("Data/Textures/Cubemaps", baseName_, targetName_, targetID_);
    path = imgPath + "_" + GetFaceName(GetFaceForCycle(updateCycle_)) + ".tga";
    img->SaveTGA(path);
}

Urho3D::CubeMapFace CubeCapture::GetFaceForCycle(int cycle) const
{
    switch (updateCycle_)
    {
    case 1:
        return FACE_POSITIVE_X;
    case 2:
        return FACE_POSITIVE_Y;
    case 3:
        return FACE_POSITIVE_Z;
    case 4:
        return FACE_NEGATIVE_X;
    case 5:
        return FACE_NEGATIVE_Y;
    case 6:
        return FACE_NEGATIVE_Z;
    }
    return FACE_POSITIVE_X;
}

Urho3D::String CubeCapture::GetFaceName(Urho3D::CubeMapFace face) const
{
    switch (face)
    {
    case FACE_POSITIVE_X:
        return "PosX";
    case FACE_POSITIVE_Y:
        return "PosY";
    case FACE_POSITIVE_Z:
        return "PosZ";
    case FACE_NEGATIVE_X:
        return "NegX";
    case FACE_NEGATIVE_Y:
        return "NegY";
    case FACE_NEGATIVE_Z:
        return "NegZ";
    }
    return "PosX";
}

Urho3D::Quaternion CubeCapture::RotationOf(Urho3D::CubeMapFace face) const
{
    Quaternion result;
    switch (face)
    {
        //  Rotate camera according to probe rotation
    case FACE_POSITIVE_X:
        result = Quaternion(0, 90, 0);
        break;
    case FACE_NEGATIVE_X:
        result = Quaternion(0, -90, 0);
        break;
    case FACE_POSITIVE_Y:
        result = Quaternion(-90, 0, 0);
        break;
    case FACE_NEGATIVE_Y:
        result = Quaternion(90, 0, 0);
        break;
    case FACE_POSITIVE_Z:
        result = Quaternion(0, 0, 0);
        break;
    case FACE_NEGATIVE_Z:
        result = Quaternion(0, 180, 0);
        break;
    }
    return result;
}

Urho3D::String CubeCapture::GetName(const Urho3D::String& path, const Urho3D::String& sourceSceneName, const Urho3D::String& targetName, int targetID) const
{
    String sceneName = sourceSceneName.Length() > 0 ? "/" + sourceSceneName + "/" : "";
    String basePath = Urho3D::AddTrailingSlash(path + sceneName);
    String cubeName = targetName.Length() > 0 ? (targetName + "_") : "";
    String xmlPath = basePath + cubeName + String(targetID);
    return xmlPath;
}

ResourceRef CubeCapture::WriteXML(const Urho3D::String& path, const Urho3D::String& sourceSceneName, const Urho3D::String& targetName, int targetID) const
{
    auto cache = GetContext()->GetSubsystem<ResourceCache>();

    auto commonPath = GetName(path, sourceSceneName, targetName, targetID);
    SharedPtr<XMLFile> file(new XMLFile(GetContext()));
    XMLElement rootElem = file->CreateRoot("cubemap");

    for (int i = 0; i < 6; ++i)
    {
        XMLElement faceElem = rootElem.CreateChild("face");
        String facePath = commonPath + "_" + GetFaceName(CubeMapFace(i)) + ".tga";
        faceElem.SetAttribute("name", facePath);
    }

    auto cubeXMLPath = commonPath + ".xml";
    file->SaveFile(cubeXMLPath);

    return ResourceRef(StringHash("TextureCube"), GetResourceNameFromFullName(cubeXMLPath));
}
