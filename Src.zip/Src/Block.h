//
// Copyright (c) 2008-2018 the Urho3D project.
//
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
//
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.
//

#pragma once

#include <Urho3D/Engine/Application.h>
#include <Urho3D/Scene/Scene.h>

using namespace Urho3D;

namespace Urho3D
{
    class ImGuiElement;
}

class GUI_MainHub;
class GUI_ViewManager;
struct DocumentManager;
class BitNamesTable;

/// Urho3DPlayer application runs a script specified on the command line.
class BlockExe : public Application
{
    URHO3D_OBJECT(BlockExe, Application);

public:
    /// Construct.
    explicit BlockExe(Context* context);
    ~BlockExe();

    /// Setup before engine initialization. Verify that a script file has been specified.
    void Setup() override;
    /// Setup after engine initialization. Load the script and execute its start function.
    void Start() override;
    /// Cleanup after the main loop. Run the script's stop function if it exists.
    void Stop() override;

    Urho3D::SharedPtr<ImGuiElement>& GetImGuiElem() { return imguiElem_; }
    GUI_MainHub* GetHub() { return hub_; }
    Urho3D::SharedPtr<Scene> GetMasterScene() { return masterScene_; }

    BitNamesTable* GetBitNames() const { return bitNames_; }

    static BlockExe* GetInst() { return inst_; }
private:
    void RenderImGui(StringHash event, VariantMap& data);
    void MouseUp(StringHash event, VariantMap& data);
    void MouseMove(StringHash event, VariantMap& data);
    void HandleExit(StringHash event, VariantMap& data);
    void FocusLost(StringHash event, VariantMap& data);
    void MainScriptReloaded(StringHash event, VariantMap& data);
    void OnBindingTrigger(StringHash event, VariantMap& data);
    
    void InitializeDataObjects();
    void SaveDataObjects();
    void LoadDataObjects();
    void InitializeBindings();
    void LoadBindings();
    void SaveBindings();

    void SetupDocumentTypes();

    /// Flag whether CommandLine.txt was already successfully read.
    bool commandLineRead_;
    Urho3D::SharedPtr<Scene> masterScene_;
    Urho3D::SharedPtr<ImGuiElement> imguiElem_;
    GUI_MainHub* hub_;
    BitNamesTable* bitNames_;

    static BlockExe* inst_;
};
