#include "Doc_Document3D.h"

#include <Urho3D/Graphics/BillboardSet.h>
#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Graphics/Graphics.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Graphics/Light.h>
#include <Urho3D/Graphics/Material.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Physics/RigidBody.h>
#include <Urho3D/Scene/SplinePath.h>
#include <Urho3D/Graphics/Texture2D.h>

#include <Urho3D/ThirdParty/ImGui/ImGuizmo.h>

#include "DataObject.h"
#include "GUI_Main.h"
#include "GUI_Pane3D.h"
#include "Urho_Util.h"

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

extern ImGuiElement* GetImGuiElement();
#define VIEW_TEXID(ID) (5000 + ID)

int Document3D::View::nextViewID_ = 0;

Document3D::Document3D(Urho3D::Context* ctx, Urho3D::SharedPtr<Urho3D::Scene> scene) :
    DocumentBase(ctx)
{
    scene_ = scene;
}

Document3D::~Document3D()
{
}

bool Document3D::Close() 
{ 
    DocumentBase::Close(); 
    scene_.Reset(); 
    debugIconNode_.Reset(); 
    gizmo_.reset(); 
    debugIconBB_.Reset(); 
    return true; 
}

void Document3D::PreDraw()
{
    UpdateNodeIcons();
    auto debugRen = scene_->GetOrCreateComponent<DebugRenderer>();
    if (auto activeView = GetViewManager()->GetActiveView())
    {
        if (GUI_View3D* view3D = dynamic_cast<GUI_View3D*>(activeView))
        {
            auto worldPos = view3D->view_->cameraNode_->GetWorldPosition();
            DrawGrid_3D(debugRen, worldPos);
        }
    }
    else
        DrawGrid_3D(debugRen, Vector3(0, 0, 0));
}

void Document3D::UpdateNodeIcons()
{
    if (!wantNodeIcons_)
        return;

    extern std::unique_ptr<DataObject> viewportSettings_;
    if (!viewportSettings_->GetField("Draw Scene Icons").GetBool())
    {
        for (int iconType = 0; iconType < 12; ++iconType)
        {
            String path = "##debug_icon_" + String(iconType);
            if (Node* bbNode = scene_->GetChild(path))
                bbNode->SetEnabled(false);
        }
        return;
    }

    Node* cameraNode = nullptr;
    Vector3 camPos(0, 0, 0);
    if (auto activeView = dynamic_cast<GUI_View3D*>(GetViewManager()->GetActiveView()))
    {
        camPos = activeView->view_->cameraNode_->GetWorldPosition();
        cameraNode = activeView->view_->cameraNode_;
    }

    static int splinePathResolution = 16;
    static std::vector<Color> debugIconsColors = { Color(1,1,1) , Color(1,1,0), Color(0,1,0) };
    static std::vector<String> iconsTypesMaterials = {
        "DebugIconPointLight.xml",
        "DebugIconSpotLight.xml",
        "DebugIconLight.xml",
        "DebugIconCamera.xml",
        "DebugIconSoundSource.xml",
        "DebugIconSoundSource.xml",
        "DebugIconSoundListener.xml",
        "DebugIconZone.xml",
        "DebugIconSplinePathPoint.xml",
        "DebugIconCollisionTrigger.xml",
        "DebugIconCustomGeometry.xml",
        "DebugIconParticleEmitter.xml" };
    static std::vector<String>  componentTypes = { "Light",
        "Light",
        "Light",
        "Camera",
        "SoundSource",
        "SoundSource3D",
        "SoundListener",
        "Zone",
        "SplinePath",
        "RigidBody",
        "CustomGeometry",
        "ParticleEmitter" };

    enum IconsTypes
    {
        ICON_POINT_LIGHT = 0,
        ICON_SPOT_LIGHT,
        ICON_DIRECTIONAL_LIGHT,
        ICON_CAMERA,
        ICON_SOUND_SOURCE,
        ICON_SOUND_SOURCE_3D,
        ICON_SOUND_LISTENERS,
        ICON_ZONE,
        ICON_SPLINE_PATH,
        ICON_TRIGGER,
        ICON_CUSTOM_GEOMETRY,
        ICON_PARTICLE_EMITTER,
        ICON_COUNT
    };

    enum IconsColorType
    {
        ICON_COLOR_DEFAULT = 0,
        ICON_COLOR_SPLINE_PATH_BEGIN,
        ICON_COLOR_SPLINE_PATH_END
    };

    static Vector2 debugIconsSize = Vector2(1, 1);
    static Vector2 debugIconsSizeSmall = debugIconsSize / 1.5;
    static float debugIconAlphaThreshold = 0.1f;
    static float maxDistance = 100.0f;

    for (int iconType = 0; iconType < ICON_COUNT; ++iconType)
    {
        String path = "##debug_icon_" + String(iconType);
        Node* bbNode = scene_->GetChild(path);
        if (bbNode == nullptr)
        {
            bbNode = scene_->CreateChild(path);
            bbNode->SetTemporary(true);
            bbNode->CreateComponent<BillboardSet>()->SetMaterial(bbNode->GetSubsystem<ResourceCache>()->GetResource<Material>("Materials/Editor/" + iconsTypesMaterials[iconType]));
        }
        bbNode->SetEnabled(true);
        BillboardSet* bbSet = bbNode->GetOrCreateComponent<BillboardSet>();
        PODVector<Node*> nodes = scene_->GetChildrenWithComponent(componentTypes[iconType], true);
        if (nodes.Size() > 0)
        {
            bbSet->SetEnabled(true);
            bbSet->SetNumBillboards(nodes.Size());
            for (unsigned i = 0; i < nodes.Size(); ++i)
                bbSet->GetBillboard(i)->enabled_ = false;
            // Fill with new data
            for (unsigned i = 0; i < nodes.Size(); ++i)
            {
                if (nodes[i] == cameraNode)
                    continue;
                Component* component = nodes[i]->GetComponent(componentTypes[iconType]);
                if (component == nullptr)
                    continue;

                Color finalIconColor = debugIconsColors[0];
                float distance = (camPos - nodes[i]->GetWorldPosition()).Length();
                int iconsOffset = 0;
                float iconsYPos = 0;

                if (iconType == ICON_SPLINE_PATH)
                {
                    if (SplinePath* sp = dynamic_cast<SplinePath*>(component))
                    {
                        if (sp->GetLength() > 0.01f)
                        {
                            for (int step = 0; step < splinePathResolution; step++)
                            {
                                const float splineStep = 1.0f / splinePathResolution;

                                int index = (i * splinePathResolution) + step;
                                Vector3 splinePoint = sp->GetPoint(splineStep * step);
                                Billboard* bb = bbSet->GetBillboard(index);
                                float stepDistance = (camPos - splinePoint).Length();

                                if (step == 0) // SplinePath start
                                {
                                    bb->color_ = debugIconsColors[ICON_COLOR_SPLINE_PATH_BEGIN];
                                    bb->size_ = debugIconsSize;
                                    bb->position_ = splinePoint;
                                }
                                else if ((step + 1) >= (splinePathResolution - splineStep)) // SplinePath end
                                {
                                    bb->color_ = debugIconsColors[ICON_COLOR_SPLINE_PATH_END];
                                    bb->size_ = debugIconsSize;
                                    bb->position_ = splinePoint;
                                }
                                else // SplinePath middle points
                                {
                                    bb->color_ = finalIconColor;
                                    bb->size_ = debugIconsSizeSmall;
                                    bb->position_ = splinePoint;
                                }
                                bb->enabled_ = sp->IsEnabled();
                                // Blend Icon relatively by distance to it
                                bb->color_ = Color(bb->color_.r_, bb->color_.g_, bb->color_.b_, 1.2f - 1.0f / (maxDistance / stepDistance));
                                if (bb->color_.a_ < debugIconAlphaThreshold)
                                    bb->enabled_ = false;
                            }
                        }
                    }
                }
                else
                {
                    Billboard* bb = bbSet->GetBillboard(i);
                    bb->size_ = debugIconsSize;

                    if (iconType == ICON_TRIGGER)
                    {
                        if (auto rigidbody = dynamic_cast<RigidBody*>(component))
                        {
                            if (!rigidbody->IsTrigger())
                                continue;
                        }
                    }
                    else if (iconType == ICON_POINT_LIGHT || iconType == ICON_SPOT_LIGHT || iconType == ICON_DIRECTIONAL_LIGHT)
                    {
                        if (Light* light = dynamic_cast<Light*>(component))
                        {
                            bb = 0x0;
                            if (light->GetLightType() == LIGHT_POINT && iconType == ICON_POINT_LIGHT)
                                bb = bbSet->GetBillboard(i);
                            else if (light->GetLightType() == LIGHT_DIRECTIONAL && iconType == ICON_DIRECTIONAL_LIGHT)
                                bb = bbSet->GetBillboard(i);
                            else if (light->GetLightType() == LIGHT_SPOT && iconType == ICON_SPOT_LIGHT)
                                bb = bbSet->GetBillboard(i);

                            if (!bb)
                                continue;

                            bb->enabled_ = true;
                            finalIconColor = light->GetEffectiveColor();
                        }
                    }

                    bb->position_ = nodes[i]->GetWorldPosition();
                    bb->size_ = debugIconsSize;

                    // Blend Icon relatively by distance to it
                    bb->color_ = Color(finalIconColor.r_, finalIconColor.g_, finalIconColor.b_, 1.2f - 1.0f / (maxDistance / distance));
                    bb->enabled_ = component->IsEnabledEffective();
                    // Discard billboard if it almost transparent
                    if (bb->color_.a_ < debugIconAlphaThreshold)
                        bb->enabled_ = false;
                    //IncrementIconPlacement(bb->enabled_, nodes[i], 1);
                }
            }
        }
        else
        {
            bbSet->SetEnabled(false);
        }
        bbSet->Commit();
    }
}

Document3D::View::View(Document3D* doc, Urho3D::SharedPtr<Urho3D::Node> camNode)
{
    gizmoContext_ = ImGuizmo::CreateContext();
    doc_ = doc;
    viewID_ = ++nextViewID_;
    surface_ = new Texture2D(doc->scene_->GetContext());
    surface_->SetSize(512, 512, Graphics::GetRGBFormat(), TEXTURE_RENDERTARGET);
    surface_->SetFilterMode(FILTER_BILINEAR);

    cameraNode_ = camNode;

    auto rt = surface_->GetRenderSurface();
    viewport_ = new Viewport(doc->scene_->GetContext(), doc->scene_, cameraNode_->GetComponent<Camera>());
    rt->SetViewport(0, viewport_);
    rt->SetUpdateMode(SURFACE_UPDATEVISIBLE);

    GetImGuiElement()->AddTexture(VIEW_TEXID(viewID_), surface_);
}

Document3D::View::~View()
{
    ImGuizmo::DestroyContext(gizmoContext_);
    GetImGuiElement()->RemoveTexture(VIEW_TEXID(viewID_));
}

void Document3D::View::CheckSize(int w, int h)
{
    // don't resize to 0
    if (w <= 0 || h <= 0)
        return;

    // check if resizing is even needed
    if (w != surface_->GetWidth() || h != surface_->GetHeight())
    {
        surface_->SetSize(w, h, Graphics::GetRGBFormat(), TEXTURE_RENDERTARGET);
        auto rt = surface_->GetRenderSurface();
        rt->SetViewport(0, viewport_);
        rt->SetUpdateMode(Urho3D::SURFACE_UPDATEALWAYS);
    }
}

void Document3D::DrawViewManagementWidgets()
{
    ImGuiUX::MenuButton(ICON_FA_EYE, "#main_menu_viewports", "Viewports");
    //ImGui::SameLine();

    if (ImGui::BeginPopup("#main_menu_viewports"))
    {
        ImGuiUX::StandardPopupChecks();

        // there are several ways to actually do this layout.
        // The layout is based on strips, and the orientation is the layout direction of each strip.
        // So a 2-view split can be done: w/ setting vertical orientation and fill either just top or bottom views
        //      Add 1 viewport to both top and bottom then setting the orientation
        // Can do more esoteric views, like a 3x2
        const unsigned ctTop = GetViewManager()->topViews_.size();
        const unsigned ctBottom = GetViewManager()->bottomViews_.size();
        const unsigned totalCt = ctTop + ctBottom;
        const bool isVert = GetViewManager()->verticalOrientation_;

        std::vector<GUI_PaneView*> flatViews;
        for (auto v : GetViewManager()->topViews_)
            flatViews.push_back(v);
        for (auto v : GetViewManager()->bottomViews_)
            flatViews.push_back(v);

        if (ImGui::MenuItem("Single", 0x0, totalCt == 1))
        {
            for (size_t i = 1; i < flatViews.size(); ++i)
                delete flatViews[i];
            GetViewManager()->topViews_.clear();
            GetViewManager()->bottomViews_.clear();
            GetViewManager()->topViews_.push_back(flatViews[0]);
        }
        bool vertical2View = (ImGui::MenuItem("Dual SxS", 0x0, isVert && ctTop == 2 && ctBottom == 0));
        bool horiz2View = (ImGui::MenuItem("Dual Over", 0x0, !isVert && ctTop == 2 && ctBottom == 0));

        if (vertical2View || horiz2View)
        {
            for (size_t i = 2; i < flatViews.size(); ++i)
                delete flatViews[i];
            flatViews.resize(Min(2u, flatViews.size()));
            GetViewManager()->topViews_.clear();
            GetViewManager()->bottomViews_.clear();

            for (size_t i = 0; i < 2 && i < flatViews.size(); ++i)
                GetViewManager()->topViews_.push_back(flatViews[i]);
            while (GetViewManager()->topViews_.size() < 2)
                GetViewManager()->topViews_.push_back(flatViews.back()->Clone());
            GetViewManager()->verticalOrientation_ = vertical2View;
        }
        bool oneX2Top = ImGui::MenuItem("1x2 Top Wide", 0x0, ctTop == 1 && ctBottom == 2 && isVert);
        bool twoX1Bottom = ImGui::MenuItem("2x1 Bottom Wide", 0x0, ctTop == 2 && ctBottom == 1 && isVert);

        bool oneX2Tall = ImGui::MenuItem("1x2 Left Tall", 0x0, ctTop == 1 && ctBottom == 2 && !isVert);
        bool twoX1Tall = ImGui::MenuItem("2x1 Right Tall", 0x0, ctTop == 2 && ctBottom == 1 && !isVert);

        if (oneX2Top || twoX1Bottom || oneX2Tall || twoX1Tall)
        {
            for (size_t i = 3; i < flatViews.size(); ++i)
                delete flatViews[i];
            flatViews.resize(Min(3, flatViews.size()));
            GetViewManager()->topViews_.clear();
            GetViewManager()->bottomViews_.clear();

            std::vector<GUI_PaneView*>& doubleTarget = oneX2Top || oneX2Tall ? GetViewManager()->bottomViews_ : GetViewManager()->topViews_;
            std::vector<GUI_PaneView*>& singleTarget = twoX1Bottom || twoX1Tall ? GetViewManager()->bottomViews_ : GetViewManager()->topViews_;

            size_t i = 0;
            while (i < 2 && i < flatViews.size())
            {
                doubleTarget.push_back(flatViews[i]);
                ++i;
            }
            while (i < 3 && i < flatViews.size())
            {
                singleTarget.push_back(flatViews[i]);
                ++i;
            }

            while (doubleTarget.size() < 2)
                doubleTarget.push_back(flatViews.back()->Clone());
            while (singleTarget.size() < 1)
                singleTarget.push_back(flatViews.back()->Clone());

            GetViewManager()->verticalOrientation_ = (oneX2Top || twoX1Bottom);
        }

        if (ImGui::MenuItem("2x2 Quad", 0x0, ctTop == 2 && ctBottom == 2))
        {
            while (GetViewManager()->topViews_.size() < 2)
                GetViewManager()->topViews_.push_back(flatViews.back()->Clone());
            while (GetViewManager()->bottomViews_.size() < 2)
                GetViewManager()->bottomViews_.push_back(flatViews.back()->Clone());

            GetViewManager()->verticalOrientation_ = false;
        }

        if (ImGui::MenuItem("3x1 Top Wide", 0x0, ctTop == 3 && ctBottom == 1))
        {
            for (size_t i = 4; i < flatViews.size(); ++i)
                delete flatViews[i];
            flatViews.resize(Min(flatViews.size(), 4));
            GetViewManager()->topViews_.clear();
            GetViewManager()->bottomViews_.clear();

            size_t i = 0;
            while (i < 1 && i < flatViews.size())
            {
                GetViewManager()->topViews_.push_back(flatViews[i]);
                ++i;
            }
            while (i < 4 && i < flatViews.size())
            {
                GetViewManager()->bottomViews_.push_back(flatViews[i]);
                ++i;
            }

            while (GetViewManager()->topViews_.size() < 1)
                GetViewManager()->topViews_.push_back(flatViews.back()->Clone());
            while (GetViewManager()->bottomViews_.size() < 3)
                GetViewManager()->bottomViews_.push_back(flatViews.back()->Clone());
            GetViewManager()->verticalOrientation_ = true;
        }

        ImGui::EndPopup();
    }
}


