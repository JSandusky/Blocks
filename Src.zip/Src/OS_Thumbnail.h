#pragma once

#include <Urho3D/Graphics/Texture2D.h>
#include <Urho3D/Container/Ptr.h>

namespace Urho3D
{
    class Context;
}

Urho3D::SharedPtr<Urho3D::Texture2D> CreateThumbnail(Urho3D::Context* ctx, const Urho3D::String& path, unsigned size);
bool IsFile(const Urho3D::String& path);
