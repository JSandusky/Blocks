#include "Scripting.h"

#include <Urho3D/AngelScript/APITemplates.h>
#include <Urho3D/AngelScript/Script.h>
#include <Urho3D/AngelScript/ScriptFile.h>
#include <Urho3D/AngelScript/ScriptInstance.h>

#include <Urho3D/Core/Context.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Scene/Scene.h>
#include <Urho3D/Core/Variant.h>

#include <Urho3D/ThirdParty/AngelScript/angelscript.h>
#include <Urho3D/ThirdParty/ImGui/imgui_dock.h>
#include <Urho3D/ThirdParty/ImGui/imgui_ext.h>
#include <Urho3D/ThirdParty/ImGui/imgui_tabs.h>

#include "Block.h"
#include "Doc_DocumentManager.h"
#include "Doc_SelectableAction.h"

#include "DocType_Material.h"
#include "DocType_Scene.h"
#include "DocType_ModelViewer.h"
#include "DocType_Particle.h"

#include "Urho_Util.h"
#include "UX.h"

#include <algorithm>
#include <unordered_map>

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

std::vector<ScriptPluginMenuRecord*> script_Plugins;

ScriptPluginMenuRecord::~ScriptPluginMenuRecord()
{
    for (auto child : children_)
        delete child;
    children_.clear();
}

int pluginSort(const ScriptPluginMenuRecord* lhs, const ScriptPluginMenuRecord* rhs)
{
    return lhs->title_.Compare(rhs->title_) < 0;
}

ScriptPluginMenuRecord* ScriptPluginMenuRecord::FindOrCreateScriptPluginMenuGroup(const Urho3D::String& str, std::vector<ScriptPluginMenuRecord*>* holder)
{
    for (auto rec : *holder)
    {
        if (rec->title_ == str)
            return rec;
    }

    auto r = new ScriptPluginMenuRecord{ nullptr, str, 0 };
    holder->push_back(r);
    std::stable_sort(holder->begin(), holder->end(), pluginSort);
    return r;
}

void ScriptPluginMenuRecord::DrawScriptingPluginMenu(ScriptPluginMenuRecord* rec)
{
    if (rec->children_.size())
    {
        if (ImGui::BeginMenu(rec->title_.CString()))
        {
            for (auto c : rec->children_)
                DrawScriptingPluginMenu(c);
            ImGui::EndMenu();
        }
    }
    else
    {
        if (ImGui::MenuItem(rec->title_.CString()))
            rec->file_->SendEvent(rec->eventID_);
    }
}

void ScriptPluginMenuRecord::DrawScriptingPluginsMenu()
{
    if (script_Plugins.empty())
        return;

    ImGuiUX::MenuButton(ICON_FA_PUZZLE_PIECE, "#plugin_commands", "Plugins");
    ImGui::SameLine();

    if (ImGui::BeginPopup("#plugin_commands"))
    {
        ImGuiUX::StandardPopupChecks();

        StringHash lastMenu;
        bool lastMenuOpen = false;
        for (auto plug : script_Plugins)
            DrawScriptingPluginMenu(plug);

        if (lastMenu != 0 && lastMenuOpen)
            ImGui::EndMenu();

        ImGui::EndPopup();
    }
}

class ScriptAction : public AppAction
{
public:
    String eventName_;
    ScriptAction(const Urho3D::String& grp, const Urho3D::String& name, const Urho3D::String& message, const Urho3D::String& eventName) : AppAction(grp, name, message)
    {
        eventName_ = eventName;
    }

    void Activate()
    {
        VariantMap& eventData = BlockExe::GetInst()->GetEventDataMap();
        eventData[BindingTriggered::P_ACTION] = actionName_;
        eventData[BindingTriggered::P_GROUP] = groupName_;
        BlockExe::GetInst()->GetSubsystem<Input>()->SendEvent(eventName_, eventData);
    }
};

Vector<SharedPtr<ScriptAction>> scriptActions_;

void CheckScriptAction(const Urho3D::String& grp, const Urho3D::String& name)
{
    for (auto act : scriptActions_)
    {
        if (act->groupName_ == grp && act->actionName_ == name)
        {
            act->Activate();
            return;
        }
    }
}

ScriptPropertyPage::ScriptPropertyPage(Urho3D::SharedPtr<Urho3D::ScriptFile> scriptFile, Urho3D::StringHash typeHash, const Urho3D::String& functionCall, bool isExt) :
    scriptFile_(scriptFile), typeHash_(typeHash), functionCall_(functionCall), isExtension_(isExt)
{
    asFunction_ = scriptFile_->GetFunction(functionCall_);
}

ScriptPropertyPage::~ScriptPropertyPage()
{

}

Urho3D::HashMap<Urho3D::StringHash, ScriptPropertyPage> ScriptPropertyPage::propertyPages_;

bool ScriptPropertyPage::CanHandle(Urho3D::Object* object)
{
    if (object == nullptr)
        return false;
    return propertyPages_.Contains(object->GetType());
}

bool ScriptPropertyPage::HasExtension(Urho3D::Object* object)
{
    if (object == nullptr)
        return false;
    auto found = propertyPages_.Find(object->GetType());
    if (found != propertyPages_.End())
        return found->second_.isExtension_;
    return false;
}

bool ScriptPropertyPage::CheckAndDrawPropertyPage(Urho3D::Object* forObject, ImGuiTextFilter* filter)
{
    if (!forObject)
        return false;
    auto found = propertyPages_.Find(forObject->GetType());
    if (found != propertyPages_.End())
    {
        found->second_.DrawPropertyPage(forObject, filter);
        return true;
    }
    return false;
}

void ScriptPropertyPage::DrawPropertyPage(Urho3D::Object* object, ImGuiTextFilter* filter)
{
    if (asFunction_)
        scriptFile_->Execute(asFunction_, { object, filter });
}

void ClearScriptRegistration()
{
    for (auto c : script_Plugins)
        delete c;
    script_Plugins.clear();
    ScriptPropertyPage::propertyPages_.Clear();
}

void as_RegisterPluginMenu(const String& title, const String& eventID)
{
    if (title.Contains('/'))
    {
        auto strings = title.Split('/');
        ScriptPluginMenuRecord* group;
        std::vector<ScriptPluginMenuRecord*>* holder = &script_Plugins;
        while (strings.Size() > 1)
        {
            group = ScriptPluginMenuRecord::FindOrCreateScriptPluginMenuGroup(strings[0], holder);
            holder = &group->children_;
            strings.Erase(0);
        }
        holder->push_back(new ScriptPluginMenuRecord{ SharedPtr<ScriptFile>(GetScriptContextFile()), strings[0], eventID });
        std::stable_sort(holder->begin(), holder->end(), pluginSort);
        return;
    }
    else
        script_Plugins.push_back(new ScriptPluginMenuRecord { SharedPtr<ScriptFile>(GetScriptContextFile()), title, eventID });
    
    // Menu items are always arranged in alphabetical order
    std::stable_sort(script_Plugins.begin(), script_Plugins.end(), pluginSort);
}

unsigned as_GetSelectionCount()
{
    if (auto doc = DocumentManager::Get()->GetActiveDocument())
        return doc->GetSelection().size();
    return 0;
}

Urho3D::Object* as_GetSelected(unsigned index)
{
    if (auto doc = DocumentManager::Get()->GetActiveDocument())
    {
        if (index < doc->GetSelection().size())
        {
            if (auto sel = std::dynamic_pointer_cast<UrhoNodeSelectable>(doc->GetSelection()[index]))
                return sel->node_.Get();
            else if (auto sel = std::dynamic_pointer_cast<UrhoComponentSelectable>(doc->GetSelection()[index]))
                return sel->component_.Get();
        }
    }
    return 0x0;
}

Urho3D::Scene* as_GetMasterScene()
{
    return BlockExe::GetInst()->GetMasterScene().Get();
}

Urho3D::Scene* as_GetActiveScene()
{
    if (auto doc = DocumentManager::Get()->GetActiveDoc<Document3D>())
        return doc->GetScene().Get();
    return nullptr;
}

void as_ClearSelection() { 
    if (auto doc = DocumentManager::Get()->GetActiveDocument()) 
        doc->GetSelection().clear(); 
}

void as_SelectNode(Node* node) { 
    if (node == nullptr)
        return;
    if (auto doc = DocumentManager::Get()->GetActiveDocument()) 
        doc->GetSelection().Select(std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(node))); 
}

void as_SelectComp(Component* node) {
    if (node == nullptr)
        return;
    if (auto doc = DocumentManager::Get()->GetActiveDocument())
        doc->GetSelection().Select(std::make_shared<UrhoComponentSelectable>(SharedPtr<Component>(node)));
}

void as_Deselect(Object* node) {
    if (node == nullptr)
        return;
    if (auto doc = DocumentManager::Get()->GetActiveDocument())
        doc->GetSelection().Deselect(node);
}

void as_AddSelect(Object* node) {
    if (node == nullptr)
        return;
    if (auto doc = DocumentManager::Get()->GetActiveDocument())
    {
        if (auto nd  = dynamic_cast<Node*>(node))
            doc->GetSelection().AddSelection(std::make_shared<UrhoNodeSelectable>(SharedPtr<Node>(nd)));
        else if (auto cmp = dynamic_cast<Component*>(node))
            doc->GetSelection().AddSelection(std::make_shared<UrhoComponentSelectable>(SharedPtr<Component>(cmp)));
    }
}

Urho3D::String as_OSOpenDialog(const Urho3D::String& title, const Urho3D::String& filter)
{
    return OSOpenFile(title.CString(), 0x0, filter.CString()).c_str();
}

Urho3D::String as_OSSaveDialog(const Urho3D::String& title, const Urho3D::String& filter)
{
    return GetSaveFile(title.CString(), 0x0, filter.CString()).c_str();
}


bool as_BeginDock(const Urho3D::String& name)
{
    return ImGui::BeginDock(name.CString());
}

Urho3D::ImGuiElement* as_GetImGuiElement() { return BlockExe::GetInst()->GetImGuiElem().Get(); }

static StringHash closeWindowParam("Close");
static bool as_closeWindow = false;
void as_PushScriptModal(const Urho3D::String& name, const Urho3D::String& funcName)
{
    SharedPtr<ScriptFile> scriptFile(GetScriptContextFile());
    ModalWindows::Get()->PushModal(ModalWindow(name.CString(), [scriptFile, funcName]() -> bool {
        as_closeWindow = false;
        scriptFile->Execute(funcName);
        if (as_closeWindow)
            return false;
        return true;
    }));
}

void as_PushScriptToolWindow(const Urho3D::String& name, const Urho3D::String& funcName)
{
    SharedPtr<ScriptFile> scriptFile(GetScriptContextFile());
    ModalWindows::Get()->PushTool(ModalWindow(name.CString(), [scriptFile, funcName]() -> bool {
        as_closeWindow = false;
        scriptFile->Execute(funcName);
        if (as_closeWindow)
            return false;
        return true;
    }));
}

void as_RegisterAction(const Urho3D::String& grpName, const Urho3D::String& action, const Urho3D::String& message, const Urho3D::String& eventName)
{
    BlockExe::GetInst()->GetSubsystem<Input>()->AddInputBinding(SharedPtr<InputBinding>(new ScriptAction(grpName, action, message, eventName)));
}

void RegisterAngelscript(class asIScriptEngine* engine)
{
    //RegisterObject<DocumentBase>(engine, "DocumentBase");
    //RegisterSubclass<DocumentBase, Document3D>(engine, "DocumentBase", "Document3D");
    //RegisterSubclass<Document3D, SceneDocument>(engine, "Document3D", "SceneDocument");
    //RegisterSubclass<Document3D, ParticleDocument>(engine, "Document3D", "ParticleDocument");
    //RegisterSubclass<Document3D, ModelViewerDocument>(engine, "Document3D", "ModelViewerDocument");
    //RegisterSubclass<Document3D, MaterialDocument>(engine, "Document3D", "MaterialDocument");
    
    engine->RegisterInterface("ScriptDocument");
    engine->RegisterInterfaceMethod("ScriptDocument", "void NewDocument()");
    engine->RegisterInterfaceMethod("ScriptDocument", "bool OpenDocument(const String&in)");
    engine->RegisterInterfaceMethod("ScriptDocument", "void DrawViewport()");
    engine->RegisterInterfaceMethod("ScriptDocument", "void DrawProperties()");
    engine->RegisterInterfaceMethod("ScriptDocument", "void DrawSceneTree()");
    // One time only
    engine->RegisterInterfaceMethod("ScriptDocument", "bool HasPropertySheet()");
    engine->RegisterInterfaceMethod("ScriptDocument", "bool HasCustomSceneTree()");

    engine->SetDefaultNamespace("Plugin");
    engine->RegisterGlobalFunction("void RegisterMenuItem(const String&in, const String&in)", asFUNCTION(as_RegisterPluginMenu), asCALL_CDECL);
    engine->RegisterGlobalFunction("void RegisterPropertyPage(const String&in, const String&, bool)", asFUNCTIONPR([](const String& typeHash, const String& functionCall, bool isExt) {
        // NOT CHECKING CONTAINMENT IS DELIBERATE, allows plugins to override other plugins
        ScriptPropertyPage::propertyPages_[typeHash] = ScriptPropertyPage(SharedPtr<ScriptFile>(GetScriptContextFile()), typeHash, functionCall, isExt);
    }, (const String&, const String&, bool), void), asCALL_CDECL);
    engine->RegisterGlobalFunction("void RegisterAction(const String&in, const String&in, const String&in, const String&in)", asFUNCTION(as_RegisterAction), asCALL_CDECL);
    engine->SetDefaultNamespace("");

    engine->SetDefaultNamespace("Editor");
    engine->RegisterGlobalFunction("Scene@+ GetMasterScene()", asFUNCTION(as_GetMasterScene), asCALL_CDECL);
    engine->RegisterGlobalFunction("Scene@+ GetActiveScene()", asFUNCTION(as_GetActiveScene), asCALL_CDECL);
    engine->RegisterGlobalFunction("ImGuiElement@+ GetImGui()", asFUNCTION(as_GetImGuiElement), asCALL_CDECL);

    engine->RegisterGlobalFunction("void ShowModalWindow(const String&in, const String&in)", asFUNCTION(as_PushScriptModal), asCALL_CDECL);
    engine->RegisterGlobalFunction("void ShowToolWindow(const String&in, const String&in)", asFUNCTION(as_PushScriptToolWindow), asCALL_CDECL);

    // Selection management
    engine->RegisterGlobalFunction("uint GetSelectionCount()", asFUNCTION(as_GetSelectionCount), asCALL_CDECL);
    engine->RegisterGlobalFunction("Object@+ GetSelected(uint)", asFUNCTION(as_GetSelected), asCALL_CDECL);
    engine->RegisterGlobalFunction("void ClearSelection()", asFUNCTION(as_ClearSelection), asCALL_CDECL);
    engine->RegisterGlobalFunction("void Select(Object@+)", asFUNCTION(as_SelectNode), asCALL_CDECL);
    engine->RegisterGlobalFunction("void AddSelection(Object@+)", asFUNCTION(as_AddSelect), asCALL_CDECL);
    engine->RegisterGlobalFunction("void Deselect(Object@+)", asFUNCTION(as_Deselect), asCALL_CDECL);
    engine->RegisterGlobalFunction("Vector3 GetSelectionCenter()", asFUNCTION(GetSelectionCentroid), asCALL_CDECL);
    engine->SetDefaultNamespace("");

    // OS functions
    engine->SetDefaultNamespace("OS");
    engine->RegisterGlobalFunction("String GetOpenFile(const String&in, const String&in)", asFUNCTION(as_OSOpenDialog), asCALL_CDECL);
    engine->RegisterGlobalFunction("String GetSaveFile(const String&in, const String&in)", asFUNCTION(as_OSSaveDialog), asCALL_CDECL);
    engine->SetDefaultNamespace("");

    engine->SetDefaultNamespace("ImGui");
    engine->RegisterGlobalFunction("bool BeginDock(const String&in)", asFUNCTION(as_BeginDock), asCALL_CDECL);
    engine->RegisterGlobalFunction("void EndDock()", asFUNCTION(ImGui::EndDock), asCALL_CDECL);
    engine->SetDefaultNamespace("");

    engine->SetDefaultNamespace("ImGuiUX");
    engine->RegisterGlobalFunction("bool ToggleButton(const String&in, bool&)", asFUNCTIONPR([](const String& title, bool& state) {
        if (ImGuiUX::ToggleButton(title.CString(), state))
        {
            state = !state;
            return true;
        }
        return false;
    }, (const String&, bool&), bool), asCALL_CDECL);
    engine->RegisterGlobalFunction("bool MenuButton(const String&in, const String&in, const String& in)", asFUNCTIONPR([](const String& text, const String& menuID, const String& tip) {
        return ImGuiUX::MenuButton(text.CString(), menuID.CString(), tip.CString());
    }, (const String&, const String&, const String&), bool), asCALL_CDECL);
    engine->RegisterGlobalFunction("void PushBoldFont()", asFUNCTION(ImGuiUX::PushBold), asCALL_CDECL);
    engine->RegisterGlobalFunction("void PushLargeBoldFont()", asFUNCTION(ImGuiUX::PushLargeBold), asCALL_CDECL);
    engine->RegisterGlobalFunction("void PopFont()", asFUNCTION(ImGui::PopFont), asCALL_CDECL);
    engine->RegisterGlobalFunction("bool AutoMenu(const String&in)", asFUNCTIONPR([](const String& title) { return ImGuiUX::AutoMenu(title.CString()); }, (const String&), bool), asCALL_CDECL);
    engine->RegisterGlobalFunction("void AutoSeparator()", asFUNCTION(ImGuiUX::AutoSeparator), asCALL_CDECL);
    engine->RegisterGlobalFunction("void CheckAutoSeparator()", asFUNCTION(ImGuiUX::CheckAutoSeparator), asCALL_CDECL);
    engine->RegisterGlobalFunction("void EndAutoMenu()", asFUNCTION(ImGuiUX::EndAutoMenu), asCALL_CDECL);
    engine->RegisterGlobalFunction("void StandardPopupChecks()", asFUNCTION(ImGuiUX::StandardPopupChecks), asCALL_CDECL);
    engine->RegisterGlobalFunction("bool Bitmask(const String&in, uint&inout)", asFUNCTIONPR([](const String& txt, unsigned& val) {
        return ImGui::BitField(txt.CString(), &val);
    }, (const String&, unsigned&), bool), asCALL_CDECL);
    engine->RegisterGlobalFunction("bool RangeSliderFloat(const String&in, float&inout, float&inout, float, float)", asFUNCTIONPR([](const String& txt, float& v1, float& v2, float m1, float m2) {
        return ImGui::RangeSliderFloat(txt.CString(), &v1, &v2, m1, m2);
    }, (const String&, float&, float&, float, float), bool), asCALL_CDECL);
    engine->RegisterGlobalFunction("bool RangeSliderFloat(const String&in, Vector2&inout, const Vector2&in)", asFUNCTIONPR([](const String& txt, Vector2& v1, const Vector2& limits) {
        return ImGui::RangeSliderFloat(txt.CString(), &v1.x_, &v1.y_, limits.x_, limits.y_);
    }, (const String&, Vector2&, const Vector2&), bool), asCALL_CDECL);
    
    engine->RegisterGlobalFunction("void BeginTabBar(const String&in, int)", asFUNCTIONPR([](const String& title, int flags) {
        ImGui::BeginTabBar(title.CString(), flags);
    }, (const String&, int), void), asCALL_CDECL);
    engine->RegisterGlobalFunction("bool TabItem(const String&in, bool&inout, int)", asFUNCTIONPR([](const String& title, bool& state, int flags) {
        return ImGui::TabItem(title.CString(), &state, flags);
    }, (const String&, bool&, int), bool), asCALL_CDECL);
    engine->RegisterGlobalFunction("void EndTabBar()", asFUNCTION(ImGui::EndTabBar), asCALL_CDECL);
    engine->RegisterGlobalFunction("bool EditVariant(const String&in, Variant&inout)", asFUNCTIONPR([](const String& id, Variant& val) {
        ImGui::PushID(id.CString());
        bool ret = ImGuiElement::EditVariant(val);
        ImGui::PopID();
        return ret;
    }, (const String&, Variant&), bool), asCALL_CDECL);
    engine->SetDefaultNamespace("");
}

void ExecuteScriptFile(Urho3D::Context* ctx, const std::string& scriptFile)
{
    auto cache = ctx->GetSubsystem<ResourceCache>();
    if (auto script = ctx->GetSubsystem<Script>())
    {
        if (ScriptFile* file = cache->GetResource<ScriptFile>(scriptFile.c_str()))
        {
            file->Execute("void main()");
            cache->ReleaseResource<ScriptFile>(file->GetName(), true);
        }
    }
}

void ExecuteScriptOnScene(Urho3D::Context* ctx, Urho3D::Scene* target, const std::string& scriptFile)
{
    auto cache = ctx->GetSubsystem<ResourceCache>();
    if (auto script = ctx->GetSubsystem<Script>())
    {
        if (ScriptFile* file = cache->GetResource<ScriptFile>(scriptFile.c_str()))
        {
            VariantVector v;
            v.Push(target);
            file->Execute("void main(Scene@+)", v);
            cache->ReleaseResource<ScriptFile>(file->GetName(), true);
        }
    }
}