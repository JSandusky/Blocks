#pragma once

#include <Urho3D/Core/Object.h>
#include <Urho3D/Math/Matrix3x4.h>

#include <functional>
#include <memory>
#include <vector>

class Selectable
{
public:
    virtual ~Selectable() { }

    virtual bool Is(void* t) const = 0;
    virtual bool Is(std::shared_ptr<Selectable> t) const = 0;
    virtual void AccumulateTransform(std::vector<Urho3D::Matrix3x4>& into, int& idx) { }
    virtual void ExtractTransform(const Urho3D::Matrix4& ref, const Urho3D::Matrix4& from, int& idx, int mode, bool isReversal) { }
};

typedef std::vector< std::shared_ptr<Selectable> > SelectionList;

/// For UI display using a 'fake' selectable object.
class FunctionalSelectable
{
public:
    FunctionalSelectable(std::function<void()> propertiesFunc) : propertiesFunction_(propertiesFunc) { }
    virtual bool Is(void* t) const { return false; }
    virtual bool Is(std::shared_ptr<Selectable> t) const {
        return false;
    }
    std::function<void()> propertiesFunction_;
};

class SelectionContext : public Urho3D::Object, public std::vector<std::shared_ptr<Selectable> >
{
    URHO3D_OBJECT(SelectionContext, Urho3D::Object);
public:
    using std::vector<std::shared_ptr<Selectable> >::size;
    using std::vector<std::shared_ptr<Selectable> >::empty;
    using std::vector<std::shared_ptr<Selectable> >::begin;
    using std::vector<std::shared_ptr<Selectable> >::end;
    using std::vector<std::shared_ptr<Selectable> >::iterator;
    using std::vector<std::shared_ptr<Selectable> >::const_iterator;

    std::shared_ptr<Selectable> GetMostRecent();

    template<typename T>
    std::shared_ptr<T> MostRecent() {
        static_assert(std::is_base_of<Selectable, T>::value, "T must derive from selectable for SelectionContext");
        if (size())
            return std::dynamic_pointer_cast<T>(back());
        return std::shared_ptr<T>();
    }

    void Select(std::shared_ptr<Selectable> sel);
    void AddSelection(std::shared_ptr<Selectable> sel);
    void Deselect(std::shared_ptr<Selectable> sel);
    void Deselect(void* data);
    void DeselectAll();
    bool IsSelected(void* data);

    SelectionList GetList() const { return SelectionList(*this); }
    void Set(const SelectionList& sel);

    template<typename T>
    std::shared_ptr<T> Get(size_t i)
    {
        static_assert(std::is_base_of<Selectable, T>::value, "T must derive from selectable for SelectionContext");
        return std::dynamic_pointer_cast<T>((*this)[i]);
    }

    template<typename T>
    std::vector<std::shared_ptr<T>> GetAll()
    {
        std::vector<std::shared_ptr<T>> ret;
        for (size_t i = 0; i < size(); ++i)
        {
            if (auto d = std::dynamic_pointer_cast<T>((*this)[i]))
                ret.push_back(d);
        }
        return ret;
    }

    template<typename T>
    std::shared_ptr<T> GetFirstOf()
    {
        for (size_t i = 0; i < size(); ++i)
            if (auto d = std::dynamic_pointer_cast<T>((*this)[i]))
                return d;
        return nullptr;
    }

    size_t Count() const { return size(); }
    bool IsEmpty() const { return empty(); }

    SelectionContext(Urho3D::Context*);
    ~SelectionContext();
};