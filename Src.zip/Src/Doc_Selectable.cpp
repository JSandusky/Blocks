#include "Doc_Selectable.h"

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

SelectionContext::SelectionContext(Urho3D::Context* ctx) :
    Object(ctx)
{

}

SelectionContext::~SelectionContext()
{
    if (!empty())
    {
        clear();
        SendEvent("EDITOR_SELECTION_CHANGED");
    }
}

std::shared_ptr<Selectable> SelectionContext::GetMostRecent() 
{
    if (size())
        return back();
    return std::shared_ptr<Selectable>();
}

void SelectionContext::Select(std::shared_ptr<Selectable> sel)
{
    clear();
    push_back(sel);
    auto& eventData = GetEventDataMap();
    SendEvent("EDITOR_SELECTION_CHANGED");
}

void SelectionContext::AddSelection(std::shared_ptr<Selectable> sel)
{
    for (auto s : *this)
        if (s->Is(sel))
            return;
    
    push_back(sel);
    SendEvent("EDITOR_SELECTION_CHANGED");
}

void SelectionContext::Deselect(std::shared_ptr<Selectable> sel)
{
    auto found = std::find(begin(), end(), sel);
    if (found != end())
    {
        erase(found);
        SendEvent("EDITOR_SELECTION_CHANGED");
    }
}

bool SelectionContext::IsSelected(void* data)
{
    for (auto it = begin(); it != end(); ++it)
    {
        if ((*it)->Is(data))
            return true;
    }
    return false;
}

void SelectionContext::Deselect(void* data)
{
    for (auto it = begin(); it != end(); ++it)
    {
        if ((*it)->Is(data))
        {
            erase(it);
            SendEvent("EDITOR_SELECTION_CHANGED");
            return;
        }
    }
}

void SelectionContext::DeselectAll()
{
    if (!empty())
    {
        clear();
        SendEvent("EDITOR_SELECTION_CHANGED");
    }
}

void SelectionContext::Set(const SelectionList& sel)
{
    // Check for differences first
    bool isDifferent = sel.size() != size();
    for (size_t i = 0; i < Min(sel.size(), size()) && isDifferent == false; ++i)
    {
        if ((*this)[i]->Is(sel[i]) == false)
            isDifferent = true;
    }

    if (isDifferent)
    {
        clear();
        insert(end(), sel.begin(), sel.end());
        SendEvent("EDITOR_SELECTION_CHANGED");
    }
}