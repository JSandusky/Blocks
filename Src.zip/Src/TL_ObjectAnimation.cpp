#include "TL_ObjectAnimation.h"

#include <Urho3D/Scene/ValueAnimation.h>
#include <Urho3D/Scene/ValueAnimationInfo.h>

using namespace Urho3D;

ObjectAnimSequencer::ObjectAnimSequencer(Urho3D::SharedPtr<Urho3D::ObjectAnimation> animation)
{
    animation_ = animation;
}

ObjectAnimSequencer::~ObjectAnimSequencer()
{

}

int ObjectAnimSequencer::GetFrameCount() const
{
    if (animation_)
    {
        int max = 0;
        for (auto k : animation_->GetAttributeAnimationInfos().Values())
            max = Max(max, k->GetAnimation()->GetEndTime() * 30);
    }
    return 0;
}

int ObjectAnimSequencer::GetTrackCount() const
{
    if (animation_)
        return animation_->GetAttributeAnimationInfos().Size();
    return 0;
}
ImSequencer::TRACK_NATURE ObjectAnimSequencer::GetTrackNature(unsigned trackIndex) const
{
    return ImSequencer::TRACK_NATURE_TICK;
}
int ObjectAnimSequencer::GetTrackTypeCount() const
{
    return 1;
}
const char* ObjectAnimSequencer::GetTrackTypeName(int typeIndex) const
{
    return "Value Animation";
}
const char* ObjectAnimSequencer::GetTrackLabel(int index) const
{
    if (animation_)
    {
        auto vals = animation_->GetAttributeAnimationInfos().Keys();
        return vals[index].CString();
    }
    return 0x0;
}
unsigned ObjectAnimSequencer::GetKeyFrameCount(int trackIndex)
{
    if (animation_)
    {
        auto vals = animation_->GetAttributeAnimationInfos().Values();
        return vals[trackIndex]->GetAnimation()->GetKeyFrames().Size();
    }
    return 0;
}
void ObjectAnimSequencer::Get(int trackIndex, int keyIndex, int** start, int** end, int *type, unsigned int *color)
{
    if (animation_)
    {
        if (keyIndex != -1)
        {
            auto vals = animation_->GetAttributeAnimationInfos().Values();
            auto key = vals[trackIndex]->GetAnimation()->GetKeyFrames()[keyIndex];
            //if (start)
            //    *start = (key.time_ * 30);
        }
        if (type)
            *type = 1;
    }
}
void ObjectAnimSequencer::Add(int type)
{

}
void ObjectAnimSequencer::Del(int index)
{

}
void ObjectAnimSequencer::Duplicate(int index)
{

}
bool ObjectAnimSequencer::SwapKeyframes(int trackIndex, int keyIndex, int withIndex)
{
    if (animation_)
    {
        auto vals = animation_->GetAttributeAnimationInfos().Values();
        auto& keys = vals[trackIndex]->GetAnimation()->GetKeyFrames();
        Swap(keys[keyIndex], keys[withIndex]);
        return true;
    }
    return false;
}