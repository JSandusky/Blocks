#pragma once

#include "CubeCapture.h"
#include "Doc_Document3D.h"
#include "GUI_Pane3D.h"

namespace Urho3D
{
    class RenderSurface;
    class Texture2D;
    class Viewport;
}

class SceneDocumentType : public DocumentType
{
public:
    SceneDocumentType();

    virtual std::shared_ptr<DocumentBase> NewDocument() override;
    virtual std::shared_ptr<DocumentBase> OpenPath(const Urho3D::String& path) override;

    virtual bool OpensXML(const Urho3D::String& xmlRootName) { return xmlRootName == "scene" || xmlRootName == "node"; }
};

class SceneDocument : public Document3D
{
    friend class GUI_SceneView3D;
public:
    /// Common construct
    SceneDocument(Urho3D::Context*);
    SceneDocument(Urho3D::Context*, const Urho3D::String& path);
    SceneDocument(Urho3D::Context*, const SceneDocument& src) = delete;
    virtual ~SceneDocument();

    virtual bool Save() override;
    virtual unsigned GetTabColor() const override { return ImColor(30, 120, 30, 255); }

    virtual void SaveAs() override;
    /// Tries to close the document, returns true if we were able to immediately close it (not dirty)
    virtual bool Close() override;

    virtual void PreDraw() override;
    virtual void DrawMasterButtons() override;

    bool CheckMultiGizmo() override;

protected:
    void CommonConstruct();
    void CommonSave();

    void BakeLightmaps();
    void BakeCubemaps();
    void OptimizeMeshes();
    void BakeNavigation();

    void InitializeCameraView(Urho3D::SharedPtr<Urho3D::Camera> camera);
    void DeinitializeCameraView();

    void OnSelectionChanged(Urho3D::StringHash, Urho3D::VariantMap&);

    Urho3D::SharedPtr<Urho3D::Camera> viewCamera_;
    Urho3D::SharedPtr<Urho3D::Texture2D> viewTexture_;
    Urho3D::SharedPtr<Urho3D::RenderSurface> viewSurface_;
    Urho3D::SharedPtr<Urho3D::Viewport> viewport_;
    Urho3D::SharedPtr<Urho3D::Node> prefabNode_;
    bool isPrefab_ = false;
    intptr_t viewTexID_;
    std::shared_ptr<CapturingData> captureData_;

// Binding evnets
    void OnBindingAction(Urho3D::StringHash, Urho3D::VariantMap&);
};

class GUI_SceneView3D : public GUI_View3D
{
public:
    GUI_SceneView3D(Document3D::View*);
    virtual ~GUI_SceneView3D();

    virtual void Draw(const Urho3D::IntRect&) override;
    virtual void Activate() override;
    virtual GUI_PaneView* Clone() override;
    virtual void DoBoxSelect(Urho3D::Frustum) override;
};

struct MultiGizmo : public BaseGizmo
{
    MultiGizmo(std::vector<std::shared_ptr<UrhoNodeSelectable> > items);

    virtual bool Draw(Urho3D::Camera* camera, const Urho3D::IntRect& rect, Urho3D::DebugRenderer*) override;

    std::vector< std::shared_ptr<UrhoNodeSelectable> > items_;
    std::vector<Urho3D::Matrix3x4> originalMatrices_;
    Urho3D::Matrix4 centroidMat_;
    Urho3D::Matrix4 editMat_;
    bool didClone_ = false;
};
