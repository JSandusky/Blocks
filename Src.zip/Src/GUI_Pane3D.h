#pragma once

#include <Urho3D/Scene/Component.h>
#include <Urho3D/Math/Frustum.h>
#include <Urho3D/Container/Str.h>
#include <Urho3D/UI/UIElement.h>

#include "GUI_Main.h"
#include "Doc_DocumentManager.h"
#include "Doc_Document3D.h"
#include "UX.h"

class GUI_View3D;

class UrhoNodeSelectable : public Selectable
{
public:
    Urho3D::SharedPtr<Urho3D::Node> node_;

    UrhoNodeSelectable(Urho3D::Node* n);
    UrhoNodeSelectable(const Urho3D::SharedPtr<Urho3D::Node>& n);
    UrhoNodeSelectable(const Urho3D::SharedPtr<Urho3D::Scene>& n);
    ~UrhoNodeSelectable();

    virtual bool Is(void* item) const override;
    virtual bool Is(std::shared_ptr<Selectable> t) const override;

    virtual void AccumulateTransform(std::vector<Urho3D::Matrix3x4>& into, int& idx) override;
    virtual void ExtractTransform(const Urho3D::Matrix4& refmat, const Urho3D::Matrix4& from, int& idx, int mode, bool isReversal) override;
};

class UrhoComponentSelectable : public Selectable
{
public:
    Urho3D::SharedPtr<Urho3D::Component> component_;

    UrhoComponentSelectable(Urho3D::Component* c)
    {
        component_ = Urho3D::SharedPtr<Urho3D::Component>(c);
    }
    UrhoComponentSelectable(Urho3D::SharedPtr<Urho3D::Component> c)
    {
        component_ = c;
    }
    ~UrhoComponentSelectable() { component_.Reset(); }

    virtual bool Is(void* item) const override { return component_.Get() == item; }

    virtual bool Is(std::shared_ptr<Selectable> t) const {
        if (auto rhs = std::dynamic_pointer_cast<UrhoComponentSelectable>(t))
            return component_ == rhs->component_;
        return false;
    }
};

class UrhoUISelectable : public Selectable
{
public:
    Urho3D::SharedPtr<Urho3D::UIElement> element_;

    UrhoUISelectable(Urho3D::SharedPtr<Urho3D::UIElement> c)
    {
        element_ = c;
    }
    ~UrhoUISelectable() { element_.Reset(); }

    virtual bool Is(void* item) const override { return element_.Get() == item; }

    virtual bool Is(std::shared_ptr<Selectable> t) const {
        if (auto rhs = std::dynamic_pointer_cast<UrhoUISelectable>(t))
            return element_ == rhs->element_;
        return false;
    }
};

class UrhoResourceSelectable : public Selectable
{
public:
    Urho3D::SharedPtr<Urho3D::Resource> resource_;

    UrhoResourceSelectable(Urho3D::SharedPtr<Urho3D::Resource> r)
    {
        resource_ = r;
    }
    ~UrhoResourceSelectable() { resource_.Reset(); }

    virtual bool Is(void* item) const override { return resource_.Get() == item; }

    virtual bool Is(std::shared_ptr<Selectable> t) const {
        if (auto rhs = std::dynamic_pointer_cast<UrhoResourceSelectable>(t))
            return resource_ == rhs->resource_;
        return false;
    }
};

enum ViewNavigationStyle
{
    VNS_Free,
    VNS_Front,
    VNS_Back, //2D
    VNS_Top,
    VNS_Right,
    VNS_Left
};

struct BoxSelect3D
{
    Urho3D::IntRect box_ = Urho3D::IntRect(0,0,0,0);
    bool started_ = false;

    /// Grabs a rightfully organized rect.
    Urho3D::IntRect GetCleanRect();
    /// Update the positioning of the rect.
    void Update(int, int);
    /// Gets 4 clipping planes (top, left, right, bottom) for the rect
    Urho3D::Frustum CalculatePlanes(Urho3D::Camera*, float w, float h);
};

class GUI_View3D : public GUI_PaneView, public IMouseCapture
{
public:
    GUI_View3D(Document3D::View*);
    virtual ~GUI_View3D();

    virtual void Draw(const Urho3D::IntRect&) override;

    virtual void ActivateDraw() override;
    virtual void DeactivateDraw() override;
    virtual GUI_PaneView* Clone() override { return 0x0; }

    virtual bool ProcessKeys() override;
    virtual bool ProcessCapture(const Urho3D::IntVector2& pos, const Urho3D::IntVector2& delta) override;

    void ProcessKeyboardInput(float);

    bool CheckBoxSelect(float oX, float oY, bool isOver);
    virtual void DoBoxSelect(Urho3D::Frustum) { }

    ViewNavigationStyle style_ = VNS_Free;
    Document3D::View* view_;
    Urho3D::String name_;
    bool noGrid_ = false;
    bool isBoxSelecting_ = false;
    BoxSelect3D boxSelector_;
};