#pragma once

#include "Doc_Document3D.h"

#include <Urho3D/Graphics/Material.h>
#include <Urho3D/Graphics/Model.h>
#include <Urho3D/Graphics/StaticModel.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>

class MaterialDocumentType : public DocumentType
{
public:
    MaterialDocumentType();

    virtual std::shared_ptr<DocumentBase> NewDocument() override;
    virtual std::shared_ptr<DocumentBase> OpenPath(const Urho3D::String& path) override;

    virtual bool OpensXML(const Urho3D::String& xmlRootName) { return xmlRootName == "material"; }
};

class MaterialDocument : public Document3D, public IPropertyDocument
{
    friend class GUI_MaterialView;
public:
    MaterialDocument(Urho3D::Context*);
    MaterialDocument(Urho3D::Context*, const Urho3D::String& path);
    virtual ~MaterialDocument();

    virtual unsigned GetTabColor() const override { return ImColor(120, 30, 30, 255); }
    virtual bool Save() override;
    virtual void SaveAs() override;
    virtual bool Close() override;

    virtual void PreDraw() override;
    virtual void DrawProperties(ImGuiTextFilter*) override;
    virtual void DrawMasterButtons() override;

protected:
    friend struct MaterialShaderParamCreateDelete;
    friend struct MaterialShaderParamEdit;
    friend struct MaterialTechniqueAddRemove;
    friend struct MaterialTechniqueEdit;

    void CommonConstruct();
    void CollectMaterialParams();
    void ScheduleParamUpdate() const;
    void ScheduleRecollect() const;

    Urho3D::SharedPtr<Urho3D::StaticModel> previewModel_;
    Urho3D::SharedPtr<Urho3D::Material> material_;
    Urho3D::Vector<Urho3D::MaterialShaderParameter> materialParams_;
    Urho3D::SharedPtr<Urho3D::Model> model_;
    int modelIndex_;
    bool animateLight_ = true;
    bool drawAxes_ = true;
    float lightTime_ = 0.0f;
    mutable bool updateParams_ = false;
    mutable bool flushParams_ = false;
};