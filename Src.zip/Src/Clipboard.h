#pragma once

#include <Urho3D/IO/VectorBuffer.h>

namespace Clipboard
{
    unsigned GetClipboardDataType();
    Urho3D::VectorBuffer& GetClipboardData();

    void SetClipboardDataType(unsigned type);
    void SetClipboardData(unsigned type, const Urho3D::VectorBuffer& buffer);
    void ClearClipboard();
}