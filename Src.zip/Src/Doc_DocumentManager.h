#pragma once

#include <Urho3D/Scene/Scene.h>
#include <Urho3D/Scene/Node.h>
#include <Urho3D/Graphics/Texture2D.h>
#include <Urho3D/Graphics/Viewport.h>

#include "Doc_Actions.h"
#include "Doc_Selectable.h"

#include <memory>
#include <vector>

struct ImGuiTextFilter;

namespace Urho3D
{
    class DebugRenderer;
    class BillboardSet;
    class Node;
    class Input;
}

struct NodeDocument;

class GUI_ViewManager;

/// Document that is itself a collection properties (material, particle-effect, model)
class IPropertyDocument abstract
{
public:
    virtual void DrawProperties(ImGuiTextFilter*) = 0;
};

std::string OSOpenFile(const std::string& title, const char* defExt, const char* filter);
std::string GetSaveFile(const std::string& title, const char* defExt, const char* filter);
std::pair<std::string, std::string> GetSaveFile_PairName(const std::string& title, const char* defExt, const char* filter);

/// Document that is itself a hierarchy of nodes (scene, model [bones])
class ITreeDocument abstract
{
public:
    virtual ~ITreeDocument() { }
    virtual void DrawDocumentTree(ImGuiTextFilter*) = 0;
};

/// For multiplie inheritence.
class IMultiViewDocument abstract
{
public:
    virtual ~IMultiViewDocument() { }

    void DrawMultiViewMasterButton();
};

/// Document that contains a default timeline.
class ITimelineDocument abstract
{
public:
    virtual ~ITimelineDocument() { }
    virtual void DrawTimeline() = 0;
};

class DocumentBase abstract : public Urho3D::Object
{
    URHO3D_OBJECT(DocumentBase, Object);
public:
    virtual ~DocumentBase();

    virtual bool Save() = 0;

    virtual void SaveAs() = 0;
    /// Tries to close the document, returns true if we were able to immediately close it (not dirty)
    virtual bool Close();
    /// Return a tab color to draw with.
    virtual unsigned GetTabColor() const = 0;

    virtual void DrawMasterButtons() = 0;

    bool IsDirty() const { return dirty_; }
    void ClearDirty();
    void MarkDirty() const { dirty_ = true; }
    const std::string& GetPath() const { return filePath_; }
    const std::string& GetName() const { return name_; }

    SelectionContext& GetSelection() { return selectionContext_; }

    GUI_ViewManager* GetViewManager() { return guiViews_; }

    UndoStack& GetUndoStack() { return undoRedo_; }

    virtual void PreDraw() { }

    virtual void Activated() { }
    virtual void Deactivated() { }
    bool IsActive() const;

protected:
    DocumentBase(Urho3D::Context*);

    std::string GetSavePath(const std::string& title, const std::string& filter, bool saveAs);

    friend class DocumentManager;
    void SetPath(const std::string& path) { filePath_ = path; }

    GUI_ViewManager* guiViews_;
    UndoStack undoRedo_;
    std::string name_ = "< new document >";
    std::string filePath_;
    SelectionContext selectionContext_;
    mutable bool dirty_ = false;
    bool closing_ = false;
};

struct BaseGizmo
{
    static const int NONE;
    static const int TRANSLATE;
    static const int ROTATE;
    static const int SCALE;
    static const int BOX;
    static int mode_;
    static bool isLocal_;

    virtual ~BaseGizmo() { }

    void DrawGrid(int gridType, Urho3D::Vector3 trans, Urho3D::DebugRenderer*);

    virtual bool Draw(Urho3D::Camera* camera, const Urho3D::IntRect& rect, Urho3D::DebugRenderer*) = 0;
};

struct UrhoGizmo : public BaseGizmo
{
    UrhoGizmo(Urho3D::SharedPtr<Urho3D::Node> tgt) { transformNode_ = tgt; }

    Urho3D::SharedPtr<Urho3D::Node> transformNode_;

    virtual bool Draw(Urho3D::Camera* camera, const Urho3D::IntRect& rect, Urho3D::DebugRenderer*) override;

    bool didClone_ = false;
};

class DocumentType : public IQuickActionSource {
public:   
    DocumentType(const Urho3D::String& name, const Urho3D::String& openMask);
    
    Urho3D::String name_;
    Urho3D::String openMask_;
    ActionList actions_;

    virtual bool CanCreateNew() const { return true; }
    virtual std::shared_ptr<DocumentBase> NewDocument() = 0;
    virtual std::shared_ptr<DocumentBase> OpenPath(const Urho3D::String& path) = 0;
    virtual bool OpensXML(const Urho3D::String& xmlRootName) { return false; }

    Urho3D::InputBinding* AddAction(Urho3D::SharedPtr<Urho3D::InputBinding>);
    virtual void CollectActions(ActionList&) override;

protected:
    std::shared_ptr<DocumentBase> DoXMLCheck(const Urho3D::String& path);
};

struct DocumentManager
{
    DocumentManager();
    ~DocumentManager();

    std::shared_ptr<DocumentBase> AddDocument(std::shared_ptr<DocumentBase> data);
    bool CloseDocument(std::shared_ptr<DocumentBase> doc);

    void SetActiveDocument(std::shared_ptr<DocumentBase>);
    std::shared_ptr<DocumentBase> GetActiveDocument();

    template<typename T>
    std::shared_ptr<T> GetActiveDoc() {
        //static_assert(std::is_base_of<DocumentBase, T>::value, "T must be a DocumentBase derived type");
        return std::dynamic_pointer_cast<T>(activeDocument_);
    }

    std::vector<std::shared_ptr<DocumentBase> >& GetDocuments() { return documents_; }

    static DocumentManager* Get();
    static void Release() { inst_.reset(); }

    void DoOpenDocument();
    bool OpenPath(const Urho3D::String& path);

    void DrawNewDocumentMenu();

    std::vector<std::shared_ptr<DocumentType> >& GetDocumentTypes() { return types_; }

    std::shared_ptr<DocumentType> GetTypeForXML(const Urho3D::String& xmlName);

private:
    static std::unique_ptr<DocumentManager> inst_;

    std::shared_ptr<DocumentBase> activeDocument_;
    std::vector< std::shared_ptr<DocumentBase> > documents_;
    std::vector< std::shared_ptr<DocumentType> > types_;
};

struct UrhoTransformUndoRedo : public UndoRedo
{
    UrhoTransformUndoRedo(Urho3D::SharedPtr<Urho3D::Node> target, 
        Urho3D::Vector3 oldTrans,
        Urho3D::Quaternion oldQuat,
        Urho3D::Vector3 oldScale,
        Urho3D::Vector3 newTrans,
        Urho3D::Quaternion newQuat,
        Urho3D::Vector3 newScale);

    virtual Urho3D::String GetText() override { return text_; }

    virtual void Execute(bool isUndo, DocumentBase* forDoc) override;
    virtual bool CanMergeWith(UndoRedo* act) const override;
    virtual void Merge(UndoRedo* act) override;

    Urho3D::SharedPtr<Urho3D::Node> target_;
    Urho3D::Vector3 oldTrans_;
    Urho3D::Quaternion oldQuat_;
    Urho3D::Vector3 oldScale_;
    Urho3D::Vector3 newTrans_;
    Urho3D::Quaternion newQuat_;
    Urho3D::Vector3 newScale_;
    Urho3D::String text_;
};
