#include "Urho_Undo.h"

#include <Urho3D/Scene/Component.h>
#include <Urho3D/Scene/Node.h>

#include <Urho3D/Physics/CollisionShape.h>
#include <Urho3D/Physics/Constraint.h>
#include <Urho3D/UI/UIElement.h>

#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include <Urho3D/DebugNew.h>

using namespace Urho3D;

UrhoAttributeUndoRedo::UrhoAttributeUndoRedo(Urho3D::SharedPtr<Urho3D::Serializable> target, unsigned attrIndex, Urho3D::Variant oldVal, Urho3D::Variant newVal)
{
    target_ = target;
    attributeIndex_ = attrIndex;
    oldValue_ = oldVal;
    newValue_ = newVal;
    UpdateText();
}

UrhoAttributeUndoRedo::~UrhoAttributeUndoRedo()
{

}

void UrhoAttributeUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    if (isUndo)
        target_->SetAttribute(attributeIndex_, oldValue_);
    else
        target_->SetAttribute(attributeIndex_, newValue_);

    target_->ApplyAttributes();
    //if (auto colShape = dynamic_cast<CollisionShape*>(target_.Get()))
    //    colShape->NotifyRigidBody();
}

bool UrhoAttributeUndoRedo::CanMergeWith(UndoRedo* rhs) const
{
    if (auto r = dynamic_cast<UrhoAttributeUndoRedo*>(rhs))
    {
        if (r->attributeIndex_ == attributeIndex_ && r->target_ == target_)
            return true;
    }
    return false;
}

void UrhoAttributeUndoRedo::Merge(UndoRedo* rhs)
{
    if (auto r = dynamic_cast<UrhoAttributeUndoRedo*>(rhs))
    {
        newValue_ = r->newValue_;
        UpdateText();
    }
}

void UrhoAttributeUndoRedo::UpdateText()
{
    if (auto node = dynamic_cast<Node*>(target_.Get()))
    {
        if (node->GetName().Empty())
            text_ = ICON_FA_PENCIL_ALT " ^3Node [" + String(node->GetID()) + "]";
        else
            text_ = ICON_FA_PENCIL_ALT " ^3" + node->GetName() + " [" + String(node->GetID()) + "] ";
    }
    else if (auto comp = dynamic_cast<Component*>(target_.Get()))
        text_ = ICON_FA_PENCIL_ALT " ^3" + comp->GetTypeName() + " [" + String(comp->GetID()) + "] ";
    else if (auto serial = dynamic_cast<Object*>(target_.Get()))
        text_ = ICON_FA_PENCIL_ALT " ^3" + serial->GetTypeName() + " ";

    const AttributeInfo& attr = (*target_->GetAttributes())[attributeIndex_];
    text_ += attr.name_ + " to " + newValue_.ToString();
}

UrhoCreateDeleteNodeUndoRedo::UrhoCreateDeleteNodeUndoRedo(Urho3D::SharedPtr<Urho3D::Node> parent, Urho3D::SharedPtr<Urho3D::Node> target, bool isCreate) :
    parent_(parent),
    target_(target),
    isCreate_(isCreate),
    id_(target_->GetID())
{
    if (isCreate_)
    {
        if (parent->GetName().Empty())
            text_ = (ICON_FA_ASTERISK " ^2Add child to " + parent->GetName() + " [" + String(parent->GetID()) + "]");
        else
            text_ = (ICON_FA_ASTERISK " ^2Add child to Node [" + String(parent->GetID()) + "]");
    }
    else
    {
        oldIndex_ = parent->GetChildren().IndexOf(target);
        if (target_->GetName().Empty())
            text_ = (ICON_FA_TRASH " ^1Delete node " + target_->GetName() + " [" + String(parent->GetID()) + "]");
        else
            text_ = (ICON_FA_TRASH " ^1Delete Node [" + String(parent->GetID()) + "]");
    }
}

UrhoCreateDeleteNodeUndoRedo::~UrhoCreateDeleteNodeUndoRedo()
{

}

void UrhoCreateDeleteNodeUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    if (firstRedo_ && isCreate_)
        return;

    if ((isCreate_ && isUndo) || (!isCreate_ && !isUndo))
        parent_->RemoveChild(target_);
    else
    {
        target_->SetID(id_);
        parent_->AddChild(target_, oldIndex_);
    }
}

UrhoCreateDeleteComponentUndoRedo::UrhoCreateDeleteComponentUndoRedo(Urho3D::SharedPtr<Urho3D::Node> parent, Urho3D::SharedPtr<Urho3D::Component> target, bool isCreate) :
    parent_(parent),
    target_(target),
    isCreate_(isCreate)
{
    if (isCreate_)
    {
        if (parent->GetName().Empty())
            text_ = (ICON_FA_ASTERISK " ^2Add component " + target->GetTypeName() + " to " + parent->GetName() + " [" + String(parent->GetID()) + "]");
        else
            text_ = (ICON_FA_ASTERISK " ^2Add child to Node [" + String(parent->GetID()) + "]");
    }
    else
    {
        if (parent->GetName().Empty())
            text_ = (ICON_FA_TRASH " ^1Delete " + target_->GetTypeName() + " from " + parent->GetName() + " [" + String(parent->GetID()) + "]");
        else
            text_ = (ICON_FA_TRASH " ^1Delete " + target_->GetTypeName() + " from Node [" + String(parent->GetID()) + "]");
    }
}

UrhoCreateDeleteComponentUndoRedo::~UrhoCreateDeleteComponentUndoRedo()
{

}

void UrhoCreateDeleteComponentUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    if (firstRedo_ && isCreate_)
        return;

    if ((isCreate_ && isUndo) || (!isCreate_ && !isUndo))
        parent_->RemoveComponent(target_);
    else
        parent_->AddComponent(target_, target_->GetID(), target_->GetID() >= Urho3D::FIRST_LOCAL_ID ? CreateMode::LOCAL : CreateMode::REPLICATED);
}

UrhoMoveNodeUndoRedo::UrhoMoveNodeUndoRedo(Urho3D::SharedPtr<Urho3D::Node> movedNode, Urho3D::SharedPtr<Urho3D::Node> oldParent, Urho3D::SharedPtr<Urho3D::Node> newParent) :
    newParent_(newParent),
    oldParent_(oldParent),
    target_(movedNode)
{
    oldIndex_ = oldParent_->GetChildren().IndexOf(movedNode);
    UpdateText();
}

UrhoMoveNodeUndoRedo::~UrhoMoveNodeUndoRedo()
{

}

void UrhoMoveNodeUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    if (isUndo)
        oldParent_->AddChild(target_, oldIndex_);
    else
        target_->SetParent(newParent_);
}

bool UrhoMoveNodeUndoRedo::CanMergeWith(UndoRedo* rhs) const
{
    if (auto other = dynamic_cast<UrhoMoveNodeUndoRedo*>(rhs))
    {
        if (other->target_ == target_)
            return true;
    }
    return false;
}

void UrhoMoveNodeUndoRedo::Merge(UndoRedo* rhs)
{
    if (auto other = dynamic_cast<UrhoMoveNodeUndoRedo*>(rhs))
        newParent_ = other->newParent_;
    UpdateText();
}

void UrhoMoveNodeUndoRedo::UpdateText()
{
    text_ = (ICON_FA_TREE " ^3Reparent node " + String(target_->GetID()) + " to " + String(newParent_->GetID()));
}

UrhoMoveComponentUndoRedo::UrhoMoveComponentUndoRedo(Urho3D::SharedPtr<Urho3D::Component> movedNode, Urho3D::SharedPtr<Urho3D::Node> oldParent, Urho3D::SharedPtr<Urho3D::Node> newParent) :
    newParent_(newParent),
    oldParent_(oldParent),
    target_(movedNode)
{
    UpdateText();
}

UrhoMoveComponentUndoRedo::~UrhoMoveComponentUndoRedo()
{

}

void UrhoMoveComponentUndoRedo::Execute(bool isUndo, DocumentBase* forDoc)
{
    unsigned id = target_->GetID();
    target_->Remove();
    if (isUndo)
        oldParent_->AddComponent(target_, id, id >= FIRST_LOCAL_ID ? LOCAL : REPLICATED);
    else
        newParent_->AddComponent(target_, id, id >= FIRST_LOCAL_ID ? LOCAL : REPLICATED);
}

bool UrhoMoveComponentUndoRedo::CanMergeWith(UndoRedo* rhs) const
{
    if (auto other = dynamic_cast<UrhoMoveComponentUndoRedo*>(rhs))
    {
        if (other->target_ == target_)
            return true;
    }
    return false;
}

void UrhoMoveComponentUndoRedo::Merge(UndoRedo* rhs)
{
    if (auto other = dynamic_cast<UrhoMoveComponentUndoRedo*>(rhs))
        newParent_ = other->newParent_;
    UpdateText();
}

void UrhoMoveComponentUndoRedo::UpdateText()
{
    text_ = (ICON_FA_TREE " ^3Reparent " + String(target_->GetTypeName()) + " to " + String(newParent_->GetID()));
}
