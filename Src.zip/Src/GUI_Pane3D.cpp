#include "GUI_Pane3D.h"

#include <Urho3D/Core/Context.h>
#include <Urho3D/Input/Input.h>
#include <Urho3D/Graphics/Camera.h>
#include <Urho3D/Graphics/DebugRenderer.h>
#include <Urho3D/Graphics/Octree.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/ImGuizmo.h>
#include <Urho3D/ThirdParty/ImGui/imgui_dock.h>
#include <Urho3D/ThirdParty/ImGui/imgui_internal.h>

#include "DataObject.h"
#include "DocType_Scene.h"
#include "Urho_Util.h"
#include "UX.h"

#include <MathGeoLib\MathGeoLib.h>

#include <Urho3D/DebugNew.h>

extern bool IsShiftDown();

using namespace Urho3D;

UrhoNodeSelectable::UrhoNodeSelectable(Urho3D::Node* n)
{
    node_ = SharedPtr<Node>(n);
}

UrhoNodeSelectable::UrhoNodeSelectable(const Urho3D::SharedPtr<Urho3D::Node>& n) 
{
    node_ = n;
}

UrhoNodeSelectable::UrhoNodeSelectable(const Urho3D::SharedPtr<Urho3D::Scene>& n)
{
    node_ = SharedPtr<Node>(n.Get());
}

UrhoNodeSelectable::~UrhoNodeSelectable()
{
    node_.Reset();
}

bool UrhoNodeSelectable::Is(void* item) const 
{ 
    return node_.Get() == item; 
}

bool UrhoNodeSelectable::Is(std::shared_ptr<Selectable> t) const
{
    if (auto rhs = std::dynamic_pointer_cast<UrhoNodeSelectable>(t))
        return node_ == rhs->node_;
    return false;
}

void UrhoNodeSelectable::AccumulateTransform(std::vector<Urho3D::Matrix3x4>& into, int& idx)
{
    into.push_back(node_->GetWorldTransform());
    ++idx;
}

void UrhoNodeSelectable::ExtractTransform(const Urho3D::Matrix4& ref, const Urho3D::Matrix4& from, int& idx, int mode, bool isReversal)
{
    auto trans = node_->GetWorldTransform();

    Vector3 t, scl, oT, rT, oScl, rScl;
    Quaternion r, oR, rR;
    trans.Decompose(oT, oR, oScl);
    ref.Decompose(rT, rR, rScl);
    from.Decompose(t, r, scl);

    auto quatDiff = rR.Inverse() * r;
    auto sclDiff = oScl + (isReversal ? (rScl - scl) : (scl - rScl));

    if (mode == ImGuizmo::TRANSLATE)
        node_->SetWorldPosition(oT + (isReversal ? rT - t : t - rT));
    else if (mode == ImGuizmo::ROTATE)
    {
        auto newQ = node_->GetParent()->GetWorldRotation().Inverse() * quatDiff;
        node_->SetRotation((node_->GetRotation() * newQ).Normalized());
    }
    else if (mode == ImGuizmo::SCALE && (scl - rScl).Length() > 0.001f)
        node_->SetWorldScale(sclDiff);
}

Urho3D::IntRect BoxSelect3D::GetCleanRect()
{
    return IntRect(Min(box_.left_, box_.right_), Min(box_.top_, box_.bottom_),
        Max(box_.left_, box_.right_), Max(box_.top_, box_.bottom_));
}

void BoxSelect3D::Update(int x, int y)
{
    if (!started_)
    {
        box_.left_ = box_.right_ = x;
        box_.top_ = box_.bottom_ = y;
        started_ = true;
    }
    else
    {
        box_.right_ = x;
        box_.bottom_ = y;
    }
}

Urho3D::Frustum BoxSelect3D::CalculatePlanes(Urho3D::Camera* camera, float w, float h)
{
    auto r = GetCleanRect();

    auto min = r.Min();
    auto max = r.Max();
    
    auto topLeftRay = camera->GetScreenRay(min.x_ / w, min.y_ / h);
    auto topRightRay = camera->GetScreenRay(max.x_ / w, min.y_ / h);
    auto bottomLeftRay = camera->GetScreenRay(min.x_ / w, max.y_ / h);
    auto bottomRightRay = camera->GetScreenRay(max.x_ / w, max.y_ / h);
    auto centroid = camera->GetNode()->GetWorldPosition();

#define RAY_TO_POINT(R) R.origin_ + R.direction_ * 1000

    Urho3D::Frustum ret;
    ret.vertices_[0] = topLeftRay.origin_;
    ret.vertices_[1] = topLeftRay.origin_;
    ret.vertices_[2] = topLeftRay.origin_;
    ret.vertices_[3] = topLeftRay.origin_;
    ret.vertices_[4] = RAY_TO_POINT(topRightRay);
    ret.vertices_[5] = RAY_TO_POINT(bottomRightRay);
    ret.vertices_[6] = RAY_TO_POINT(bottomLeftRay);
    ret.vertices_[7] = RAY_TO_POINT(topLeftRay);
    ret.UpdatePlanes();
    return ret;
}

GUI_View3D::GUI_View3D(SceneDocument::View* v)
{
    view_ = v;
    name_ = Urho3D::String("##renderview_") + Urho3D::String((long long)v);
}

GUI_View3D::~GUI_View3D()
{
    delete view_;
    view_ = nullptr;
}

void GUI_View3D::ActivateDraw()
{
    view_->surface_->GetRenderSurface()->SetUpdateMode(SURFACE_UPDATEALWAYS);
}

void GUI_View3D::DeactivateDraw()
{
    view_->surface_->GetRenderSurface()->SetUpdateMode(SURFACE_MANUALUPDATE);
}

void GUI_View3D::Draw(const Urho3D::IntRect& r)
{
    const float framePad = 4;
    auto xxx = ImGui::GetCurrentWindow()->Rect();
    lastDraw_ = IntRect(xxx.Min.x + framePad*2, xxx.Min.y + framePad,
        xxx.Max.x - framePad * 3, xxx.Max.y - framePad * 3);
    view_->CheckSize(r.Width(), r.Height());

    auto winPos = ImGui::GetWindowPos();
    auto winSize = ImGui::GetWindowSize();

    const bool isActive = IsActive();
    ImGui::SetCursorPos(ImVec2(r.left_, r.top_));

    auto imgSize = ImVec2(r.Width(), r.Height());
    ImGui::Image((ImTextureID)(5000 + view_->viewID_), imgSize);
    auto imgMin = ImGui::GetItemRectMin();
    auto imgMax = ImGui::GetItemRectMax();
    bool imageHovered = ImGui::IsItemHovered();

    auto& sel = view_->doc_->GetSelection();
    auto debugRen = view_->viewport_->GetScene()->GetOrCreateComponent<DebugRenderer>();
    if (!sel.IsEmpty())
    {
        for (size_t i = 0; i < sel.size(); ++i)
        {
            if (auto selNode = sel.Get<UrhoNodeSelectable>(i))
            {
                auto comps = selNode->node_->GetComponents();
                for (size_t i = 0; i < comps.Size(); ++i)
                    comps[i]->DrawDebugGeometry(debugRen, true);
                debugRen->AddNode(selNode->node_);
            }
            else if (auto selComp = sel.Get<UrhoComponentSelectable>(i))
            {
                selComp->component_->DrawDebugGeometry(debugRen, true);
            }
        }
    }

    bool wasHovered = false;
    if (imageHovered)
    {
        wasHovered = true;
        if (ImGui::IsMouseDown(1))
        {
            Activate();
            MouseCapture::Capture(this, Urho3D::MOUSEB_RIGHT);
        }
    }

    if (IsActive())
    {
        if (imageHovered && MouseCapture::Get()->GetActive() == nullptr)
            ProcessKeyboardInput(1.5f);

        // use mouse wheel to zoom in/out
        if (imageHovered && ImGui::GetIO().MouseWheel != 0)
        {
            float delta = ImGui::GetIO().MouseWheel;
            if (IsShiftDown())
                delta *= 10;
            view_->cameraNode_->SetWorldPosition(view_->cameraNode_->GetWorldPosition() + view_->cameraNode_->GetWorldDirection() * delta);
        }

        ImGui::GetWindowDrawList()->AddRect(
            imgMin,
            imgMax,
            ImColor(ImVec4(100/255.0f, 149/255.0f, 237/255.0f, 1)), 2.0f, 15, 3);
    }
}

void GUI_View3D::ProcessKeyboardInput(float val)
{
    static Vector3 MotionAxesFORE[] = {
        Vector3(0,0,0),     //VNS_Free,
        Vector3(0,-1,0),    //VNS_Front,
        Vector3(0,1,0),     //VNS_Back, //2D
        Vector3(0,0,-1),    //VNS_Top,
        Vector3(0,1,0),     //VNS_Right,
        Vector3(0,1,0)      //VNS_Left
    };
    static Vector3 MotionAxesRIGHT[] = {
        Vector3(0,0,0),     //VNS_Free,
        Vector3(1,0,0),     //VNS_Front,
        Vector3(0,0,0),     //VNS_Back, //2D
        Vector3(1,0,0),     //VNS_Top,
        Vector3(1,0,0),     //VNS_Right,
        Vector3(-1,0,0)     //VNS_Left
    };

    if (IsActive())
    {
        float dt = ImGui::GetIO().DeltaTime * val;
        auto input = view_->cameraNode_->GetSubsystem<Input>();
        Vector3 moveDelta = Vector3();
        if (input->GetKeyDown(KEY_W))
            moveDelta += view_->cameraNode_->GetDirection() * dt;
        else if (input->GetKeyDown(KEY_S))
            moveDelta -= view_->cameraNode_->GetDirection() * dt;
        if (input->GetKeyDown(KEY_A))
            moveDelta -= view_->cameraNode_->GetRight() * dt;
        else if (input->GetKeyDown(KEY_D))
            moveDelta += view_->cameraNode_->GetRight() * dt;
        if (input->GetKeyDown(KEY_E))
            moveDelta.y_ += dt;
        else if (input->GetKeyDown(KEY_C))
            moveDelta.y_ -= dt;

        moveDelta *= 10.0f;
        if (IsShiftDown())
            moveDelta *= 10.0f;

        if (moveDelta.LengthSquared() > 0)
        {
            ImGui::GetCurrentContext()->ActiveId = -1;
            view_->cameraNode_->SetWorldPosition(view_->cameraNode_->GetWorldPosition() + moveDelta);
        }
    }
}

bool GUI_View3D::ProcessCapture(const Urho3D::IntVector2& pos, const Urho3D::IntVector2& delta)
{
    auto input = view_->cameraNode_->GetSubsystem<Input>();

    if (input->GetMouseButtonDown(2))
    {
        Vector3 moveDelta = view_->cameraNode_->GetWorldRight() * delta.x_ * -0.1f + view_->cameraNode_->GetWorldUp() * delta.y_ * 0.1f;
        view_->cameraNode_->SetWorldPosition(view_->cameraNode_->GetWorldPosition() + moveDelta);
    }
    else
    {
        extern bool IsCtrlDown();
        extern std::unique_ptr<DataObject> viewportSettings_;

        bool orbitMode = viewportSettings_->GetField("Default Mouse Orbit").GetBool();
        if (IsCtrlDown())
            orbitMode = !orbitMode;
        float yAxisMultiplier = viewportSettings_->GetField("Invert Orbit Y Axis").GetBool() ? 1.0f : -1.0f;

        if (orbitMode)
        {
            auto center = GetSelectionCentroid();
            auto camPos = view_->cameraNode_->GetWorldPosition();
            const float camDist = (camPos - center).Length();
            float distMultiplier = camDist / 20.0f;
            camPos += (view_->cameraNode_->GetWorldRight() * delta.x_ * -0.2f * distMultiplier) + (view_->cameraNode_->GetWorldUp() * delta.y_ * 0.2f * yAxisMultiplier * distMultiplier);
            auto camVec = (camPos - center);

            view_->cameraNode_->SetWorldPosition(center + camVec.Normalized() * camDist);
            view_->cameraNode_->LookAt(center);
        }
        else
        {
            auto dir = view_->cameraNode_->GetWorldRotation();
            float yaw = dir.YawAngle();
            float pitch = dir.PitchAngle();

            yaw += delta.x_ * 0.2f;
            pitch += delta.y_ * 0.2f;
            pitch = Urho3D::Clamp<float>(pitch, -83, 83);

            auto quat = Quaternion(yaw, Vector3::UP) * Quaternion(pitch, Vector3::RIGHT);
            view_->cameraNode_->SetWorldRotation(quat);
        }        
    }

    return true;
}

bool GUI_View3D::ProcessKeys()
{
    ProcessKeyboardInput(1.0f);
    return true;
}

extern bool IsAltDown();
bool GUI_View3D::CheckBoxSelect(float px, float py, bool isOver)
{
    if (!isOver && isBoxSelecting_)
        isBoxSelecting_ = false;

    if (isBoxSelecting_)
    {
        if (!IsAltDown() || !ImGui::IsMouseDown(0))
        {
            DoBoxSelect(boxSelector_.CalculatePlanes(view_->cameraNode_->GetOrCreateComponent<Camera>(), view_->surface_->GetWidth(), view_->surface_->GetHeight()));
            boxSelector_.started_ = false;
            isBoxSelecting_ = false;
            return true;
        }

        auto mousePos = ImGui::GetMousePos();
        boxSelector_.Update(mousePos.x - px, mousePos.y - py);

        auto r = boxSelector_.GetCleanRect();
        ImGui::GetWindowDrawList()->AddRectFilled(
            ImVec2(px + r.left_, py + r.top_), ImVec2(px + r.right_, py + r.bottom_),
            ImColor(40, 40, 255, 64)
        );
        ImGui::GetWindowDrawList()->AddRect(
            ImVec2(px + r.left_, py + r.top_), ImVec2(px + r.right_, py + r.bottom_),
            ImColor(40, 40, 255, 255)
        );
        return true;
    }
    else
    {
        if (IsAltDown() && ImGui::IsMouseDown(0))
        {
            auto mousePos = ImGui::GetMousePos();
            boxSelector_.Update(mousePos.x - px, mousePos.y - py);
            isBoxSelecting_ = true;
            return true;
        }
    }
    return false;
}
