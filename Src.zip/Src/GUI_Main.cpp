#include "GUI_Main.h"

#include <Urho3D/Resource/ResourceCache.h>
#include <Urho3D/Core/Context.h>
#include <Urho3D/Scene/Component.h>
#include <Urho3D/UI/ImGuiElement.h>
#include <Urho3D/Input/InputEvents.h>
#include <Urho3D/Input/Input.h>
#include <Urho3D/IO/IOEvents.h>
#include <Urho3D/IO/Log.h>
#include <Urho3D/Math/Rect.h>
#include <Urho3D/IO/FileSystem.h>
#include <Urho3D/Graphics/Graphics.h>
#include <Urho3D/Core/Profiler.h>
#include <Urho3D/Graphics/Shader.h>
#include <Urho3D/Graphics/ShaderPrecache.h>
#include <Urho3D/Graphics/ShaderVariation.h>
#include <Urho3D/Audio/Sound.h>
#include <Urho3D/Audio/SoundSource.h>
#include <Urho3D/Core/Variant.h>

#include <Urho3D/ThirdParty/ImGui/imgui.h>
#include <Urho3D/ThirdParty/ImGui/imgui_dock.h>
#include <Urho3D/ThirdParty/ImGui/imgui_ext.h>
#include <Urho3D/ThirdParty/ImGui/imgui_internal.h>
#include <Urho3D/ThirdParty/ImGui/imgui_tabs.h>
#include <Urho3D/ThirdParty/ImGui/ImSequencer.h>
#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include "BitNames.h"
#include "Block.h"
#include "DataObject.h"
#include "GUI_Pane3D.h"
#include "Doc_DocumentManager.h"
#include "Doc_SelectableAction.h"
#include "OS_Thumbnail.h"

#include "DocType_Material.h"
#include "DocType_Particle.h"
#include "DocType_Scene.h"
#include "Scripting.h"
#include "Urho_AttrEdit.h"
#include "Urho_Undo.h"
#include "Urho_Util.h"
#include "UX.h"

#include "TL_ObjectAnimation.h"

#include <algorithm>
#include <map>
#include <iterator>
#include <set>
#include <typeinfo>

#include <Urho3D/DebugNew.h>

#define FILTER_TEXT ICON_FA_FILTER " Filter"

#define PANE_THRESHOLD 4.0f

#ifdef URHO3D_PROFILING
#define PROFILE(name) Urho3D::AutoProfileBlock profile_ ## name (BlockExe::GetInst()->GetSubsystem<Urho3D::Profiler>(), #name)
#else
#define PROFILE(name)
#endif

GUI_PaneView* GUI_PaneView::activeView_ = nullptr;

inline ImVec2 Add(const ImVec2& lhs, const ImVec2& rhs)
{
    return{ lhs.x + rhs.x, lhs.y + rhs.y };
}

inline ImVec2 Mul(const ImVec2& lhs, const ImVec2& rhs)
{
    return{ lhs.x * rhs.x, lhs.y * rhs.y };
}

inline ImVec2 Sub(const ImVec2& lhs, const ImVec2& rhs)
{
    return{ lhs.x - rhs.x, lhs.y - rhs.y };
}

ImVec2 ImGui_CursorDrawPos(bool withScrollOffset)
{
    auto winPos = ImGui::GetWindowPos();
    auto cPos = ImGui::GetCursorPos();
    if (withScrollOffset)
    {
        float scrollOffsetX = ImGui::GetScrollX();
        float scrollOffsetY = ImGui::GetScrollY();
        return ImVec2(cPos.x + winPos.x - scrollOffsetX, cPos.y + winPos.y - scrollOffsetY);
    }
    return ImVec2(cPos.x + winPos.x, cPos.y + winPos.y);
}

bool DrawSplitter(const char* id, int split_vertically, float thickness, float* size0, float* size1, float min_size0, float min_size1)
{
    ImVec2 backup_pos = ImGui::GetCursorPos();
    if (split_vertically)
        ImGui::SetCursorPosY(backup_pos.y + *size0);
    else if (*size0 > PANE_THRESHOLD)
        ImGui::SetCursorPosX(backup_pos.x + *size0);
    else
        ImGui::SetCursorPosX(backup_pos.x);

    ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
    ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.6f, 0.6f, 1.0f, 0.5f));          // We don't draw while active/pressed because as we move the panes the splitter button will be 1 frame late
    ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.6f, 0.6f, 1.0f, 0.7f));
    ImGui::Button(id, ImVec2(!split_vertically ? thickness : -1.0f, split_vertically ? thickness : -1.0f));
    ImGui::PopStyleColor(3);

    //ImGui::SetItemAllowOverlap(); // This is to allow having other buttons OVER our splitter.

    if (ImGui::IsItemHovered() || ImGui::IsItemActive())
        ImGui::SetMouseCursor(split_vertically ? ImGuiMouseCursor_ResizeNS : ImGuiMouseCursor_ResizeEW);

    if (ImGui::IsItemClicked() && ImGui::IsMouseDoubleClicked(0))
    {
        if (*size0 > PANE_THRESHOLD)
        {
            *size0 = 0.0f;
            *size1 = 400.0f + 800.0f;
        }
        else
        {
            *size0 = 400.0f;
            *size1 = 800.0f;
        }
    }
    else if (ImGui::IsItemActive())
    {
        float mouse_delta = split_vertically ? ImGui::GetIO().MouseDelta.y : ImGui::GetIO().MouseDelta.x;

        // Minimum pane size
        if (mouse_delta < min_size0 - *size0)
            mouse_delta = min_size0 - *size0;
        if (mouse_delta > *size1 - min_size1)
            mouse_delta = *size1 - min_size1;

        if (*size0 <= 0.0f && mouse_delta < 0)
            mouse_delta = 0;

        // Apply resize
        *size0 += mouse_delta;
        *size1 -= mouse_delta;
        if (*size0 < min_size0)
        {
            *size1 += -(*size0);
            *size0 = 0.0f;
        }
        ImGui::SetCursorPos(backup_pos);
        return true;
    }
    ImGui::SetCursorPos(backup_pos);
    return false;
}

GUI_ViewManager::~GUI_ViewManager()
{
    for (auto v : topViews_)
        delete v;
    for (auto v : bottomViews_)
        delete v;
    topViews_.clear();
    bottomViews_.clear();
}

GUI_PaneView* GUI_ViewManager::GetActiveView() const
{
    for (auto v : topViews_)
        if (v->IsActive())
            return v;
    for (auto v : bottomViews_)
        if (v->IsActive())
            return v;
    return 0x0;
}

void GUI_ViewManager::Draw(const Urho3D::IntRect&)
{
    PROFILE(ViewManager_DrawViewports);
    ImGui::BeginDock("##viewports", 0, ImGuiWindowFlags_NoScrollbar, ImGuiDockFlags_NoTabs | ImGuiDockFlags_NoPad);
    auto pad = ImGui::GetStyle().WindowPadding;
    auto p = ImGui::GetWindowPos();
    auto s = ImGui::GetWindowSize();
    IntRect viewRect(p.x, p.y, p.x + s.x, p.y + s.y);
    if (verticalOrientation_)
    {
        Urho3D::IntRect upperRect(viewRect);
        Urho3D::IntRect lowerRect(viewRect);

        if (!topViews_.empty() && !bottomViews_.empty())
        {
            upperRect.bottom_ -= upperRect.Height()*0.5f;
            lowerRect.top_ += lowerRect.Height()*0.5f;
            lowerRect.bottom_ -= pad.y * 0.5f;
        }

        static const auto ViewRender = [](const Urho3D::IntRect& viewRect, Urho3D::IntRect r, std::vector<GUI_PaneView*>& views, float pad) {
            const float halfPad = pad * 0.5f;

            r.left_ += pad*2;
            r.top_ += halfPad;
            r.bottom_ -= halfPad;

            float unit = (r.Width() - (pad*views.size() - 1)) / views.size();

            for (size_t i = 0; i < views.size(); ++i)
            {
                Urho3D::IntRect sizeRect(r);
                sizeRect.left_ += unit * i + pad * i;
                sizeRect.right_ = sizeRect.left_ + unit;
                sizeRect.left_ -= viewRect.left_;
                sizeRect.right_ -= viewRect.left_;
                sizeRect.bottom_ -= viewRect.top_;
                sizeRect.top_ -= viewRect.top_;
                views[i]->Draw(sizeRect);
            }
        };

        ViewRender(viewRect, upperRect, topViews_, pad.x);
        ViewRender(viewRect, lowerRect, bottomViews_, pad.x);
    }
    else
    {
        Urho3D::IntRect leftRect(viewRect);
        Urho3D::IntRect rightRect(viewRect);

        if (!topViews_.empty() && !bottomViews_.empty())
        {
            leftRect.right_ -= leftRect.Width()*0.5f;
            leftRect.left_ += pad.x;
            leftRect.right_ -= pad.x * 0.5f;
            rightRect.left_ += rightRect.Width()*0.5f;
            rightRect.left_ += pad.x * 0.5f;
            rightRect.right_ -= pad.x * 0.5f;
        }
        else {
            leftRect.left_ += pad.x;
            leftRect.right_ -= pad.x;
            rightRect.left_ += pad.x;
            rightRect.right_ -= pad.x;
        }

        static const auto ViewRender = [](const Urho3D::IntRect& viewRect, Urho3D::IntRect r, std::vector<GUI_PaneView*>& views, float pad) {
            const float halfPad = pad * 0.5f;
            r.top_ += halfPad;

            float unit = (r.Height() - (pad*views.size() - 1)) / views.size();

            for (size_t i = 0; i < views.size(); ++i)
            {
                Urho3D::IntRect sizeRect(r);
                sizeRect.top_ += unit * i + pad*i;
                sizeRect.bottom_ = sizeRect.top_ + unit;
                sizeRect.left_ -= viewRect.left_;
                sizeRect.right_ -= viewRect.left_;
                sizeRect.bottom_ -= viewRect.top_;
                sizeRect.top_ -= viewRect.top_;
                views[i]->Draw(sizeRect);
            }
        };

        ViewRender(viewRect, leftRect, topViews_, pad.y);
        ViewRender(viewRect, rightRect, bottomViews_, pad.y);
    }
    ImGui::EndDock();
}

void GUI_ViewManager::Activate()
{
    for (auto v : topViews_)
        v->ActivateDraw();
    for (auto v : bottomViews_)
        v->ActivateDraw();
}

void GUI_ViewManager::Deactivate()
{
    for (auto v : topViews_)
        v->DeactivateDraw();
    for (auto v : bottomViews_)
        v->DeactivateDraw();
}

GUI_PaneView* GUI_ViewManager::GetFirstView()
{
    if (leftView_) return leftView_;
    if (rightView_) return rightView_;
    if (topViews_.size())
        return topViews_.front();
    if (bottomViews_.size())
        return bottomViews_.front();
    return nullptr;
}

GUI_MainHub::~GUI_MainHub()
{
    for (GUI_DockView* d : docks_)
        delete d;
}

void GUI_MainHub::SaveXML()
{
    auto ctx = BlockExe::GetInst()->GetContext();
    auto fs = ctx->GetSubsystem<FileSystem>();
    XMLFile file(ctx);
    auto root = file.CreateRoot("visibility");
    for (auto dock : docks_)
    {
        auto d = root.CreateChild("dock");
        d.SetAttribute("name", dock->title_.c_str());
        d.SetBool("open", dock->visible_);
    }
    file.SaveFile(fs->GetAppPreferencesDir("urho3d", "blocks") + "docks.xml");
}
void GUI_MainHub::LoadXML()
{
    auto ctx = BlockExe::GetInst()->GetContext();
    auto fs = ctx->GetSubsystem<FileSystem>();
    XMLFile file(ctx);
    if (file.LoadFile(fs->GetAppPreferencesDir("urho3d", "blocks") + "docks.xml"))
    {
        auto node = file.GetRoot().GetChild("dock");
        while (node.NotNull())
        {
            auto dockName = node.GetAttributeCString("name");
            bool vis = node.GetBool("open");

            for (auto dock : docks_)
            {
                auto typeName = dock->title_.c_str();
                if (strcmp(typeName, dockName) == 0)
                {
                    dock->visible_ = vis;
                    break;
                }
            }

            node = node.GetNext("dock");
        }
    }
}

float GUI_MainHub::DrawDocumentTabs()
{
    DocumentManager* docMan = DocumentManager::Get();
    ImGui::SetCursorPosY(5);
    ImGui::SetCursorPosX(0);
    ImGui::BeginTabBar("##document_tabs");
    for (size_t i = 0; i < docMan->GetDocuments().size(); ++i)
    {
        auto doc = docMan->GetDocuments()[i];
        ImGui::PushID(doc.get());

        bool tabOpen = true;
        int flags = 0;
        if (doc->IsDirty())
            flags |= ImGuiTabItemFlags_UnsavedDocument;

        auto tabColor = ImColor(doc->GetTabColor()).Value;
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered, tabColor);
        tabColor.x *= 0.75f; tabColor.y *= 0.75f; tabColor.z *= 0.75f;
        ImGui::PushStyleColor(ImGuiCol_HeaderActive, tabColor);
        tabColor.x *= 0.75f; tabColor.y *= 0.75f; tabColor.z *= 0.75f;
        ImGui::PushStyleColor(ImGuiCol_Header, tabColor);

        if (ImGui::TabItem(doc->GetName().c_str(), &tabOpen, flags) && doc != docMan->GetActiveDocument())
            docMan->SetActiveDocument(doc);
        ImGui::PopStyleColor(3);

        if (!tabOpen)
        {
            if (docMan->CloseDocument(doc))
                --i;
        }
        ImGui::PopID();
    }
    ImGui::EndTabBar();
    auto tabSize = ImGui::GetWindowSize();
    return tabSize.y;
}

void GUI_MainHub::InitializeDockActions()
{
    auto input = BlockExe::GetInst()->GetSubsystem<Input>();
    for (auto& dock : docks_)
    {
        SharedPtr<InputBinding> binding;
        binding = new AppAction("Windows", dock->title_.c_str(), "Toggle panel visibility", [=]() { dock->visible_ = !dock->visible_; });
        input->AddInputBinding(binding);
    }
}

float GUI_MainHub::DrawMasterBar()
{
    DocumentManager* docMan = DocumentManager::Get();
    ImGuiUX::PushLargeBold();

    ImGui::SetCursorPosY(40);

    ImGuiUX::MenuButton(ICON_FA_FILE, "#main_menu_new", "File");
    //ImGui::SameLine();

    if (docMan->GetActiveDocument())
        docMan->GetActiveDocument()->DrawMasterButtons();

    ImGuiUX::MenuButton(ICON_FA_COGS, "#main_menu_win", "Windows & Settings");
    //ImGui::SameLine();

    if (ImGui::BeginPopup("#main_menu_new", ImGuiWindowFlags_ChildMenu))
    {
        if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
            ImGui::CloseCurrentPopup();

        if (ImGui::BeginMenu(ICON_FA_FILE " New"))
        {
            DocumentManager::Get()->DrawNewDocumentMenu();
            ImGui::EndMenu();
        }

        if (ImGui::MenuItem(ICON_FA_FOLDER_OPEN " Open"))
            docMan->DoOpenDocument();

        ImGui::Separator();
        if (ImGui::MenuItem(ICON_FA_SAVE " Save") && docMan->GetActiveDocument())
            docMan->GetActiveDocument()->Save();
        if (ImGui::MenuItem(ICON_FA_SAVE " Save as...") && docMan->GetActiveDocument())
            docMan->GetActiveDocument()->SaveAs();

        ImGui::Separator();
        if (ImGui::MenuItem(ICON_FA_WINDOW_CLOSE " Exit"))
            BlockExe::GetInst()->GetContext()->GetEventSender()->SendEvent(Urho3D::E_EXITREQUESTED);
        ImGui::EndPopup();
    }

    if (ImGui::BeginPopup("#main_menu_win", ImGuiWindowFlags_ChildMenu))
    {
        if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
            ImGui::CloseCurrentPopup();

        for (auto dock : docks_)
        {
            if (ImGui::MenuItem(dock->title_.c_str(), 0x0, dock->visible_))
                dock->visible_ = !dock->visible_;
        }
        ImGui::Separator();
        if (ImGui::MenuItem(ICON_FA_COGS " Viewport Settings"))
            ModalWindows::Get()->PushModal(ModalWindow{ ICON_FA_COGS " Viewport Settings", ViewportSettingsDialog });
        if (ImGui::MenuItem(ICON_FA_COGS " Editor Settings"))
            ModalWindows::Get()->PushModal(ModalWindow{ ICON_FA_COGS " Editor Settings", EditorSettingsDialog });
        if (ImGui::MenuItem(ICON_FA_ARROWS_ALT " Manipulator Settings"))
            ModalWindows::Get()->PushModal(ModalWindow(ICON_FA_ARROWS_ALT " Manipulator Settings", ManipulatorSettingsDialog));
        if (ImGui::MenuItem(ICON_FA_CHECK_SQUARE " Bitmask Names"))
            ModalWindows::Get()->PushModal(ModalWindow(ICON_FA_CHECK_SQUARE " Bitmask Names", []() -> bool { BlockExe::GetInst()->GetBitNames()->DrawEditor(); return true; }));
        if (ImGui::MenuItem(ICON_FA_KEYBOARD " Shortcuts"))
            ModalWindows::Get()->PushTool(ModalWindow(ICON_FA_KEYBOARD " Shortcuts", []() -> bool { DrawInputBindings(); return true; }));

        ImGui::EndPopup();
    }

    //ImGui::SameLine();

    ScriptPluginMenuRecord::DrawScriptingPluginsMenu();

    ImGui::PopFont();

    return 32.0f;
}

void GUI_MainHub::Draw(const Urho3D::IntRect& guiRect)
{
    auto docMan = DocumentManager::Get();
    
    ImGui::SetNextWindowPos(ImVec2(0, 0));
    ImGui::SetNextWindowSize(ImVec2(ImGui::GetIO().DisplaySize.x, 0));
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(2, 2));
    
    const int coreFlags = ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove |
        ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoSavedSettings |
        ImGuiWindowFlags_NoBringToFrontOnFocus;

    ImGui::PushStyleColor(ImGuiCol_WindowBg, ImVec4(0.1f, 0.1f, 0.1f, 1));
    ImGui::Begin("ContentTabs", nullptr, ImVec2(0, 0), -1, coreFlags);
    const float tabHeight = DrawDocumentTabs();
    ImGui::End();

    ImGui::SetNextWindowSize(ImVec2(40, guiRect.Height()));
    ImGui::Begin("ContentButtons", nullptr, ImVec2(0, 0), -1, coreFlags);
    DrawMasterBar();
    ImGui::End();
    ImGui::PopStyleColor();
    ImGui::PopStyleVar();

    auto r = guiRect;
    r.top_ += tabHeight;
    r.left_ += 40;

    //ImGui::Begin("Content", nullptr, ImVec2(0, 0), 0.0f, coreFlags);

    ImGui::RootDock(ImVec2(r.left_, r.top_), ImVec2(r.Width(), r.Height()));

    if (docMan->GetActiveDocument())
    {
        docMan->GetActiveDocument()->PreDraw();
        docMan->GetActiveDocument()->GetViewManager()->Draw(r);
    }
    else
    {
        PROFILE(ViewManager_DrawViewports);
        ImGui::BeginDock("##viewports", 0, 0, ImGuiDockFlags_NoTabs | ImGuiDockFlags_NoPad);
        ImGui::EndDock();
    }

    for (auto d : docks_)
        d->Draw();
}

GUI_ProfilerView::GUI_ProfilerView() : GUI_DockView(ICON_FA_CLOCK " Profiler") 
{ 
}

void GUI_ProfilerView::Draw()
{
    PROFILE(GUI_Profiler);
    if (ImGui::BeginDock(title_.c_str(), &visible_))
        BlockExe::GetInst()->GetImGuiElem()->ShowProfiler();
    ImGui::EndDock();
}

GUI_ResourceView::GUI_ResourceView() : GUI_DockView(ICON_FA_ADDRESS_BOOK " Resource View")
{

}

void GUI_ResourceView::Draw()
{
    PROFILE(GUI_ResourceView);
    if (ImGui::BeginDock(title_.c_str(), &visible_))
        BlockExe::GetInst()->GetImGuiElem()->ShowResources();
    ImGui::EndDock();
}

GUI_PropertiesView::GUI_PropertiesView() : GUI_DockView(ICON_FA_LIST " Properties")
{

}

GUI_PropertiesView::~GUI_PropertiesView()
{

}

void GUI_PropertiesView::Draw()
{
    static ImGuiTextFilter filter;
    
    PROFILE(GUI_Properties);
    if (ImGui::BeginDock(title_.c_str(), &visible_, ImGuiWindowFlags_MenuBar))
    {
        ImGui::BeginMenuBar();
        filter.Draw(FILTER_TEXT);
        ImGui::EndMenuBar();

        if (auto doc = DocumentManager::Get()->GetActiveDocument())
        {
            if (auto sel = doc->GetSelection().MostRecent<UrhoNodeSelectable>())
            {
                ImGuiUX::PushBold();
                if (sel->node_->GetID() < FIRST_LOCAL_ID)
                    ImGui::Text("Replicated Node: %u", sel->node_->GetID());
                else
                    ImGui::Text("Local Node: %u", sel->node_->GetID());
                ImGui::PopFont();
                ShowSerializableEditor(sel->node_.Get(), &doc->GetUndoStack(), &filter);

                auto comps = sel->node_->GetComponents();
                auto defFont = ImGui::GetFont();
                auto boldFont = ImGui::GetIO().Fonts->Fonts[3];
                if (!comps.Empty())
                {
                    auto comps = sel->node_->GetComponents();
                    //ImGui::Indent();
                    for (size_t ci = 0; ci < comps.Size(); ++ci)
                    {
                        ImGui::Separator();
                        auto comp = comps[ci];
                        ImGui::PushID(comp.Get());
                        bool open = true;
                        auto typeName = comp->GetTypeName();
                        auto labelFreeTypeName = "##" + typeName;
                        ImGui::PushFont(boldFont);
                        int extraFlags = 0;
                        extern std::unique_ptr<DataObject> editorSettings_;
                        if (editorSettings_->GetField("Default Components Open").GetBool())
                            extraFlags = ImGuiTreeNodeFlags_DefaultOpen;
                        bool treeVis = ImGui::TreeNodeEx(labelFreeTypeName.CString(), ImGuiTreeNodeFlags_AllowOverlapMode | extraFlags);
                        ImGui::SameLine();
                        auto texSize = GetEditorIconUV(comp->GetTypeName());
                        ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(24, 24), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w));
                        ImGui::SameLine();
                        bool isEnabled = comp->IsEnabled();
                        if (ImGui::Checkbox(typeName.CString(), &isEnabled))
                            comp->SetEnabled(isEnabled);
                        ImGui::SameLine();

                        ImGui::SetCursorPosX(ImGui::GetWindowContentRegionWidth() - 24);
                        if (ImGui::Button(ICON_FA_COG, ImVec2(32, 32)))
                            ImGui::OpenPopup("component_options");
                        if (ImGui::BeginPopup("component_options"))
                        {
                            static StringHash COMPONENT_OPTIONS("COMPONENT_OPTIONS");
                            static StringHash typeID("TypeHash");
                            static StringHash compValue("Component");
                            if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
                                ImGui::CloseCurrentPopup();

                            if (ImGui::MenuItem(ICON_FA_TRASH " Delete"))
                                open = false;
                            if (ImGui::MenuItem(ICON_FA_SYNC " Reset"))
                                comp->ResetToDefault();

                            auto& dataMap = doc->GetEventDataMap();
                            dataMap[typeID] = comp->GetType();
                            dataMap[compValue] = comp;
                            doc->SendEvent(COMPONENT_OPTIONS, dataMap);

                            ImGui::EndPopup();
                        }

                        if (treeVis)
                        {
                            ImGui::PopFont();
                            auto blockStart = ImGui_CursorDrawPos(true);

                            ImGui::Indent();
                            if (ScriptPropertyPage::CanHandle(comp.Get()))
                            {
                                if (ScriptPropertyPage::HasExtension(comp.Get()))
                                {
                                    ShowSerializableEditor(comp.Get(), &doc->GetUndoStack(), &filter);
                                    ScriptPropertyPage::CheckAndDrawPropertyPage(comp, &filter);
                                }
                                else
                                    ScriptPropertyPage::CheckAndDrawPropertyPage(comp, &filter);
                            }
                            else
                                ShowSerializableEditor(comp.Get(), &doc->GetUndoStack(), &filter);
                            ImGui::Unindent();

                            auto blockEnd = ImGui_CursorDrawPos(true);

                            ImGui::GetWindowDrawList()->AddRectFilled(
                                ImVec2(blockStart.x + 1, blockStart.y - 4),
                                ImVec2(blockEnd.x + 10, blockEnd.y),
                                (ImColor)ImGui::GetStyleColorVec4(ImGuiCol_Header)
                            );
                            ImGui::TreePop();
                        }
                        else
                            ImGui::PopFont();

                        if (!open)
                        {
                            SelectionList oldSelection = doc->GetSelection();
                            sel->node_->RemoveComponent(comp);
                            doc->GetSelection().Deselect(comp.Get());
                            SelectionList newSelection = doc->GetSelection();
                            if (auto doc = DocumentManager::Get()->GetActiveDocument())
                                doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteComponentUndoRedo>(SharedPtr<Node>(sel->node_), SharedPtr<Component>(comp), false))->AttachSelectables(oldSelection, newSelection);
                        }
                        ImGui::PopID();
                    }
                }

                ShowCreateComponentButton(sel->node_);
            }
            else if (auto selC = doc->GetSelection().MostRecent<UrhoComponentSelectable>())
            {
                if (ScriptPropertyPage::CanHandle(selC->component_))
                {
                    if (ScriptPropertyPage::HasExtension(selC->component_))
                    {
                        ShowSerializableEditor(selC->component_.Get(), &doc->GetUndoStack(), &filter);
                        ScriptPropertyPage::CheckAndDrawPropertyPage(selC->component_, &filter);
                    }
                    else
                        ScriptPropertyPage::CheckAndDrawPropertyPage(selC->component_, &filter);
                }
                else
                    ShowSerializableEditor(selC->component_.Get(), &doc->GetUndoStack(), &filter);
            }
            else if (auto selR = doc->GetSelection().MostRecent<UrhoResourceSelectable>())
            {
                ScriptPropertyPage::CheckAndDrawPropertyPage(selR->resource_, &filter);
            }
            else if (auto selUI = doc->GetSelection().MostRecent<UrhoUISelectable>())
            {
                if (ScriptPropertyPage::CanHandle(selUI->element_))
                {
                    if (ScriptPropertyPage::HasExtension(selUI->element_))
                    {
                        ShowSerializableEditor(selUI->element_.Get(), &doc->GetUndoStack(), &filter);
                        ScriptPropertyPage::CheckAndDrawPropertyPage(selUI->element_, &filter);
                    }
                    else
                        ScriptPropertyPage::CheckAndDrawPropertyPage(selC->component_, &filter);
                }
                else
                    ShowSerializableEditor(selUI->element_.Get(), &doc->GetUndoStack(), &filter);
            }
            else if (auto dataObject = doc->GetSelection().MostRecent<DataObjectSelectable>())
            {
                dataObject->DrawProperties(&filter);
            }
            else if (auto doc = DocumentManager::Get()->GetActiveDoc<IPropertyDocument>())
            {
                doc->DrawProperties(&filter);
            }
        }
    }
    ImGui::EndDock();
}

Urho3D::Component* GUI_PropertiesView::DoCreateComponentMenu(Urho3D::SharedPtr<Urho3D::Node> node)
{
    auto doc = DocumentManager::Get()->GetActiveDocument();

    Urho3D::Component* newComp = 0x0;
    auto ctx = node->GetContext();
    auto categories = ctx->GetObjectCategories();
    ImGuiUX::CheckAutoSeparator();
    for (auto cat : categories)
    {
        if (cat.first_ == "UI")
            continue;

        if (ImGui::BeginMenu(cat.first_.CString()))
        {
            auto cont = cat.second_;
            for (auto ci : cont)
            {
                auto factory = ctx->GetObjectFactories()[ci]->Get();
                if (factory)
                {
                    auto name = factory->GetTypeName();

                    auto texSize = GetEditorIconUV(name);
                    ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(20, 20), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w));
                    ImGui::SameLine();
                    if (ImGui::MenuItem(name.CString()))
                    {
                        SelectionList oldSelection = doc->GetSelection();
                        newComp = node->CreateComponent(factory->GetType());
                        doc->GetSelection().Select(std::make_shared<UrhoComponentSelectable>(newComp));
                        SelectionList newSelection = doc->GetSelection();
                        if (doc)
                            doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteComponentUndoRedo>(SharedPtr<Node>(node), SharedPtr<Component>(newComp), true))->AttachSelectables(oldSelection, newSelection);
                    }
                }
            }
            ImGui::EndMenu();
        }

    }
    return newComp;
}

void GUI_PropertiesView::ShowCreateComponentButton(Urho3D::SharedPtr<Urho3D::Node> node)
{
    static bool showingCreate = false;

    ImGui::PushID(node.Get());
    auto defFont = ImGui::GetFont();
    auto boldFont = ImGui::GetIO().Fonts->Fonts[3];
    ImGui::PushFont(boldFont);
    auto sz = ImGui::CalcItemSize(ImGui::CalcTextSize("Create Componet"), 30, 0);

    ImGui::SetCursorPosY(ImGui::GetCursorPosY() + 10);

    ImGui::SetCursorPosX(ImGui::GetWindowContentRegionWidth()*0.5f - sz.x * 0.5f);
    bool clicked = ImGui::Button("Create Component");
    if (clicked)
        ImGui::OpenPopup("##create_component");
    ImGui::PopFont();

    if (ImGui::BeginPopup("##create_component"))
    {
        if (ImGui::IsKeyPressed(ImGui::GetKeyIndex(ImGuiKey_Escape)))
            ImGui::CloseCurrentPopup();
        DoCreateComponentMenu(node);
        ImGui::EndPopup();
    }

    ImGui::PopID();
}

GUI_SceneTreeView::GUI_SceneTreeView() : GUI_DockView(ICON_FA_TREE " Scene")
{

}

void GUI_SceneTreeView::Draw()
{
    PROFILE(GUI_SceneTree);
    if (treeW > 0)
        ImGui::SetNextWindowContentWidth(treeW);
    treeW = 0;
    if (ImGui::BeginDock(title_.c_str(), &visible_, ImGuiWindowFlags_MenuBar | ImGuiWindowFlags_HorizontalScrollbar))
    {
        static ImGuiTextFilter sceneFilter;
        ImGui::BeginMenuBar();
        sceneFilter.Draw(FILTER_TEXT);
        ImGui::EndMenuBar();

        if (auto doc = DocumentManager::Get()->GetActiveDoc<ITreeDocument>())
        {
            ImGui::PushID(doc.get());
            doc->DrawDocumentTree(&sceneFilter);
            ImGui::PopID();
        }
        else if (auto doc = DocumentManager::Get()->GetActiveDoc<Document3D>())
        {
            ImGui::PushID(doc.get());

            std::vector<RefCounted*> selectedList;
            for (size_t i = 0; i < doc->GetSelection().size(); ++i)
            {
                if (auto sel = doc->GetSelection().Get<UrhoNodeSelectable>(i))
                    selectedList.push_back(sel->node_);
                else if (auto selComp = doc->GetSelection().Get<UrhoComponentSelectable>(i))
                    selectedList.push_back(selComp->component_);
                else if (auto selUI = doc->GetSelection().Get<UrhoUISelectable>(i))
                    selectedList.push_back(selUI->element_);
            }

            auto newSel = ShowTree(doc->GetScene(), selectedList, false, true, &sceneFilter);
            if (newSel.first)
            {
                if (newSel.second == 0) // is it a removal?
                {
                    doc->GetSelection().Deselect(newSel.first);
                    // if there's a valid gizmo thing be sure to use it
                    if (auto firstNode = doc->GetSelection().MostRecent<UrhoNodeSelectable>())
                        doc->GetGizmo().reset(new UrhoGizmo(firstNode->node_));
                    else if (auto firstComp = doc->GetSelection().MostRecent<UrhoComponentSelectable>())
                        doc->GetGizmo().reset(new UrhoGizmo(Urho3D::SharedPtr<Node>(firstComp->component_->GetNode())));
                    else
                        doc->GetGizmo().reset();
                }
                else
                {
                    if (newSel.second == 1)
                        doc->GetSelection().clear();
                    if (auto nodeCast = dynamic_cast<Node*>(newSel.first))
                    {
                        doc->GetSelection().AddSelection(std::make_shared<UrhoNodeSelectable>(Urho3D::SharedPtr<Node>((Urho3D::Node*)newSel.first)));
                        doc->GetGizmo().reset(new UrhoGizmo(Urho3D::SharedPtr<Node>((Urho3D::Node*)newSel.first)));
                    }
                    else if (auto compCast = dynamic_cast<Component*>(newSel.first))
                    {
                        doc->GetSelection().AddSelection(std::make_shared<UrhoComponentSelectable>(Urho3D::SharedPtr<Component>((Urho3D::Component*)newSel.first)));
                        doc->GetGizmo().reset(new UrhoGizmo(Urho3D::SharedPtr<Node>(compCast->GetNode())));
                    }
                }

                doc->CheckMultiGizmo();
            }
            //BlockExe::GetInst()->GetImGuiElem()->ShowTree(doc->GetScene());
            ImGui::PopID();
        }
    }
    ImGui::EndDock();
}

#define SelectedContains(obj) std::find(currentSelected.begin(), currentSelected.end(), obj) != currentSelected.end()

bool ImGui_MouseTrulyClicked(int btn = 0)
{
    return ImGui::IsItemHovered() && ImGui::GetIO().MouseReleased[btn] && ImGui::IsWindowFocused() && !ImGui::IsPopupOpen((ImGuiID)0);
}

unsigned GUI_SceneTreeView::CountNonTempChildren(Urho3D::Node* node, bool tempsIn) const
{
    if (tempsIn)
        return node->GetNumChildren() + node->GetNumComponents();
    return node->GetNumPersistentChildren() + node->GetNumPersistentChildren();
}

std::pair<RefCounted*, int> GUI_SceneTreeView::ShowTree(Node* node, std::vector<RefCounted*>& currentSelected, bool disabled, bool showTemps, ImGuiTextFilter* filter)
{
    extern std::unique_ptr<DataObject> editorSettings_;

    const bool isScene = dynamic_cast<Scene*>(node) != nullptr;

    std::pair<RefCounted*, int> retSel(0x0, 0);
    if (node == 0x0)
        return retSel;
    if (node->GetName().StartsWith("##"))
        return retSel;
    if (node->IsTemporary() && !editorSettings_->GetField("Show Temporary Objects").GetBool())
        return retSel;

    static Component* lastComp = 0x0;
    static Node* lastNode = 0x0;
    ImGui::PushID(node);
    int treeNodeFlags = ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_AllowItemOverlap;
    bool thisNodeSelected = SelectedContains(node);
    if (thisNodeSelected)
        treeNodeFlags |= ImGuiTreeNodeFlags_Selected;
    if (isScene)
        treeNodeFlags |= ImGuiTreeNodeFlags_DefaultOpen;

    String name = (node->GetName().Length() > 0 ? node->GetName() : "< unnamed >") + " : " + node->GetTypeName() + " [" + String(node->GetID()) + "]";
    const unsigned childCt = CountNonTempChildren(node, showTemps);

    if (childCt == 0)
        treeNodeFlags |= ImGuiTreeNodeFlags_Leaf;
    
    if (!node->IsEnabled() || disabled)
        name = "^1" + name;
    else if (node->IsTemporary())
        name = "^3" + name;
    else if (editorSettings_->GetField("Highlight Prefab Instances").GetBool() && node->GetVar("PREFAB_PATH").GetType() != VAR_NONE)
        name = "^5" + name;

    bool passedFilter = filter->PassFilter(name.CString());
    bool isNodeOpen = passedFilter ? ImGui::TreeNodeEx("", treeNodeFlags) : true;
    int lastItem = ImGui::GetCurrentWindow()->DC.LastItemId;
    if (passedFilter)
    {
        ImGui::SameLine();
        auto texSize = GetEditorIconUV("Node");
        bool isReplicated = node->GetID() < FIRST_LOCAL_ID;

        ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(20,20), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w), isReplicated ? ImVec4(0.6,0.6,1,1) :ImVec4(1,1,1,1));
        ImGui::SameLine();
        treeW = Max(treeW, ImGui::GetCursorPosX() + ImGui::CalcTextSize(name.CString()).x);
        ImGui::Selectable(name.CString());
        if (!ImGui::IsPopupOpen((ImGuiID)0) && !isScene && ImGui::BeginDragDropSource())
        {
            unsigned id = node->GetID();
            ImGui::SetDragDropPayload("U_NODEID", &id, sizeof(unsigned));
            ImGui::Text(name.CString());
            ImGui::EndDragDropSource();
        }
        else if (ImGui::BeginDragDropTarget())
        {
            if (auto payload = ImGui::AcceptDragDropPayload("U_NODEID"))
            {
                if (auto doc = DocumentManager::Get()->GetActiveDoc<Document3D>())
                {
                    unsigned nodeID = *((unsigned*)payload->Data);
                    if (auto found = GetNodeByID(SharedPtr<Node>(doc->GetScene()), nodeID))
                        doc->GetUndoStack().PushNew(std::make_shared<UrhoMoveNodeUndoRedo>(found, SharedPtr<Node>(found->GetParent()), SharedPtr<Node>(node)))->RecordStandardSelectables(doc.get());
                }
            }
            else if (auto payload = ImGui::AcceptDragDropPayload("U_COMPID"))
            {
                if (auto doc = DocumentManager::Get()->GetActiveDoc<Document3D>())
                {
                    unsigned nodeID = *((unsigned*)payload->Data);
                    if (auto found = GetComponentByID(SharedPtr<Node>(doc->GetScene()), nodeID))
                        doc->GetUndoStack().PushNew(std::make_shared<UrhoMoveComponentUndoRedo>(found, SharedPtr<Node>(found->GetNode()), SharedPtr<Node>(node)))->RecordStandardSelectables(doc.get());
                }
            }
            ImGui::EndDragDropTarget();
        }
        else if (ImGui_MouseTrulyClicked())
        {
            if (!thisNodeSelected)
                retSel = std::make_pair(node, ImGui::GetIO().KeyCtrl ? 2 : 1);
            else if (ImGui::GetIO().KeyCtrl && thisNodeSelected)
                retSel = std::make_pair(node, 0);
        }
        else if (ImGui::IsItemClicked(1))
        {
            ImGui::OpenPopup("tree_node_ctx");
            lastNode = node;
        }
    }
    
    if (isNodeOpen && childCt > 0)
    {
        int i = 1;
        if (passedFilter) // only show components on nodes that pass the filter
        {
            for (size_t compIdx = 0; compIdx < node->GetComponents().Size(); ++compIdx, ++i)
            {
                auto comp = node->GetComponents()[compIdx];
                if (!showTemps && comp->IsTemporary())
                    continue;
                ImGui::PushStyleColor(ImGuiCol_Text, { 0.39f, 1.0f, 0.39f, 1.0f });
                bool thisCompSelected = SelectedContains(comp.Get());
                int flags = thisCompSelected ? ImGuiTreeNodeFlags_Selected : 0;
                flags |= (ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_AllowItemOverlap);
                ImGui::PushID(i);
                ImGui::TreeNodeEx("", ImGuiTreeNodeFlags_Leaf | flags);
                ImGui::SameLine();

                auto texSize = GetEditorIconUV(comp->GetTypeName());
                ImGui::Image((ImTextureID)GetEditorIconTexture(), ImVec2(16, 16), ImVec2(texSize.x, texSize.y), ImVec2(texSize.z, texSize.w));
                ImGui::SameLine();

                String compText = comp->GetTypeName() + " [" + String(comp->GetID()) + "]";
                if (!comp->IsEnabledEffective() || disabled)
                    compText = "^1" + compText;
                else if (comp->IsTemporary())
                    compText = "^3" + compText;

                treeW = Max(treeW, ImGui::GetCursorPosX() + ImGui::CalcTextSize(compText.CString()).x);
                ImGui::Selectable(compText.CString());
                if (ImGui::BeginDragDropSource())
                {
                    unsigned id = comp->GetID();
                    ImGui::SetDragDropPayload("U_COMPID", &id, sizeof(unsigned));
                    ImGui::Text(compText.CString());
                    ImGui::EndDragDropSource();
                }
                else if (ImGui::IsItemClicked())
                {
                    if (!thisCompSelected)
                        retSel = std::make_pair(comp, ImGui::GetIO().KeyCtrl ? 2 : 1);
                    else if (thisCompSelected && ImGui::GetIO().KeyCtrl)
                        retSel = std::make_pair(comp, 0);
                }
                else if (ImGui::IsItemClicked(1))
                {
                    ImGui::OpenPopup("#tree_comp_ctx");
                    lastComp = comp;
                    lastNode = node;
                }
                ImGui::PopStyleColor();

                if (lastComp == comp && ImGui::BeginPopup("#tree_comp_ctx"))
                {
                    if (ImGui::MenuItem(ICON_FA_CLONE " Clone"))
                    {
                        auto doc = DocumentManager::Get()->GetActiveDocument();
                        SelectionList oldSelection = doc->GetSelection();
                        VectorBuffer data;
                        comp->Save(data);
                        data.Seek(sizeof(StringHash) + sizeof(unsigned));
                        SharedPtr<Component> newComp(comp->GetNode()->CreateComponent(comp->GetType(), comp->GetID() < FIRST_LOCAL_ID ? REPLICATED : LOCAL));
                        newComp->Load(data);
                        doc->GetSelection().Select(std::make_shared<UrhoComponentSelectable>(newComp));
                        SelectionList newSel = doc->GetSelection();
                        doc->GetUndoStack().PushNew(std::make_shared<UrhoCreateDeleteComponentUndoRedo>(SharedPtr<Node>(comp->GetNode()), newComp, true))->AttachSelectables(oldSelection, newSel);
                    }
                    ImGui::Separator();
                    if (ImGui::MenuItem(ICON_FA_TRASH " Delete"))
                    {
                        if (auto doc = DocumentManager::Get()->GetActiveDocument())
                        {
                            SelectionList oldSelection = doc->GetSelection();
                            auto castVec = CastVector<UrhoComponentSelectable, Selectable>(doc->GetSelection());
                            UndoRedoList actionList;
                            for (auto v : castVec)
                                actionList.push_back(std::make_shared<UrhoCreateDeleteComponentUndoRedo>(SharedPtr<Node>(v->component_->GetNode()), SharedPtr<Component>(v->component_), false));
                            doc->GetSelection().clear();
                            if (actionList.size() == 1)
                                doc->GetUndoStack().PushNew(actionList[0])->AttachSelectables(oldSelection, SelectionList());
                            else if (actionList.size() > 1)
                                doc->GetUndoStack().PushNew(std::make_shared<MultiUndoRedo>(ICON_FA_TRASH " ^1Delete components", actionList))->AttachSelectables(oldSelection, SelectionList());
                        }
                    }

                    static StringHash CompCtx("COMPONENT_CONTEXT");
                    static StringHash CompCtx_TypeID("TypeHash");
                    static StringHash CompCtx_Comp("Component");
                    auto& eventData = DocumentManager::Get()->GetActiveDocument()->GetEventDataMap();
                    eventData[CompCtx_TypeID] = comp->GetType();
                    eventData[CompCtx_Comp] = comp;
                    DocumentManager::Get()->GetActiveDocument()->SendEvent(CompCtx, eventData);

                    ImGui::EndPopup();
                };

                ImGui::TreePop();
                ImGui::PopID();
            }
        }

        for (auto child : node->GetChildren())
        {
            if (!showTemps && child->IsTemporary())
                continue;
            auto r = ShowTree(child, currentSelected, !node->IsEnabled() || disabled, showTemps, filter);
            if (r.first && retSel.first == nullptr)
                retSel = r;
        }
    }
    
    if (isNodeOpen && passedFilter)
        ImGui::TreePop();

    if (lastNode == node && ImGui::BeginPopup("tree_node_ctx"))
    {
        FillNodeContextMenu(lastNode);
        ImGui::EndPopup();
    }

    ImGui::PopID();
    return retSel;
}

GUI_ShadersView::GUI_ShadersView() : GUI_DockView(ICON_FA_ADDRESS_CARD " Shader Variations")
{

}

void GUI_ShadersView::Draw()
{
    PROFILE(GUI_ShaderVariations);
    if (ImGui::BeginDock(title_.c_str(), &visible_, ImGuiWindowFlags_MenuBar))
    {
        ImGui::BeginMenuBar();
        static ImGuiTextFilter filter;
        filter.Draw(FILTER_TEXT);
        ImGui::EndMenuBar();
        auto ctx = BlockExe::GetInst()->GetContext();

        ResourceCache* resCache = ctx->GetSubsystem<ResourceCache>();
        PODVector<Shader*> shaders;
        resCache->GetResources<Shader>(shaders);

        for (auto shader : shaders)
        {
            ImGui::PushID(shader);
            if (ImGui::TreeNodeEx(shader->GetName().CString()))
            {
                if (ImGui::TreeNodeEx("VS"))
                {
                    auto vsVar = shader->GetVSVariations();
                    bool anyPass = false;
                    for (auto var : vsVar)
                    {
                        if (filter.PassFilter(var.second_->GetDefines().CString()))
                        {
                            ImGui::TreeNodeEx(var.second_->GetDefines().CString(), ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen);
                            anyPass = true;
                        }
                    }
                    if (!anyPass)
                        ImGui::TreeNodeEx("< no shader variations pass filter >", ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen);
                    ImGui::TreePop();
                }
                if (ImGui::TreeNodeEx("PS"))
                {
                    auto vsVar = shader->GetPSVariations();
                    bool anyPass = false;
                    for (auto var : vsVar)
                        if (filter.PassFilter(var.second_->GetDefines().CString()))
                        {
                            ImGui::TreeNodeEx(var.second_->GetDefines().CString(), ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen);
                            anyPass = true;
                        }
                    if (!anyPass)
                        ImGui::TreeNodeEx("< no shader variations pass filter >", ImGuiTreeNodeFlags_Leaf | ImGuiTreeNodeFlags_NoTreePushOnOpen);
                    ImGui::TreePop();
                }
                ImGui::TreePop();
            }
            ImGui::PopID();
        }
    }
    ImGui::EndDock();
}

GUI_AssetBrowserView::DirectoryTreeData::DirectoryTreeData(const Urho3D::String& path)
{
    fullPath_ = path;
    displayName_ = Urho3D::GetFileName(path);

    auto fileSystem = BlockExe::GetInst()->GetContext()->GetSubsystem<FileSystem>();
    auto imElem = BlockExe::GetInst()->GetImGuiElem();
    StringVector content;
    fileSystem->ScanDir(content, path, String::EMPTY, SCAN_DIRS, false);

    for (auto folder : content)
    {
        if (folder == "." || folder == "..")
            continue;

        String itemPath = path + "/" + folder;
        children_.push_back(new DirectoryTreeData(itemPath));
    }
}

GUI_AssetBrowserView::DirectoryTreeData::~DirectoryTreeData()
{
    for (auto child : children_)
        delete child;
    children_.clear();
}

GUI_AssetBrowserView::GUI_AssetBrowserView() : GUI_DockView(ICON_FA_DESKTOP " Asset Browser")
{
    auto ctx = BlockExe::GetInst()->GetContext();
    auto fs = ctx->GetSubsystem<FileSystem>();

    SharedPtr<XMLFile> favoriteData(new XMLFile(ctx));
    if (favoriteData->LoadFile(fs->GetAppPreferencesDir("urho3d", "Blocks") + "Favorites.xml"))
    {
        auto elem = favoriteData->GetRoot().GetChild("fav");
        while (elem.NotNull())
        {
            String path = elem.GetAttribute("path");
            if (fs->DirExists(path))
                favorites_.push_back(path);
            elem = elem.GetNext("fav");
        }
    }

    directory_ = Urho3D::RemoveTrailingSlash(BlockExe::GetInst()->GetContext()->GetSubsystem<FileSystem>()->GetProgramDir());
    rootDirectory_ = directory_;
    directoryData_ = new DirectoryTreeData(rootDirectory_);

    fileHandlers_ = {
        { ".as", [](const Urho3D::String& path) {
            if (ImGui::MenuItem(ICON_FA_PLAY " Run Script"))
            {
                ExecuteScriptFile(BlockExe::GetInst()->GetContext(), path.CString());
            }
            if (ImGui::MenuItem(ICON_FA_EDIT " Open"))
                BlockExe::GetInst()->GetContext()->GetSubsystem<FileSystem>()->SystemOpen(path);
            ImGui::Separator();
            ImGui::MenuItem(ICON_FA_COG " Compile Script");
            if (ImGui::MenuItem(ICON_FA_PLAY " Run as Editor Action Script"))
            {
                if (auto sceneDoc = DocumentManager::Get()->GetActiveDoc<Document3D>())
                    ExecuteScriptOnScene(BlockExe::GetInst()->GetContext(), sceneDoc->GetScene().Get(), path.CString());
                else
                    ModalWindows::Get()->Push(ErrorMessage("Active document does not contain a scene to execute a script on.", "No Scene", { }));
            }
        } },
        { ".xml", [](const Urho3D::String& path) {
            if (ImGui::MenuItem(ICON_FA_EDIT " Open"))
            {
                // first see if there's a doc type for it
                if (!DocumentManager::Get()->OpenPath(path))
                    BlockExe::GetInst()->GetContext()->GetSubsystem<FileSystem>()->SystemOpen(path);
            }
        } },
        { ".mdl", [](const Urho3D::String& path) {
            if (ImGui::MenuItem(ICON_FA_EYE, " Open in viewer"))
                DocumentManager::Get()->OpenPath(path);
        } },
        { ".ani", [](const Urho3D::String& path) {
            // load into open model-viewer
            // convert into attribute animation
        } },
        { ".wav", [](const Urho3D::String& path) {
            if (ImGui::MenuItem(ICON_FA_HEADPHONES " Play"))
            {
                auto cache = BlockExe::GetInst()->GetSubsystem<ResourceCache>();
                if (auto sfx = cache->GetResource<Sound>(path))
                {
                    auto ss = BlockExe::GetInst()->GetMasterScene()->CreateComponent<SoundSource>();
                    ss->Play(sfx);
                    ss->SetAutoRemoveMode(REMOVE_COMPONENT);
                }
            }
        } },
    };
}

GUI_AssetBrowserView::~GUI_AssetBrowserView()
{
    if (directoryData_)
    delete directoryData_;
}

void GUI_AssetBrowserView::SaveData()
{
    auto ctx = BlockExe::GetInst()->GetContext();
    auto fs = ctx->GetSubsystem<FileSystem>();

    SharedPtr<XMLFile> data(new XMLFile(ctx));
    auto root = data->CreateRoot("favorites");
    for (auto fav : favorites_)
        root.CreateChild("fav").SetAttribute("path", fav);
    data->SaveFile(fs->GetAppPreferencesDir("urho3d", "Blocks") + "Favorites.xml");
}

void GUI_AssetBrowserView::Draw()
{
    auto cache = BlockExe::GetInst()->GetSubsystem<ResourceCache>();

    PROFILE(GUI_AssetBrowser);
    if (ImGui::BeginDock(title_.c_str(), &visible_, ImGuiWindowFlags_MenuBar))
    {
        ImGui::BeginMenuBar();
        // Draw up button, but only if not at root
        if (!directory_.EndsWith(":") && !directory_.EndsWith(":/"))
        {
            ImGuiUX::PushBold();
            if (ImGui::Button(ICON_FA_LEVEL_UP_ALT, ImVec2(32, 0)))
                directory_ = Urho3D::RemoveTrailingSlash(Urho3D::GetParentPath(directory_));
            ImGui::PopFont();
        }
        ImGui::Text(directory_.CString());
        ImGui::PushItemWidth(ImGui::GetContentRegionAvailWidth() * 0.7f);
        static ImGuiTextFilter assetFilter;
        assetFilter.Draw(FILTER_TEXT);
        ImGui::PopItemWidth();

        ImGuiUX::PushBold();
        ImGui::SetCursorPosX(ImGui::GetWindowWidth() - 90);
        if (ImGuiUX::ToggleButton(ICON_FA_LIST_UL, asDetails_))
            asDetails_ = !asDetails_;
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip("Toggle list-view");
        ImGui::SameLine();
        if (ImGui::Button(ICON_FA_STAR "+"))
        {
            if (std::find(favorites_.begin(), favorites_.end(), directory_) == favorites_.end())
                favorites_.push_back(directory_);
        }
        if (ImGui::IsItemHovered()) 
            ImGui::SetTooltip("Add to favorites");
        ImGui::PopFont();

        ImGui::EndMenuBar();

        float w = ImGui::GetContentRegionAvailWidth();
        const float fSize = ImGui::GetFontSize() * 16;
        w = min(w * 0.33f, fSize);

        ImGui::BeginChild("##folder_tree", { w, ImGui::GetContentRegionAvail().y }, true);
        ImGuiUX::PushBold();
        bool localOpen = ImGui::CollapsingHeader(ICON_FA_FOLDER " LOCAL", ImGuiTreeNodeFlags_DefaultOpen);
        ImGui::PopFont();
        if (localOpen)
            ShowTree(directoryData_);

        ImGuiUX::PushBold();
        bool favsOpen = ImGui::CollapsingHeader(ICON_FA_STAR " FAVORITES", ImGuiTreeNodeFlags_DefaultOpen);
        ImGui::PopFont();
        if (favsOpen)
        {
            ImGui::Indent();
            for (int i = 0; i < favorites_.size(); ++i)
            {
                auto d = favorites_[i];
                String parent = Urho3D::GetFileName(Urho3D::RemoveTrailingSlash(Urho3D::GetParentPath(d)));
                if (auto img = GetImage(d))
                {
                    ImGui::Image(img.Get(), ImVec2(16, 16));
                    ImGui::SameLine();
                }
                ImGui::PushID(i + 1);
                ImGui::Text((parent + "/" + Urho3D::GetFileName(d)).CString());
                if (ImGui::IsItemClicked())
                    directory_ = d;
                if (ImGui::IsItemClicked(1))
                    ImGui::OpenPopup("#favorite_ctx");
                if (ImGui::BeginPopup("#favorite_ctx"))
                {
                    if (ImGui::MenuItem(ICON_FA_MINUS " Remove"))
                    {
                        favorites_.erase(favorites_.begin() + i);
                        --i;
                    }
                    ImGui::EndPopup();
                }

                ImGui::PopID();
            }
            ImGui::Unindent();
        }

        ImGuiUX::PushBold();
        bool recentOpen = ImGui::CollapsingHeader(ICON_FA_CLOCK " RECENT", ImGuiTreeNodeFlags_DefaultOpen);
        ImGui::PopFont();
        if (recentOpen)
        {
            ImGui::Indent();
            for (auto d : recentDirectories_)
            {
                String parent = Urho3D::GetFileName(Urho3D::RemoveTrailingSlash(Urho3D::GetParentPath(d)));
                if (auto img = GetImage(d))
                {
                    ImGui::Image(img.Get(), ImVec2(16, 16));
                    ImGui::SameLine();
                }
                ImGui::Text((parent + "/" + Urho3D::GetFileName(d)).CString());
                if (ImGui::IsItemClicked())
                    directory_ = d;
            }
            ImGui::Unindent();
        }

        ImGui::EndChild();

        ImGui::SameLine();

        if (directory_ != lastDirectory_)
        {
            lastDirectory_ = directory_;
            currentDirCache_.Clear();
            auto fs = BlockExe::GetInst()->GetSubsystem<FileSystem>();
            fs->ScanDir(currentDirCache_, directory_, String::EMPTY, SCAN_DIRS | SCAN_FILES, false);
        }
        if (asDetails_)
            ShowDirectory(directory_, currentDirCache_, &assetFilter, true);
        else
            ShowDirectory(directory_, currentDirCache_, &assetFilter, false);
    }
    ImGui::EndDock();
}

std::vector<String> excludedExtensions = {
    ".exe",
    ".dll",
    ".bat",
    ".ini",
    ".layout",
    ".ilk",
    ".lib",
    ".pdb",
};

void GUI_AssetBrowserView::ShowDirectory(const Urho3D::String& path, const Urho3D::StringVector& content, ImGuiTextFilter* filter, bool asDetail)
{
    auto imElem = BlockExe::GetInst()->GetImGuiElem();

    float contentWidth = ImGui::GetContentRegionAvailWidth();
    float contentHeight = ImGui::GetContentRegionAvail().y;

    ImGui::BeginChild("##ContentRegion", { contentWidth, contentHeight }, true);

    const float w = contentWidth;
    const float itemSize = asDetail ? 48 : 128;
    
    int index = 0;
    int columns = contentWidth / (asDetail ? 256 : 128);
    columns = columns < 1 ? 1 : columns;

    float curX = 0.0f;
    ImGui::Columns(columns, nullptr, false);

    static String assetPopupPath;

    for (size_t i = 0; i < content.Size(); ++i)
    {
        String item = content[i];
        String itemPath = path + "/" + item;
        if (item == "." || item == "..")
            continue;
        bool cancel = false;
        for (auto exclude : excludedExtensions)
            if (item.EndsWith(exclude))
                cancel = true;
        if (cancel)
            continue;

        if (!filter->PassFilter(item.CString()))
            continue;

        ImGui::PushID(i);

        // filtering makes this really really tricky to cache
        Urho3D::SharedPtr<Texture2D> thumb = GetImage(itemPath);
        
        auto filName = GetFileNameAndExtension(item);

        ImGui::BeginGroup();
        ImGui::ImageButton(thumb.Get(), { itemSize - 20, itemSize - 16 });// , { 0, 1 }, { 1,0 });
        if (ImGui::IsMouseDoubleClicked(0) && ImGui::IsItemHovered()) // change target directory
        {
            if (IsFile(itemPath))
            {
                if (!DocumentManager::Get()->OpenPath(itemPath))
                    BlockExe::GetInst()->GetContext()->GetSubsystem<FileSystem>()->SystemOpen(itemPath);
            }
            else
                directory_ = itemPath;
        }
        else if (ImGui::IsMouseClicked(1) && ImGui::IsItemHovered())
        {
            ImGui::OpenPopup("##asset_browser_popup");
            assetPopupPath = itemPath;
        }
        else if (ImGui::IsItemHovered() && asDetail && filName.Contains('.'))
        {
            ImGui::BeginTooltip();
            ImGui::Image(thumb.Get(), { 128, 128 });
            ImGui::EndTooltip();
        }

        if (ImGui::BeginPopup("##asset_browser_popup"))
        {
            auto ext = Urho3D::GetExtension(assetPopupPath);
            auto found = fileHandlers_.Find(ext);
            if (found != fileHandlers_.End())
                found->second_(assetPopupPath);
            else
            {
                if (ImGui::MenuItem(ICON_FA_EDIT " Open (system)"))
                    BlockExe::GetInst()->GetSubsystem<FileSystem>()->SystemOpen(assetPopupPath);
            }

            // Script extension point
            auto& eventData = BlockExe::GetInst()->GetEventDataMap();
            eventData["SelectedAssetPath"] = assetPopupPath;
            eventData["SelectedAssetExt"] = ext;
            if (ext == ".xml")
            {
                XMLFile file(BlockExe::GetInst()->GetContext());
                if (file.LoadFile(assetPopupPath))
                    eventData["XmlRoot"] = file.GetRoot().GetName().ToLower();
            }
            BlockExe::GetInst()->SendEvent("ASSET_BROWSER_CONTEXT", eventData);

            ImGui::EndPopup();
        }

        if (asDetail)
            ImGui::SameLine();
        ImGui::TextWrapped(filName.CString());
        if (ImGui::IsItemHovered() && !asDetail)
            ImGui::SetTooltip(filName.CString());
        ImGui::EndGroup();
        if (!ImGui::IsPopupOpen((ImGuiID)0) && ImGui::BeginDragDropSource(ImGuiDragDropFlags_SourceAllowNullID))
        {
            if (std::find(recentDirectories_.begin(), recentDirectories_.end(), directory_) == recentDirectories_.end())
                recentDirectories_.insert(recentDirectories_.begin(), directory_);

            ImGui::SetDragDropPayload("U_RES", itemPath.CString(), itemPath.Length());
            ImGui::Image(thumb.Get(), { 128, 128 });
            ImGui::Text(filName.CString());
            ImGui::EndDragDropSource();
        }

        ImGui::PopID();
        ImGui::NextColumn();
    }

    ImGui::EndChild();
}

Urho3D::SharedPtr<Urho3D::Texture2D> GUI_AssetBrowserView::GetImage(const Urho3D::String& itemPath)
{
    Urho3D::SharedPtr<Texture2D> thumb;
    auto cacheResult = thumbCache_.Find(itemPath);
    if (cacheResult != thumbCache_.End())
        thumb = cacheResult->second_;
    if (!thumb)
    {
        thumb = GetOrCreateThumbnail(itemPath);
        if (thumb)
            thumbCache_[itemPath] = thumb;
    }
    if (thumb)
        BlockExe::GetInst()->GetImGuiElem()->AddTexture((intptr_t)thumb.Get(), thumb);
    return thumb;
}

void GUI_AssetBrowserView::ShowTree(const DirectoryTreeData* node)
{
    const float imgSize = ImGui::GetFont()->Ascent;

    for (auto folder : node->children_)
    {
        String itemPath = folder->fullPath_;
        String labelLessText = "##" + folder->displayName_;

        const bool isLeaf = folder->children_.size() == 0;

        bool isOpen = ImGui::TreeNodeEx(labelLessText.CString(), isLeaf ? ImGuiTreeNodeFlags_Leaf : 0);

        ImGui::SameLine();

        bool isSelected = directory_ == itemPath;
        bool wasSelected = isSelected;
        String selectableText = labelLessText + "_selectable";
        ImGui::Selectable(selectableText.CString(), &isSelected, ImGuiSelectableFlags_DrawFillAvailWidth);

        // filtering makes this really really tricky to cache
        Urho3D::SharedPtr<Texture2D> thumb;
        auto cacheResult = thumbCache_.Find(itemPath);
        if (cacheResult != thumbCache_.End())
            thumb = cacheResult->second_;
        if (!thumb)
        {
            thumb = GetOrCreateThumbnail(itemPath);
            if (thumb)
                thumbCache_[itemPath] = thumb;
        }

        if (thumb)
        {
            ImGui::SameLine();
            BlockExe::GetInst()->GetImGuiElem()->AddTexture((intptr_t)thumb.Get(), thumb);
            ImGui::Image(thumb.Get(), { imgSize, imgSize }, { 0, 1 }, { 1,0 });
        }
        ImGui::SameLine();
        ImGui::Text(folder->displayName_.CString());

        if (isSelected && !wasSelected)
            directory_ = itemPath;

        if (isOpen)
        {
            if (folder->children_.size())
                ShowTree(folder);
            ImGui::TreePop();
        }
    }
}

Urho3D::SharedPtr<Urho3D::Texture2D> GUI_AssetBrowserView::GetOrCreateThumbnail(const Urho3D::String& path)
{
    static std::set<std::string> os_ThumbnailIsFixed = {
        ".as",
        ".mdl",
        ".xml",
        ".pak"
    };

    Urho3D::SharedPtr<Urho3D::Texture2D> ret;
    String lookupPath = path;

    auto resCache = BlockExe::GetInst()->GetContext()->GetSubsystem<ResourceCache>();
    if (path.EndsWith(".xml", false))
    {
        ret = resCache->GetResource<Texture2D>("##THUMB_" + lookupPath, false);
        if (ret)
            return ret;

        XMLFile file(resCache->GetContext());
        if (file.LoadFile(path))
        {
            auto found = file.GetRoot().SelectSingle("attribute[@name='Variables']");
            if (found.NotNull())
            {
                VariantMap map = found.GetVariantMap();
                if (map.Find("THUMBNAIL") != map.End())
                {
                    auto vb = map["THUMBNAIL"].GetVectorBuffer();
                    Image img(resCache->GetContext());
                    img.SetSize(128, 128, 4);
                    img.SetData(vb.GetModifiableData());
                    SharedPtr<Texture2D> newTex(new Texture2D(resCache->GetContext()));
                    newTex->SetSize(128, 128, Graphics::GetRGBAFormat());
                    newTex->SetData(&img, true);
                    if (newTex)
                    {
                        newTex->SetName(resCache->SanitateResourceName("##THUMB_" + lookupPath));
                        resCache->AddManualResource(newTex);
                        return newTex;
                    }
                }
            }
        }
    }
    
    if (os_ThumbnailIsFixed.find(Urho3D::GetExtension(path, true).CString()) != os_ThumbnailIsFixed.end())
        lookupPath = Urho3D::GetExtension(path, true);

    ret = resCache->GetResource<Texture2D>("##THUMB_" + lookupPath, false);
    if (ret)
        return ret;

    String nativePath = Urho3D::GetNativePath(path);
    ret = CreateThumbnail(BlockExe::GetInst()->GetContext(), nativePath, 64);
    if (ret)
    {
        ret->SetName(resCache->SanitateResourceName("##THUMB_" + lookupPath));
        resCache->AddManualResource(ret);
    }

    return ret;
}

static const char* SequencerItemTypeNames[] = { "Camera","Music", "ScreenEffect", "FadeIn", "Animation" };

struct TestSequencer : public ImSequencer::SequenceInterface
{
    // interface with sequencer

    virtual int GetFrameCount() const { return mFrameCount; }
    virtual int GetTrackCount() const { return (int)tracks.size(); }
    virtual ImSequencer::TRACK_NATURE GetTrackNature(unsigned trackIndex) const { return tracks[trackIndex].mType == 2 ? ImSequencer::TRACK_NATURE_TICK : ImSequencer::TRACK_NATURE_DEFAULT; }

    virtual int GetTrackTypeCount() const { return sizeof(SequencerItemTypeNames) / sizeof(char*); }
    virtual const char *GetTrackTypeName(int typeIndex) const { return SequencerItemTypeNames[typeIndex]; }
    virtual const char *GetTrackLabel(int index) const
    {
        static char tmps[512];
        sprintf_s(tmps, "[%02d] %s", index, SequencerItemTypeNames[tracks[index].mType]);
        return tmps;
    }

    virtual unsigned GetKeyFrameCount(int trackIndex) override { return tracks[trackIndex].keyFrames_.size(); }
    virtual void Get(int trackIndex, int keyIndex, int** start, int** end, int *type, unsigned int *color)
    {
        MySequenceTrack &item = tracks[trackIndex];
        if (color)
            *color = 0xFFAA8080; // same color for everyone, return color based on type
        if (keyIndex != -1)
        {
            MySequenceItem& key = item.keyFrames_[keyIndex];
            if (start)
                *start = &key.mFrameStart;
            if (end)
                *end = &key.mFrameEnd;
        }
        if (type)
            *type = item.mType;
    }
    virtual void Add(int type) { 
        tracks.push_back(MySequenceTrack(type)); 
    };
    virtual void Del(int index) { 
        tracks.erase(tracks.begin() + index); 
    }
    virtual void Duplicate(int index) { 
        tracks.push_back(tracks[index]); 
    }
    virtual bool SwapKeyframes(int trackIndex, int keyIndex, int withIndex) override 
    { 
        std::swap(tracks[trackIndex].keyFrames_[keyIndex], tracks[trackIndex].keyFrames_[withIndex]);
        return true; 
    }

    // my datas
    TestSequencer() : mFrameCount(0) {}
    int mFrameCount;
    struct MySequenceItem
    {
        int mType;
        int mFrameStart, mFrameEnd;
    };
    struct MySequenceTrack
    {
        int mType;
        std::vector<MySequenceItem> keyFrames_;

        MySequenceTrack(int type)
        {
            mType = type;
            keyFrames_.push_back(TestSequencer::MySequenceItem{ mType, 20, type == 2 ? 21 : 30 });
            keyFrames_.push_back(TestSequencer::MySequenceItem{ mType, 40, type == 2 ? 31 : 50 });
            keyFrames_.push_back(TestSequencer::MySequenceItem{ mType, 55, type == 2 ? 55 : 60 });
            keyFrames_.push_back(TestSequencer::MySequenceItem{ mType, 71, type == 2 ? 72 : 80 });
            keyFrames_.push_back(TestSequencer::MySequenceItem{ mType, 90, type == 2 ? 91 : 99 });
        }
    };
    std::vector<MySequenceTrack> tracks;
};

static TestSequencer testTimeline;

GUI_TimelineView::GUI_TimelineView() : GUI_DockView(ICON_FA_CHART_BAR " Timeline")
{
    testTimeline.mFrameCount = 100;
    testTimeline.tracks.push_back(TestSequencer::MySequenceTrack(0));
    testTimeline.tracks.push_back(TestSequencer::MySequenceTrack(1));
    testTimeline.tracks.push_back(TestSequencer::MySequenceTrack(1));
    testTimeline.tracks.push_back(TestSequencer::MySequenceTrack(3));
    testTimeline.tracks.push_back(TestSequencer::MySequenceTrack(2));
    testTimeline.tracks.push_back(TestSequencer::MySequenceTrack(4));
}

void GUI_TimelineView::Draw()
{
    PROFILE(GUI_Timeline);
    if (ImGui::BeginDock(title_.c_str(), &visible_, ImGuiWindowFlags_NoScrollbar | ImGuiWindowFlags_NoScrollWithMouse))
    {
        //if (auto sel = DocumentManager::Get()->GetActiveDocument()->GetSelection().MostRecent<UrhoNodeSelectable>())
        //{
        //    SharedPtr<ObjectAnimation> objectAnim(sel->node_->GetObjectAnimation());
        //    if (objectAnim)
        //    {
        //        bool keepCurrent = false;
        //        if (interface_)
        //        {
        //            if (auto cur = dynamic_cast<ObjectAnimSequencer*>(interface_))
        //            {
        //                if (cur->animation_ == objectAnim)
        //                    keepCurrent = true;
        //            }
        //            if (!keepCurrent)
        //                delete interface_;
        //        }
        //        if (!keepCurrent)
        //            interface_ = new ObjectAnimSequencer(objectAnim);
        //    }
        //}
        //if (auto doc = DocumentManager::Get()->GetActiveDoc<ITimelineDocument>())
        //{
        //    doc->DrawTimeline();
        //}
        if (interface_ != 0x0)
        {
            static int selectedEntry = -1;
            static int selectedKey = -1;
            static int firstFrame = 0;
            static bool expanded = true;
            static int curFrame = 0;
            ImSequencer::Sequencer(interface_, 0x0, &expanded, 0x0, 0x0, 0x0, 0);
        }
        else
        {
            static int selectedEntry = -1;
            static int selectedKey = -1;
            static int firstFrame = 0;
            static bool expanded = true;
            static int curFrame = 0;

            ImSequencer::Sequencer(&testTimeline, &curFrame, &expanded, &selectedEntry, &selectedKey, &firstFrame, ImSequencer::SEQUENCER_EDIT_ALL | ImSequencer::SEQUENCER_DEL | ImSequencer::SEQUENCER_ADD);
        }
    }
    ImGui::EndDock();
}

GUI_ShaderGraph::GUI_ShaderGraph() : GUI_DockView(ICON_FA_GLOBE " Shader Graph")
{

}

void GUI_ShaderGraph::Draw()
{
    PROFILE(GUI_ShaderGraph);
    if (ImGui::BeginDock(title_.c_str(), &visible_))
    {
        
    }
    ImGui::EndDock();
}

GUI_ScriptGraph::GUI_ScriptGraph() : GUI_DockView(ICON_FA_GLOBE " Script Graph")
{

}

void GUI_ScriptGraph::Draw()
{
    PROFILE(GUI_ScriptGraph);
    if (ImGui::BeginDock(title_.c_str(), &visible_))
    {

    }
    ImGui::EndDock();
}

GUI_LogView::GUI_LogView() : GUI_DockView(ICON_FA_HEADPHONES " Log")
{
    auto ctx = BlockExe::GetInst()->GetContext();

    BlockExe::GetInst()->SubscribeToEvent(Urho3D::E_LOGMESSAGE, [this](const StringHash& eventID, VariantMap& data) {
        messages_.push_back({ data[Urho3D::LogMessage::P_LEVEL].GetInt(), data[Urho3D::LogMessage::P_MESSAGE].GetString().CString() });
        while (messages_.size() > 512)
            messages_.erase(messages_.begin());
    });
}

void GUI_LogView::Draw()
{
    PROFILE(GUI_LogView);
    if (ImGui::BeginDock(title_.c_str(), &visible_, ImGuiWindowFlags_MenuBar))
    {
#define TIP(MSG) if (ImGui::IsItemHovered()) ImGui::SetTooltip(MSG)
#define BUTTON_TOGGLE(VAR) if (VAR) ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0.3f,0.6f,1.0f,1.0f)); else ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_Button))

        ImGui::BeginMenuBar();
        if (ImGui::Button(ICON_FA_ERASER))
            messages_.clear();
        TIP("Clear log");

        static bool showInfo = true;
        static bool showDebug = true;
        static bool showWarning = true;
        static bool showError = true;

        BUTTON_TOGGLE(showInfo);
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0, 1, 0, 1));
        if (ImGui::Button(ICON_FA_INFO_CIRCLE "##show_info"))
            showInfo = !showInfo;
        ImGui::PopStyleColor(2);
        TIP("Show information messages");

        BUTTON_TOGGLE(showWarning);
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 0.5, 0, 1));
        if (ImGui::Button(ICON_FA_EXCLAMATION_TRIANGLE "##show_warnings"))
            showWarning = !showWarning;
        ImGui::PopStyleColor(2);
        TIP("Show warning messages");

        BUTTON_TOGGLE(showError);
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 0, 0, 1));
        if (ImGui::Button(ICON_FA_EXCLAMATION_TRIANGLE "##show_errors"))
            showError = !showError;
        ImGui::PopStyleColor(2);
        TIP("Show error messages");

        BUTTON_TOGGLE(showDebug);
        ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 0, 1, 1));
        if (ImGui::Button(ICON_FA_BUG "##show_debug"))
            showDebug = !showDebug;
        ImGui::PopStyleColor(2);
        TIP("Show debug messages");

        static ImGuiTextFilter filter;
        filter.Draw(FILTER_TEXT);
        ImGui::EndMenuBar();

        auto msgCopy = messages_;
        for (auto msg = msgCopy.rbegin(); msg != msgCopy.rend(); ++msg)
        {
            if (msg->level_ == Urho3D::LOG_INFO && !showInfo)
                continue;
            if (msg->level_ == Urho3D::LOG_ERROR && !showError)
                continue;
            if (msg->level_ == Urho3D::LOG_WARNING && !showWarning)
                continue;
            if (msg->level_ == Urho3D::LOG_DEBUG && !showDebug)
                continue;
            if (filter.PassFilter(msg->text_.c_str()))
            {
                switch (msg->level_)
                {
                case Urho3D::LOG_TRACE:
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0, 1, 1, 1));
                    break;
                case Urho3D::LOG_INFO:
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 1, 1));
                    break;
                case Urho3D::LOG_WARNING:
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 1, 0, 1));
                    break;
                case Urho3D::LOG_DEBUG:
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 0, 1, 1));
                    break;
                case Urho3D::LOG_ERROR:
                    ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(1, 0, 0, 1));
                    break;
                }
                
                ImGui::TextWrapped(msg->text_.c_str());
                ImGui::PopStyleColor();
            }
        }
    }
    ImGui::EndDock();
}

GUI_HistoryView::GUI_HistoryView() : GUI_DockView(ICON_FA_HISTORY " History")
{

}

void GUI_HistoryView::Draw()
{
    PROFILE(GUI_History);
    if (ImGui::BeginDock(title_.c_str(), &visible_, ImGuiWindowFlags_MenuBar))
    {
        auto doc = DocumentManager::Get()->GetActiveDocument();

        ImGui::BeginMenuBar();

        if (ImGui::Button(ICON_FA_ERASER) && doc) doc->GetUndoStack().Clear();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Clear");

        if (ImGui::Button(ICON_FA_UNDO) && doc) doc->GetUndoStack().Undo();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Undo");
        
        if (ImGui::Button(ICON_FA_REDO)) doc->GetUndoStack().Redo();
        if (ImGui::IsItemHovered()) ImGui::SetTooltip("Redo");

        ImGui::EndMenuBar();
        if (doc)
        {
            int stepDelta = 0;

            auto& activeUndoStack = doc->GetUndoStack();
            int currentPos = activeUndoStack.undo_.size();
            if (ImGui::Selectable("< empty history > ", activeUndoStack.undo_.empty(), ImGuiSelectableFlags_AllowDoubleClick))
                stepDelta = -activeUndoStack.undo_.size();

            ImGui::PushID("UNDO_STACK");
            for (size_t i = 0; i < activeUndoStack.undo_.size(); ++i)
            {
                ImGui::PushID(i + 1);
                auto& undoable = activeUndoStack.undo_[i];
                if (ImGui::Selectable(undoable->GetText().CString(), i == activeUndoStack.undo_.size() - 1, ImGuiSelectableFlags_AllowDoubleClick))
                    stepDelta = i - activeUndoStack.undo_.size() + 1;
                ImGui::PopID();
            }
            ImGui::PopID();

            ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(0.8, 0.3, 0.0, 1.0));
            ImGui::PushID("REDO_STACK");
            for (size_t i = 0; i < activeUndoStack.redo_.size(); ++i)
            {
                ImGui::PushID(i + 1);
                // expose redo in the correct order
                auto& undoable = activeUndoStack.redo_[activeUndoStack.redo_.size() - i - 1];
                if (ImGui::Selectable(undoable->GetText().CString(), false, ImGuiSelectableFlags_AllowDoubleClick))
                    stepDelta = i + 1;
                ImGui::PopID();
            }
            ImGui::PopID();
            ImGui::PopStyleColor();

            while (stepDelta > 0)
            {
                activeUndoStack.Redo();
                --stepDelta;
            }
            while (stepDelta < 0)
            {
                activeUndoStack.Undo();
                ++stepDelta;
            }
        }
    }
    ImGui::EndDock();
}


GUI_DataGrid::GUI_DataGrid() : GUI_DockView(ICON_FA_TABLE " Data Grid")
{

}

void GUI_DataGrid::Draw()
{
    PROFILE(GUI_DataGrid);
    if (ImGui::BeginDock(title_.c_str(), &visible_))
    {
        auto doc = DocumentManager::Get()->GetActiveDoc<Document3D>();
        if (doc && doc->GetSelection().Count())
        {
            std::vector<StringHash> fields;
            std::vector<Serializable*> objects;
            for (auto sel : doc->GetSelection())
            {
                if (auto node = std::dynamic_pointer_cast<UrhoNodeSelectable>(sel))
                    objects.push_back(node->node_.Get());
                else if (auto comp = std::dynamic_pointer_cast<UrhoComponentSelectable>(sel))
                    objects.push_back(comp->component_.Get());
            }

            if (objects.size() == 0)
            {
                ImGui::Indent();
                ImGui::NewLine();
                ImGui::Text("< nothing editable selected >");
                ImGui::Unindent();
                goto LABEL_DATA_GRID_END;
            }
            
            auto attrsContains = [](Vector<AttributeInfo>& infos, const String& name) { for (int i = 0; i < infos.Size(); ++i) { if (infos[i].name_ == name) return true; } return false; };
            static auto toNameList = [](Vector<AttributeInfo>& infos) { 
                std::set<std::string> names; 
                for (int i = 0; i < infos.Size(); ++i)
                {
                    if (infos[i].mode_ & AM_NOEDIT) // don't show non-editables
                        continue;
                    names.insert(infos[i].name_.CString());
                }
                return names; 
            };

            std::set<std::string> attrNames;
            {
                HashSet<StringHash> exploredTypes;
                PROFILE(AttributeIntersection);
                for (int i = 0; i < objects.size(); ++i)
                {
                    // just carry the existing intersection if this type has been encountered
                    if (exploredTypes.Contains(objects[i]->GetType()))
                        continue;

                    exploredTypes.Insert(objects[i]->GetType());
                    auto otherAttrs = *objects[i]->GetAttributes();
                    if (i == 0)
                        attrNames = toNameList(otherAttrs);
                    else
                    {
                        auto nameList = toNameList(otherAttrs);
                        std::set<std::string> newNames;
                        std::set_intersection(attrNames.begin(), attrNames.end(), nameList.begin(), nameList.end(), std::inserter(newNames, newNames.begin()));
                        attrNames = newNames;
                    }
                }
            }

            if (attrNames.size() == 0)
            {
                ImGui::Indent();
                ImGui::NewLine();
                ImGui::Text("^3< no fields common among selection >");
                ImGui::Unindent();
                goto LABEL_DATA_GRID_END;
            }

            bool useColumns = attrNames.size() > 1;
            if (useColumns)
            {
                ImGui::BeginChild("data_grid_columns", ImVec2(0, 0), true, ImGuiWindowFlags_HorizontalScrollbar);
                ImGui::Columns(attrNames.size());
            }

            // Headers
            ImGuiUX::PushBold();
            int attrIdx = 0;
            for (auto n : attrNames)
            {
                float w = ImGui::CalcTextSize(n.c_str()).x;
                ImGui::Text(n.c_str());
                if (useColumns && ImGui::GetColumnWidth(attrIdx) < (w + 10) && ImGui::IsItemHovered())
                    ImGui::SetTooltip(n.c_str());
                if (useColumns)
                    ImGui::NextColumn();
                ++attrIdx;
            }
            ImGui::PopFont();
            ImGui::Separator(4.0f);

            for (auto obj : objects)
            {
                ImGui::PushID(obj);
                for (auto name : attrNames)
                {
                    EditAttribute(doc->GetScene(), obj, name.c_str(), &doc->GetUndoStack(), true);
                    ImGui::PopID();
                    if (useColumns)
                        ImGui::NextColumn();
                }
                ImGui::PopID();
            }
            if (useColumns)
            {
                ImGui::EndColumns();
                ImGui::EndChild();
            }
        }
        else
        {
            ImGui::Indent();
            ImGui::NewLine();
            ImGui::Text("^3< nothing selected >");
            ImGui::Unindent();
        }
    }
    LABEL_DATA_GRID_END:
    ImGui::EndDock();
}

void DrawBinding(SharedPtr<InputBinding> binding, Input* input)
{
    static Vector<String> validKeys;
    if (validKeys.Size() == 0)
    {
#define PK(V) KEY_ ## V
        std::vector<int> keys = {
            KEY_0, KEY_1, KEY_2, KEY_3, KEY_4, KEY_5, KEY_6, KEY_7, KEY_8, KEY_9,
            PK(A), PK(B), PK(C), PK(D), PK(E), PK(F), PK(G), PK(H), PK(I), PK(J), PK(K), PK(L), PK(M), PK(N), PK(O), PK(P), PK(Q), PK(R), PK(S), PK(T), PK(U), PK(V), PK(W), PK(X), PK(Y), PK(Z),
            KEY_F1, KEY_F2, KEY_F3, KEY_F4, KEY_F5, KEY_F6, KEY_F7, KEY_F8, KEY_F9, KEY_F10, KEY_F11, KEY_F12,
            KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN, KEY_DELETE, KEY_BACKSPACE, KEY_PAGEUP, KEY_PAGEDOWN, KEY_HOME, KEY_END, KEY_INSERT,
            KEY_MINUS, KEY_PLUS, KEY_SEMICOLON, KEY_COMMA, KEY_QUOTE, KEY_LEFTBRACKET, KEY_RIGHTBRACKET, KEY_SLASH, KEY_BACKSLASH
        };
        for (size_t i = 0; i < keys.size(); ++i)
            validKeys.Push(input->GetKeyName(keys[i]));
    }

    ImGui::PushID(binding.Get());
    ImGuiUX::PushBold();
    ImGui::Text(binding->actionName_.CString());
    ImGuiUX::PopBold();
    if (!binding->message_.Empty())
    {
        ImGui::SameLine();
        ImGui::Text(ICON_FA_INFO_CIRCLE);
        if (ImGui::IsItemHovered())
            ImGui::SetTooltip(binding->message_.CString());
    }
    ImGui::Indent();
    String bindText = binding->keyCode_ != -1 ? input->GetKeyName(binding->keyCode_) : "<none>";
    if (ImGui::BeginCombo("Key", bindText.CString()))
    {
        for (size_t i = 0; i < validKeys.Size(); ++i)
        {
            bool sel = validKeys[i] == bindText;
            if (ImGui::Selectable(validKeys[i].CString(), sel))
                binding->keyCode_ = input->GetKeyFromName(validKeys[i]);
            if (sel)
                ImGui::SetItemDefaultFocus();
        }
        ImGui::EndCombo();
    }
    ImGui::Checkbox("CTRL", &binding->control_);
    ImGui::SameLine();
    ImGui::Checkbox("SHIFT", &binding->shift_);
    ImGui::SameLine();
    ImGui::Checkbox("ALT", &binding->alt_);
    ImGui::SameLine();
    if (ImGui::Button(ICON_FA_UNDO))
        binding->Reset();
    ImGui::Unindent();
    ImGui::PopID();
}

void DrawInputBindings()
{
    std::map<std::string, std::vector<SharedPtr<InputBinding> > > grouped;
    
    auto input = BlockExe::GetInst()->GetSubsystem<Input>();
    auto& bindings = input->GetInputBindings();
    for (auto& bind : bindings)
    {
        auto& found = grouped.find(bind->groupName_.CString());
        if (found != grouped.end())
            found->second.push_back(bind);
        else
            grouped[bind->groupName_.CString()] = { bind };
    }

    static int selectedIdx = 0;
    int i = 0;

    ImGui::BeginChild("list_options", ImVec2(300, 400));
    for (auto kvp : grouped)
    {
        bool sel = i == selectedIdx;
        bool wasSel = sel;
        if (sel)
            ImGuiUX::PushBold();
        ImGui::Selectable(kvp.first.c_str(), &sel);
        if (sel)
            selectedIdx = i;
        if (wasSel)
            ImGui::PopFont();
        ++i;
    }
    ImGui::EndChild();
    ImGui::SameLine();

    ImGui::BeginChild(selectedIdx, ImVec2(400, 400));
    i = 0;
    for (auto kvp : grouped)
    {
        if (i == selectedIdx)
        {
            for (auto bind : kvp.second)
                DrawBinding(bind, input);
        }
        ++i;
    }
    ImGui::EndChild();

    //auto input = BlockExe::GetInst()->GetSubsystem<Input>();
    //auto& bindings = input->GetInputBindings();
    //String lastGrp;
    //bool shouldContinue = false;
    //bool didAnyGroups = false;
    //for (auto& bind : bindings)
    //{
    //    if (bind->hidden_)
    //        continue;
    //
    //    if (lastGrp != bind->groupName_)
    //    {
    //        if (didAnyGroups)
    //            ImGui::Unindent();
    //        didAnyGroups = true;
    //        lastGrp = bind->groupName_;
    //        shouldContinue = ImGui::CollapsingHeader(bind->groupName_.CString());
    //        ImGui::Indent();
    //    }
    //    if (shouldContinue)
    //    {
    //        DrawBinding(bind, input);
    //        ImGui::Separator();
    //    }
    //}
}