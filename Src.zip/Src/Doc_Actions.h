#pragma once

#include <Urho3D/Container/Str.h>
#include <Urho3D/Input/Input.h>
#include <Urho3D/ThirdParty/ImGui/FontAwesome5.h>

#include "Doc_Selectable.h"

#include <functional>
#include <memory>
#include <string>
#include <vector>

class DocumentBase;

struct UndoRedo abstract
{
    virtual ~UndoRedo();

    bool firstRedo_ = true;
    virtual Urho3D::String GetText() = 0;
    virtual void Execute(bool isUndo, DocumentBase* forDoc) = 0;
    virtual bool CanMergeWith(UndoRedo* rhs) const { return false; }
    virtual void Merge(UndoRedo* rhs) { }
    // Dead actions just do code and don't get added
    virtual bool IsDead() const { return false; }

    void Redo(DocumentBase*);
    void Undo(DocumentBase*);

    void RecordStandardSelectables(DocumentBase* doc);

    void AttachSelectables(const SelectionList& undoSel, const SelectionList& redoSel) {
        RedoSelectables = redoSel;
        UndoSelectables = undoSel;
        selectablesSet = true;
    }

    std::vector<std::shared_ptr<UndoRedo> > Consequences;
    // Selectables, for most operations these will be the same, but for creation/deletion objects they will be the same.
    SelectionList RedoSelectables;
    SelectionList UndoSelectables;
    bool selectablesSet = false;
};

typedef std::vector< std::shared_ptr<UndoRedo> > UndoRedoList;

/// General purpose lambda based undoable activity.
struct FunctionalUndoRedo : public UndoRedo
{
    FunctionalUndoRedo(const Urho3D::String& text, std::function<void()> perform, std::function<void()> reverse);

    virtual Urho3D::String GetText() override { return text_; }
    virtual void Execute(bool isUndo, DocumentBase* forDoc);

    Urho3D::String text_;
    std::function<void()> perform_;
    std::function<void()> reverse_;
};

class DocumentBase;

struct UndoStack
{
    std::vector<std::shared_ptr<UndoRedo> > undo_;
    std::vector<std::shared_ptr<UndoRedo> > redo_;

    std::shared_ptr<UndoRedo> GetLatest();

    UndoStack(DocumentBase* doc) {
        doc_ = doc;
    }

    // Push a new item into the stack, returns self for chaining
    std::shared_ptr<UndoRedo> PushNew(std::shared_ptr<UndoRedo> act);

    void Clear();
    void Undo();
    void Redo();
    void UndoUntil(std::shared_ptr<UndoRedo> act);
    void RedoUntil(std::shared_ptr<UndoRedo> act);

    DocumentBase* doc_;
};

template<typename TARGET, typename T, typename CAST = T, typename CALL = T>
struct ClassPointerUndoRedo : public UndoRedo
{
    typedef Urho3D::String(*STRING_FUNC)(CAST val);

    typedef void (TARGET::*FUNC_PTR)(CALL);
    ClassPointerUndoRedo(Urho3D::String name, TARGET* mat, FUNC_PTR ptr, T oldValue, T newValue, STRING_FUNC strFunc = [](CAST val) -> Urho3D::String { return Urho3D::String(val); }) :
        name_(name),
        mat_(mat),
        ptr_(ptr),
        oldValue_(oldValue),
        newValue_(newValue),
        strFunc_(strFunc)
    {
        UpdateText();
    }

    virtual std::string GetText() override { return text_; }

    virtual void Execute(bool isUndo) override {
        if (isUndo)
            (mat_->*ptr_)(oldValue_);
        else
            (mat_->*ptr_)(newValue_);
    }

    virtual bool CanMergeWith(UndoRedo* rhs) const override {
        if (auto other = dynamic_cast<ClassPointerUndoRedo*>(rhs))
            return other->ptr_ == ptr_;
        return false;
    }

    virtual void Merge(UndoRedo* rhs) override {
        if (auto other = dynamic_cast<ClassPointerUndoRedo*>(rhs))
        {
            newValue_ = other->newValue_;
            text_ = other->text_;
        }
    }

    void UpdateText()
    {
        text_ = (ICON_FA_PENCIL_ALT " ^3 Set " + name_ + " " + strFunc_((CAST)newValue_));
    }

    FUNC_PTR ptr_;
    TARGET* mat_;
    T oldValue_;
    T newValue_;
    Urho3D::String name_;
    STRING_FUNC strFunc_;
    std::string text_;
};

struct MultiUndoRedo : public UndoRedo
{
    MultiUndoRedo(const Urho3D::String& text, const std::vector<std::shared_ptr<UndoRedo> >& actions);

    virtual Urho3D::String GetText() override { return text_; }

    virtual void Execute(bool isUndo, DocumentBase* forDoc) override;
    virtual bool CanMergeWith(UndoRedo* rhs) const override;
    virtual void Merge(UndoRedo* rhs) override;

    std::vector<std::shared_ptr<UndoRedo> > actions_;
    Urho3D::String text_;
};

typedef std::vector<Urho3D::SharedPtr<Urho3D::InputBinding>> ActionList;

class IQuickActionSource abstract
{
public:
    virtual ~IQuickActionSource() { }

    virtual void CollectActions(ActionList&) = 0;

    static void FilterActions(ActionList&);
};